<?php

namespace App\Http\Controllers;

use App\BuyerTeam;
use App\BuyerTeamUser;
use App\Quotes;
use App\User;
use App\BuyerTeamTags;
use App\SupplierQuotes;
use App\UserDetails;
use App\BuyerTeamUserAssignedBuyRequest;
use App\BuyerTeamUserAssignedQuote;
use Illuminate\Http\Request;

use Input;
use Auth;
use Response;
use Session;
use Mail;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class PurchasingManagerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $buyerTeam = BuyerTeam::find($id);
        $buyerTeamTags = BuyerTeamTags::where('buyer_team_id',$id)->get();
        if($buyerTeamTags)
        {
            foreach($buyerTeamTags as $tags)
            {
                $tags->delete();
            }
        }

        $buyerTeamUser = BuyerTeamUser::where('team_id',$id)->get();
        if($buyerTeamUser)
        {
            foreach($buyerTeamUser as $teamUser)
            {
                $teamUser->delete();
            }
        }

        $buyerTeam->delete();

        return Redirect('/manage-purchasing-teams')->with('message','Your Purchasing Team and its Members has been removed.');
    }

    public function managePurchasingTeam(){

        $userId = Auth::user()->id;
        $buyerTeam = BuyerTeam::where('user_id',$userId)->get()->toArray();
        $allBuyerTeam = array();
        foreach($buyerTeam as $team)
        {
            $teamArray = array();
            $teamArray['id'] = $team['id'];
            $teamArray['nameOfTeam'] = $team['name'];
            $teamArray['teamId'] = $team['team_id'];
            $teamArray['memberCount'] = BuyerTeamUser::where('team_id',$team['id'])->where('status',1)->count();
            $teamArray['dateCreated'] = date('d-m-Y',strtotime($team['created_at']));
            $teamArray['dateLastActive'] = $team['modified_date'];
            $allBuyerTeam[] = $teamArray;
        }

        return view('purchasing-manager.manage-teams')->with([
            'allBuyerTeam'=>$allBuyerTeam
        ]);
    }

    /*public function editPurchasingTeam(){
        return view('purchasing-manager.edit-team');
    }*/

    public function manageMembers(){

        $team_id = '';
        $userId = Auth::user()->id;

        $allBuyerTeam = BuyerTeam::where('user_id',$userId)->get();

        if(isset($_REQUEST['team_id']))
        {
            $team_id = $_REQUEST['team_id'];
            Session::put('team_id', $team_id);

            $team_id = Session::get('team_id');
            if($team_id == '')
            {
                $buyerTeam = BuyerTeam::where('user_id',$userId)->get();
            }
            else
            {
                $buyerTeam = BuyerTeam::where('id',$team_id)->get();
            }
        }
        else
        {
            $buyerTeam = BuyerTeam::where('user_id',$userId)->get();
        }

        $buyerTeamArray = array();
        foreach($buyerTeam as $team)
        {
            $buyerTeamUser = BuyerTeamUser::where('team_id',$team->id)->where('status',1)->get();
            if($buyerTeamUser)
            {
                foreach($buyerTeamUser as $user)
                {
                    $userArray = array();
                    $userArray['userId'] = $user->id;
                    $userArray['teamName'] = $team->name;
                    $userDetails = UserDetails::where('user_id',$user->user_id)->first();
                    $userArray['memberName'] = $userDetails->first_name.' '.$userDetails->last_name;
                    $userArray['memberSince'] = date('d-m-Y',strtotime($user->created_at));
                    $userArray['status'] = $userDetails->is_active;
                    if($team->label == 'Region')
                    {
                        $buyerTeamTags = BuyerTeamTags::where('buyer_team_id',$team->id)->get()->toArray();
                        if(count($buyerTeamTags) > 0)
                        {
                            $userArray['region'] = implode(', ', array_column($buyerTeamTags,'tag'));
                        }
                        else
                        {
                            $userArray['region'] = '';
                        }
                    }
                    else
                    {
                        $userArray['region'] = '';
                    }
                    $users = User::find($user->user_id);
                    $userArray['accountType'] = $users->account_member;
                    $buyerTeamArray[] = $userArray;
                }
            }
            else
            {
                $buyerTeamArray = array();
            }
        }

        return view('purchasing-manager.manage-members')->with([
            'allBuyerTeam'=>$allBuyerTeam,
            'buyerTeamArray'=>$buyerTeamArray,
            'team_id'=>$team_id
        ]);
    }

    public function assignBuyRequest()
    {
        $user_id = Auth::user()->id;

        $buyerTeam = BuyerTeam::where('user_id',$user_id)->orderBy('id', 'desc')->get();

        $SupplierQuotes = SupplierQuotes::whereRaw('buyer_id = ? AND preview = ?',array($user_id,0))->get();

        $date = date('Y-m-d');
        $buyerRequests = BuyerTeamUserAssignedBuyRequest::where('user_id',$user_id)->where('created_at','LIKE', '%'.$date.'%')->paginate(15);

        $buyerRequestsArray = array();
        foreach($buyerRequests as $buyerRequest){
            $dataArray = array();
            $dataArray['teamId'] = $buyerRequest->buyer_team_id;
            $quote = Quotes::find($buyerRequest->buy_request_id);
            $dataArray['buy_request_name'] = $quote->title;
            $dataArray['buy_request_id'] = $quote->unique_number;
            $dataArray['created_on'] = $quote->created_at;
            $dataArray['assigned_on'] = $buyerRequest->created_at;
            $userDetails = UserDetails::where('user_id',$buyerRequest->buyer_team_user_id)->first();
            $dataArray['assigned_to'] = $userDetails->first_name.' '.$userDetails->last_name;
            $dataArray['teamId'] = $buyerRequest->buyer_team_id;

            $buyerRequestsArray[] = $dataArray;
        }

        $previousPageUrl = $buyerRequests->previousPageUrl();//previous page url
        $nextPageUrl = $buyerRequests->nextPageUrl();//next page url
        $lastPage = $buyerRequests->lastPage(); //Gives last page number
        $total = $buyerRequests->total();
        return view('purchasing-manager.assign-buy-requests')->with(['buyerTeam'=>$buyerTeam,'SupplierQuotes'=>$SupplierQuotes,'buyerRequestsArray'=>$buyerRequestsArray,'buyerRequests'=>$buyerRequests,'previousPageUrl'=>$previousPageUrl,'nextPageUrl'=>$nextPageUrl,'lastPage'=>$lastPage,"total"=>$total]);
    }

    /**
     * Search Team User for send Lead Request
     */
    public function searchTeamUser()
    {
        $teamId = Input::get('teamId');

        $teamUsers = BuyerTeamUser::where('team_id',$teamId)->where('status',1)->get();
        $userListArray = array();
        foreach($teamUsers as $teamUser)
        {
            $dataArray = array();
            $dataArray['id'] = $teamUser->user_id;
            $usersData = UserDetails::where('user_id',$teamUser->user_id)->first();
            $dataArray['full_name'] = $usersData['first_name'].' '.$usersData['last_name'];
            $userListArray[] = $dataArray;
        }

        $ajaxArray = array();
        $ajaxArray['incomplete_results'] = false;
        $ajaxArray['items'] = $userListArray;
        return Response::json($ajaxArray);
    }

    public function saveBuyerRequests()
    {
        $teamMembers = Input::get('recipients');
        foreach($teamMembers as $value){
            $buyerRequests = new BuyerTeamUserAssignedBuyRequest();
            $buyerRequests->buyer_team_id = Input::get('team_name');
            $buyerRequests->buyer_team_user_id = $value;
            $buyerRequests->buy_request_id = Input::get('buyRequest');
            $buyerRequests->user_id = Auth::user()->id;
            $buyerRequests->save();
        }

        return Redirect('manager-assign-buy-requests')->with('message','Lead Request has been Assigned.');
    }

    public function viewAssignedBuyRequests()
    {
        $userId = Auth::user()->id;

        $allBuyerTeam = BuyerTeam::where('user_id',$userId)->get();

        $team_id = '';
        if(isset($_REQUEST['team_id']))
        {
            $team_id = $_REQUEST['team_id'];
            Session::put('team_id', $team_id);

            $team_id = Session::get('team_id');
            if($team_id == '')
            {
                $buyerRequests = BuyerTeamUserAssignedBuyRequest::where('user_id',$userId)->paginate(10);
            }
            else
            {
                $buyerRequests = BuyerTeamUserAssignedBuyRequest::where('buyer_team_id',$team_id)->paginate(10);
            }
        }
        else
        {
            $buyerRequests = BuyerTeamUserAssignedBuyRequest::where('user_id',$userId)->paginate(10);
        }

        $allBuyRequestArray = array();

        foreach($buyerRequests as $buyerRequest)
        {
            $buyerRequestArray = array();
            $buyerRequestArray['teamId'] = $buyerRequest->buyer_team_id;
            $quote = Quotes::find($buyerRequest->buy_request_id);
            $buyerRequestArray['buyRequestName'] = $quote->title;
            $buyerRequestArray['buyRequestId'] = $quote->unique_number;
            $buyerRequestArray['createdOn'] = date('d-m-Y',strtotime($quote->created_at));
            $buyerRequestArray['assignedOn'] = date('d-m-Y',strtotime($buyerRequest->created_at));
            $userDetails = UserDetails::where('user_id',$buyerRequest->buyer_team_user_id)->first();
            $buyerRequestArray['assignedTo'] = $userDetails->first_name.' '.$userDetails->last_name;

            $allBuyRequestArray[] = $buyerRequestArray;
        }

        $previousPageUrl = $buyerRequests->previousPageUrl();//previous page url
        $nextPageUrl = $buyerRequests->nextPageUrl();//next page url
        $lastPage = $buyerRequests->lastPage(); //Gives last page number
        $total = $buyerRequests->total();

        return view('purchasing-manager.view-assigned-buy-requests')->with([
            'buyerRequests'=>$buyerRequests,
            'allBuyRequestArray'=>$allBuyRequestArray,
            'previousPageUrl'=>$previousPageUrl,
            'nextPageUrl'=>$nextPageUrl,
            'lastPage'=>$lastPage,
            'total'=>$total,
            'allBuyerTeam'=>$allBuyerTeam,
            'team_id'=>$team_id
        ]);
    }

    public function assignQuotes(){

        $user_id = Auth::user()->id;

        $buyerTeam = BuyerTeam::where('user_id',$user_id)->orderBy('id', 'desc')->get();

        $quotes = Quotes::where('created_by',$user_id)->get();

        $date = date('Y-m-d');
        $buyerQuotes = BuyerTeamUserAssignedQuote::where('user_id',$user_id)->where('created_at','LIKE', '%'.$date.'%')->paginate(15);

        $buyerQuotesArray = array();
        foreach($buyerQuotes as $buyerQuote){
            $dataArray = array();
            $userData = UserDetails::where('user_id',$user_id)->first();
            $dataArray['quote_received_from'] = $userData->first_name.' '.$userData->last_name;
            $quote = Quotes::find($buyerQuote->buyer_quote_id);
            $dataArray['buy_request_name'] = $quote->title;
            $dataArray['created_on'] = $quote->created_at;
            $dataArray['assigned_on'] = $buyerQuote->created_at;
            $userDetails = UserDetails::where('user_id',$buyerQuote->buyer_team_user_id)->first();
            $dataArray['assigned_to'] = $userDetails->first_name.' '.$userDetails->last_name;
            $dataArray['teamId'] = $buyerQuote->buyer_team_id;

            $buyerQuotesArray[] = $dataArray;
        }

        $previousPageUrl = $buyerQuotes->previousPageUrl();//previous page url
        $nextPageUrl = $buyerQuotes->nextPageUrl();//next page url
        $lastPage = $buyerQuotes->lastPage(); //Gives last page number
        $total = $buyerQuotes->total();

        return view('purchasing-manager.assign-quotes')->with(['buyerTeam'=>$buyerTeam,'quotes'=>$quotes,'buyerQuotesArray'=>$buyerQuotesArray,'buyerQuotes'=>$buyerQuotes,'previousPageUrl'=>$previousPageUrl,'nextPageUrl'=>$nextPageUrl,'lastPage'=>$lastPage,"total"=>$total]);

    }

    public function saveQuotes()
    {
        $teamMembers = Input::get('recipients');
        foreach($teamMembers as $value){
            $buyerQuotes = new BuyerTeamUserAssignedQuote();
            $buyerQuotes->buyer_team_id = Input::get('team_name');
            $buyerQuotes->buyer_team_user_id = $value;
            $buyerQuotes->buyer_quote_id = Input::get('quote');
            $buyerQuotes->user_id = Auth::user()->id;
            $buyerQuotes->save();
        }

        return Redirect('manager-assign-quotes')->with('message','Quote has been Assigned.');
    }

    public function viewAssignedQuotes(){

        $userId = Auth::user()->id;

        $allBuyerQuotesArray = array();

        $buyerQuotes = BuyerTeamUserAssignedQuote::where('user_id',$userId)->paginate(10);
        foreach($buyerQuotes as $buyerQuote)
        {
            $buyerQuotesArray = array();
            $quote = Quotes::find($buyerQuote->buyer_quote_id);
            $buyerQuotesArray['quoteName'] = $quote->title;
            $buyerQuotesArray['quoteId'] = $quote->unique_number;
            $buyerQuotesArray['createdOn'] = date('d-m-Y',strtotime($quote->created_at));
            $buyerQuotesArray['assignedOn'] = date('d-m-Y',strtotime($buyerQuote->created_at));
            $userDetails = UserDetails::where('user_id',$buyerQuote->buyer_team_user_id)->first();
            $buyerQuotesArray['assignedTo'] = $userDetails->first_name.' '.$userDetails->last_name;

            $allBuyerQuotesArray[] = $buyerQuotesArray;
        }

        $previousPageUrl = $buyerQuotes->previousPageUrl();//previous page url
        $nextPageUrl = $buyerQuotes->nextPageUrl();//next page url
        $lastPage = $buyerQuotes->lastPage(); //Gives last page number
        $total = $buyerQuotes->total();

        return view('purchasing-manager.view-assigned-quotes')->with([
            'buyerQuotes'=>$buyerQuotes,
            'allBuyerQuotesArray'=>$allBuyerQuotesArray,
            'previousPageUrl'=>$previousPageUrl,
            'nextPageUrl'=>$nextPageUrl,
            'lastPage'=>$lastPage,
            'total'=>$total
        ]);
    }

    public function transferTeam(){
        return view('purchasing-manager.transfer-team');
    }

    public function teamBilling(){
        return view('purchasing-manager.team-billing');
    }
}
