<?php

namespace App\Http\Controllers;

use App\User;
use App\UserDetails;
use App\UsersActivity;
use App\AppsCountries;
use App\Referrals;
use App\ReferralPayment;
use App\SubscriptionPlans;
use App\Subscriptions;
use App\Company;
use App\QuotetekUserVerification;
use App\QuotetekCompanyVerification;
use App\PaymentDetails;
use App\StripeCards;
use App\TransactionUnique;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Route;
use Input;
use Auth;
use Response;
use Session;
use Mail;


class AccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    
    /**
     * Account Payment Information
     */
    public function viewPaymentInfo()
    {
        $user_id = Auth::user()->id;
        $paymentDetails = PaymentDetails::where('user_id',$user_id)->paginate(15);
        
        $previousPageUrl = $paymentDetails->previousPageUrl();//previous page url
        $nextPageUrl = $paymentDetails->nextPageUrl();//next page url
        $lastPage = $paymentDetails->lastPage(); //Gives last page number
        $total = $paymentDetails->total();
        
        return view('account.paymentInfo')->with(['paymentDetails'=>$paymentDetails,'previousPageUrl'=>$previousPageUrl,'nextPageUrl'=>$nextPageUrl,'lastPage'=>$lastPage,"total"=>$total]);
    }
    
    /**
     * Account Payment History
     */
    public function viewPaymentHistory()
    {
        $user_id = Auth::user()->id;
        $paymentDetails = PaymentDetails::where('user_id',$user_id)->orderBy('id','desc')->paginate(15);
        
        $previousPageUrl = $paymentDetails->previousPageUrl();//previous page url
        $nextPageUrl = $paymentDetails->nextPageUrl();//next page url
        $lastPage = $paymentDetails->lastPage(); //Gives last page number
        $total = $paymentDetails->total();
        
        return view('account.paymentHistory')->with(['paymentDetails'=>$paymentDetails,'previousPageUrl'=>$previousPageUrl,'nextPageUrl'=>$nextPageUrl,'lastPage'=>$lastPage,"total"=>$total]);
    }
    
    /**
     * user packages view
     */
    public function viewPackages()
    {
        $user_id = Auth::user()->id;
        
        $packages = Subscriptions::whereRaw('user_id = ? AND (plan_id = ? OR plan_id = ?)',array($user_id,1,2))->paginate(15);
        
        $previousPageUrl = $packages->previousPageUrl();//previous page url
        $nextPageUrl = $packages->nextPageUrl();//next page url
        $lastPage = $packages->lastPage(); //Gives last page number
        $total = $packages->total();
        
        return view('account.package')->with(['packages'=>$packages,'previousPageUrl'=>$previousPageUrl,'nextPageUrl'=>$nextPageUrl,'lastPage'=>$lastPage,"total"=>$total]);
    }
    
    /**
     * user packages view
     */
    public function viewSupplierPackages()
    {
        $user_id = Auth::user()->id;
        
        $packages = Subscriptions::whereRaw('user_id = ? AND (plan_id = ? OR plan_id = ? OR plan_id = ?)',array($user_id,3,4,5))->paginate(15);
        
        $previousPageUrl = $packages->previousPageUrl();//previous page url
        $nextPageUrl = $packages->nextPageUrl();//next page url
        $lastPage = $packages->lastPage(); //Gives last page number
        $total = $packages->total();
        
        return view('account.package-supplier')->with(['packages'=>$packages,'previousPageUrl'=>$previousPageUrl,'nextPageUrl'=>$nextPageUrl,'lastPage'=>$lastPage,"total"=>$total]);
    }
    
    /**
     * Unsubscribe package
     */
    public function unsubscribePackages($subscription_id)
    {
        $user_id = Auth::user()->id;
        $user = User::find($user_id);
        
        $Subscriptions = Subscriptions::whereRaw('user_id = ? AND stripe_plan = ?',array($user_id,$subscription_id))->first();
        
        
        $strip_key = env('STRIPE_SECRET', '');
        
        \Stripe\Stripe::setApiKey($strip_key);
        
        $customer = \Stripe\Customer::retrieve($Subscriptions->stripe_id);
        $subscription = $customer->subscriptions->retrieve($subscription_id);
        $subscription->cancel();
        
        if($subscription)
        {
            $SubScriptionResponse =  $subscription->__toArray(true);
            
            $Subscriptions->delete();
            
            return Redirect::back()->with('message', 'Your account details have changed.');
        }
        else
        {
            return Redirect::back()->with('message', 'There was a problem with this action. Please try again.');
        }
    }
    
    /**
     * package detail
     */
    public function packageDetail($id)
    {
        $package = Subscriptions::find($id);
        
        $strip_key = env('STRIPE_SECRET', '');
        \Stripe\Stripe::setApiKey($strip_key);
        
        $customer = \Stripe\Customer::retrieve($package->stripe_id);
        $subscription = $customer->subscriptions->retrieve($package->stripe_plan);
        $response =  $subscription->__toArray(true);
        
        $html = '';
        $html .= '<div class="modal-dialog">
                    <div class="modal-content" >
                    <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 form-group">
                            <p>Package Name: <b>'.$response['plan']['name'].'</b></p>
                            <p>Amount: <b>'.$package->amount.'</b></p>
                            <p>Status: <b>'.$response['status'].'</b></p>
                            <p>Trial End: <b>'.$response['trial_end'].'</b></p>
                            <p>Subscribed At: <b>'.date('Y-m-d',strtotime($package->created_at)).'</b></p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn default" data-dismiss="modal">Close</button>
                </div></div></div>';
        $ajaxDataArray = array();
        $ajaxDataArray['html'] = $html;
        return Response::json($ajaxDataArray);
    }
    
    /**
     * add new package
     */
    public function addPackages()
    {
        $user_id = Auth::user()->id;
        $user = User::find($user_id);
        $strip_public_key = env('STRIPE_PUBLIC_KEY', '');
        $userData = UserDetails::where('user_id',$user_id)->first();
        if($userData->company_id != '')
        {
            $company = Company::find($userData->company_id);
            $userData->company_name = $company->name;
        }
        else
        {
            $userData->company_name = '';
        }
        $billingPlans = array();
        if($userData->account_type == 'buyer')
        {
            $billingPlans = SubscriptionPlans::where('plan_type','buyer')->get();    
        }
        elseif($userData->account_type == 'Seller')
        {
            $billingPlans = SubscriptionPlans::where('plan_type','supplier')->get();
        }
        
        return view('account.billingPlans')->with(['user'=>$user,'userData'=>$userData,'billingPlans'=>$billingPlans,'strip_public_key'=>$strip_public_key]);
    }
    
    /**
     * Save user Billing Plan
     */
    public function saveUserPackage(Request $request)
    {
        $input = $request->all();
        $user_id = Auth::user()->id;
        $user = User::find($user_id);
        $card_token = $input['card_token'];
        $strip_key = env('STRIPE_SECRET', '');
        \Stripe\Stripe::setApiKey($strip_key);
        $this->validate($request, [
                'billing_plan' => 'required',
            ]);
        
        
        if($user->stripe_id == '')
        {
            $result = \Stripe\Customer::create(array(
                      "description" => "Customer for ".$user->email,
                      "email"=>$user->email,
                      "source" => $card_token // obtained with Stripe.js
                    ));
            if($result)
            {
                $response =  $result->__toArray(true);
                $user->stripe_id = $response['id'];
                $user->save();
               
            }
            else
            {
                return Redirect::to('user/packages')->with('message', 'There was a problem processing your payment. Please verify payment details and resubmit.');
            }
        }  
        
        $billingPlan = SubscriptionPlans::find($input['billing_plan']);
        
        $account_plan = $billingPlan->plan_key;
        
        $member_type = '';
        if($billingPlan->name == 'Buyer Plus Package' || $billingPlan->name == 'Supplier Gold Package')
        {
            $member_type = 'gold';
            $jobs = 15;
        }
        elseif($billingPlan->name == 'Supplier Silver Package')
        {
            $member_type = 'silver';
            $jobs = 5;
        }
        else
        {
            $member_type = 'free';
            $jobs = 0;
        } 
        if(floatval($billingPlan->amount) > 0)
        {
            $charge = \Stripe\Charge::create(array(
                      "amount" => floatval($billingPlan->amount),
                      "currency" => "usd",
                      "customer" => $user->stripe_id, // obtained with Stripe.js
                      "description" => "Charge for ".$user->email
                    ));    
        }
        else
        {
            $charge = true;
        }
        if($charge)
        {
            if($billingPlan->amount > 0)
            {
                $charges = $charge->__toArray(true);
                $amount_chanrge = $charges['amount'];
                $invoice_id = $charges['invoice'];
                $charge_id = $charges['id'];
                $balance_transaction = $charges['balance_transaction'];
            }
            else
            {
                $amount_chanrge = 0;
                $invoice_id = '';
                $charge_id = '';
                $balance_transaction = '';
            }
            $cu = \Stripe\Customer::retrieve($user->stripe_id);
            $subscriptionResult = $cu->subscriptions->create(array("plan" => $billingPlan->plan_key));
            if($subscriptionResult)
            {
                $SubScriptionResponse =  $subscriptionResult->__toArray(true);
                
                // payment details store
                
                // for user unique number
                $unique = TransactionUnique::first();
                $next = $unique->number+1;
                $unique->number = $next;
                $unique->save();
                
                $unique_number = 'IJV-'.$next;
                
                $paymentDetails = new PaymentDetails;
                $paymentDetails->user_id = $user_id;
                $paymentDetails->unique_number = $unique_number;
                $paymentDetails->payment_type = $input['card_type'];
                $paymentDetails->detail = 'Payment for '.$SubScriptionResponse['plan']['name'];
                $paymentDetails->amount = $amount_chanrge;
                $paymentDetails->card_number = $input['cardNumber'];
                $paymentDetails->card_last_4 = $input['card_last_4'];
                $paymentDetails->expiry = $input['cardExpiry'];
                $paymentDetails->cvv = $input['cardCVC'];
                $paymentDetails->save();
                
                // subscription save
                $subscription = new Subscriptions;
                $subscription->user_id = $user_id;
                $subscription->name = $SubScriptionResponse['plan']['name'];
                $subscription->plan_id = $billingPlan->id;
                $subscription->payment_id = $paymentDetails->id;
                $subscription->amount = $amount_chanrge;
                $subscription->invoice_id = $invoice_id;
                $subscription->charge_id = $charge_id;
                $subscription->balance_transaction = $balance_transaction;
                $subscription->stripe_id = $user->stripe_id;
                $subscription->stripe_plan = $SubScriptionResponse['id'];
                $subscription->quantity = $SubScriptionResponse['quantity'];
                $subscription->trial_ends_at = $SubScriptionResponse['trial_end'];
                $subscription->ends_at = $SubScriptionResponse['ended_at'];
                $subscription->save();
                
                
                // user update
                $user->account_member = $member_type;
                $user->account_plan = $account_plan;
                $user->job_post = $jobs;
                $user->save();
                
                if($billingPlan->amount > 0)
                {
                    $referral = Referrals::whereRaw('referral_to = '.$user_id.' AND paid_referral_by != 1 ')->first();
                    if($referral)
                    {
                        // add amount to referral by user
                        $paind_amount = round($amount_chanrge/2);
                        
                        $referralPayment = new ReferralPayment;
                        $referralPayment->user_id = $referral->referral_by;
                        $referralPayment->referral_user_id = $user_id;
                        $referralPayment->referral_id = $referral->id;
                        $referralPayment->subscription_id = $subscription->id;
                        $referralPayment->amount = $paind_amount;
                        $referralPayment->save();
                        
                        /// set first time amount added;
                        $referral->paid_referral_by = 1;
                        $referral->save();
                        
                        /// User Activity for message
                        $usersActivity = new UsersActivity;
                        $usersActivity->activity_name = 'Your referral payout(s) has posted on '.date('M d, Y').'.';
                        $usersActivity->activity_id = $referral->referral_by;
                        $usersActivity->activity_type = 'refferel_payout';
                        $usersActivity->creater_id = $referral->referral_by;
                        $usersActivity->receiver_id = null;
                        $usersActivity->save(); 
                    }
                }
                
                /* payment mail to receiver */
                $receiverData = UserDetails::where('user_id',$user_id)->first();
                $receiver = User::find($user_id);
                
                /// User Activity for message
                $usersActivity = new UsersActivity;
                $usersActivity->activity_name = 'Your Indy John account payment for '.$SubScriptionResponse['plan']['name'].' has been posted on '.date('M d, Y').'.';
                $usersActivity->activity_id = $user_id;
                $usersActivity->activity_type = 'package';
                $usersActivity->creater_id = $user_id;
                $usersActivity->receiver_id = null;
                $usersActivity->save();
                
                Input::replace(array('email' => $receiver->email,'name'=>$receiverData->first_name.' '.$receiverData->last_name));
                $data = array(
                                'name'=>Input::get('name'),
                                'plan'=>$SubScriptionResponse['plan']['name'],
                                'fees'=>$amount_chanrge,
                                'transaction_id'=>$charge_id,
                                'invoice_id'=>$invoice_id,
                                'invoicr_url'=>url('')
                                );
                Mail::send('admin.Emailtemplates.sellerPaymentPosted', $data, function($message){
                    $message->from(env('MAIL_USERNAME'), 'Indy John Team');
                    $message->to(Input::get('email'), Input::get('name'))->subject('Your Indy John account payment');
                });
                
                //return Redirect::to('user/packages')->with('message', 'Your account status has been changed.');
                $ajaxDataArray = array();
                $ajaxDataArray['success'] = true;
                return Response::json($ajaxDataArray);
            }
            
        }
        else
        {
            /* payment mail to receiver */
            $receiverData = UserDetails::where('user_id',$user_id)->first();
            $receiver = User::find($user_id);
            
            /// User Activity for message
            $usersActivity = new UsersActivity;
            $usersActivity->activity_name = 'There was a problem with your Account payment on '.date('M d, Y').'.';
            $usersActivity->activity_id = $user_id;
            $usersActivity->activity_type = 'package';
            $usersActivity->creater_id = $user_id;
            $usersActivity->receiver_id = null;
            $usersActivity->save();
            
            Input::replace(array('email' => $receiver->email,'name'=>$receiverData->first_name.' '.$receiverData->last_name));
            $data = array(
                            'name'=>Input::get('name'),
                            'plan'=>$billingPlan->name,
                            'fees'=>$billingPlan->amount,
                            'transaction_id'=>'',
                            'invoice_id'=>'',
                            'email'=>$receiver->email,
                            'date'=> date('Y-m-d'),
                            'invoicr_url'=>url('')
                            );
            Mail::send('admin.Emailtemplates.sellerPaymentDeclined', $data, function($message){
                $message->from(env('MAIL_USERNAME'), 'Indy John Team');
                $message->to(Input::get('email'), Input::get('name'))->subject('Your Indy John account payment');
            });
        }
        
        return Redirect::to('user/packages')->with('message', 'There was a problem with your action, please try again.');
    }
    
    /**
     * For user payment view
     */
    public function viewPaymentDetail($user_id,$price,$payment_type)
    {
        $user = User::find($user_id);
        return view('account.payment')->with(['user'=>$user,'price'=>$price,'payment_type'=>$payment_type]);
    }
    
    /**
     * user payment save
     */
    public function savePaymentDetail()
    {
        $input = Input::all();
        $user_id = $input['user_id'];
        $user = User::find($user_id);
        $card_token = $input['card_token'];
        $amount = $input['amount'];
        $strip_key = env('STRIPE_SECRET', '');
        $admin_name = env('CONTACT_TO_NAME', '');
        $admin_email = env('CONTACT_TO_EMAIL', '');
        $amount_chanrge = 0;
        \Stripe\Stripe::setApiKey($strip_key);
        
        
        if($user->stripe_id == '')
        {
            $result = \Stripe\Customer::create(array(
                      "description" => "Customer for ".$user->email,
                      "email"=>$user->email,
                      "source" => $card_token // obtained with Stripe.js
                    ));
            if($result)
            {
                $response =  $result->__toArray(true);
                $user->stripe_id = $response['id'];
                $user->save();
            }
            else
            {
                return Redirect::to('quotetek/payment/'.$user_id.'/'.$amount)->with('message', 'There was a problem processing your payment. Please verify payment details and resubmit.');
            }
        } 
        
        if($amount > 0)
        {
            $charge = \Stripe\Charge::create(array(
                      "amount" => $amount*100,
                      "currency" => "usd",
                      "customer" => $user->stripe_id, // obtained with Stripe.js
                      "description" => "Charge for ".$user->email
                    ));    
        }
        else
        {
            $charge = true;
        }
        if($charge)
        {
            if($amount > 0)
            {
                $charges = $charge->__toArray(true);
                $amount_chanrge = $charges['amount']/100;
                $invoice_id = $charges['invoice'];
                $charge_id = $charges['id'];
                $balance_transaction = $charges['balance_transaction'];
            }
            else
            {
                $amount_chanrge = 0;
                $invoice_id = '';
                $charge_id = '';
                $balance_transaction = '';
            }
            
            // payment details store
            
            $unique = TransactionUnique::first();
            $next = $unique->number+1;
            $unique->number = $next;
            $unique->save();
            
            $unique_number = 'IJV-'.$next;
            
            $paymentDetails = new PaymentDetails;
            $paymentDetails->user_id = $user_id;
            $paymentDetails->unique_number = $unique_number;
            $paymentDetails->payment_type = $input['card_type'];
            $paymentDetails->detail = 'Payment for '.$input['payment_type'];
            $paymentDetails->amount = $amount_chanrge;
            $paymentDetails->card_number = $input['cardNumber'];
            $paymentDetails->card_last_4 = $input['card_last_4'];
            $paymentDetails->expiry = $input['cardExpiry'];
            $paymentDetails->cvv = $input['cardCVC'];
            $paymentDetails->save();
            
            /* payment mail to receiver */
            $receiver = User::find($user_id);
            $name = '';
            if($receiver->access_level == 4)
            {
                $name = $receiver->name;
            }
            else
            {
                $receiverData = UserDetails::where('user_id',$user_id)->first();
                $name = $receiverData->first_name.' '.$receiverData->last_name;
            }
            
            
            
            if($input['payment_type'] == 'verification')
            {
                if($user->access_level == 4)
                {
                    $companyVerification = QuotetekCompanyVerification::where('user_id',$user_id)->first();
                    $companyVerification->payment = 1;
                    $companyVerification->save();
                }
                else
                {
                    $userVerification = QuotetekUserVerification::where('user_id',$user_id)->first();
                    $userVerification->payment = 1;
                    $userVerification->save();    
                }
                
                Input::replace(array('email' => $admin_email,'name'=>$admin_name));
                $data = array(
                                'name'=>Input::get('name'),
                                'user'=>$name,
                                'date' => date('M d, Y'),
                                'transaction_id'=>$charge_id,
                                'invoice_id'=>$invoice_id
                                );
                Mail::send('admin.Emailtemplates.verificationPaymentPosted', $data, function($message){
                    $message->from(env('MAIL_USERNAME'), 'Indy John Team');
                    $message->to(Input::get('email'), Input::get('name'))->subject('Your Indy John account verification details');
                });
                
            }
            else
            {
                Input::replace(array('email' => $receiver->email,'name'=>$name));
                $data = array(
                                'name'=>Input::get('name'),
                                'plan'=>'Payment for '.$input['payment_type'],
                                'fees'=>$amount_chanrge,
                                'transaction_id'=>$charge_id,
                                'invoice_id'=>$invoice_id,
                                'invoicr_url'=>url('')
                                );
                Mail::send('admin.Emailtemplates.sellerPaymentPosted', $data, function($message){
                    $message->from(env('MAIL_USERNAME'), 'Indy John Team');
                    $message->to(Input::get('email'), Input::get('name'))->subject('Your Indy John account payment');
                });
            }
            
            return Redirect::to('user/payment-history')->with('message', 'Your account status has been changed.');
            
        }
        else
        {
            /* payment mail to receiver */
            $receiver = User::find($user_id);
            $name = '';
            if($receiver->access_level == 4)
            {
                $name = $receiver->name;
            }
            else
            {
                $receiverData = UserDetails::where('user_id',$user_id)->first();
                $name = $receiverData->first_name.' '.$receiverData->last_name;
            }
            
            Input::replace(array('email' => $receiver->email,'name'=>$name));
            $data = array(
                            'name'=>Input::get('name'),
                            'plan'=>'Payment for '.$input['payment_type'],
                            'fees'=>$amount_chanrge,
                            'transaction_id'=>'',
                            'invoice_id'=>'',
                            'email'=>$receiver->email,
                            'date'=> date('Y-m-d'),
                            'invoicr_url'=>url('')
                            );
            Mail::send('admin.Emailtemplates.sellerPaymentDeclined', $data, function($message){
                $message->from(env('MAIL_USERNAME'), 'Indy John Team');
                $message->to(Input::get('email'), Input::get('name'))->subject('Your indy John account payment');
            });
        }
        return Redirect::to('user/payment-history')->with('message', 'Your payment was unsuccessful. Please verify your details and resubmit.');
        
    }
    
    public function viewCardDetail()
    {
        $user_id = Auth::user()->id;
        $user = User::find($user_id);
        
        $strip_key = env('STRIPE_SECRET', '');
        \Stripe\Stripe::setApiKey($strip_key);
        
        $cards = \Stripe\Customer::retrieve($user->stripe_id)->sources->all(array(
                  "object" => "card"
                ));
        $response =  $cards->__toArray(true);
        //echo '<pre>';print_r($response['data']);
        //exit(0);
        return view('account.cards')->with(['cards'=>$response['data'],'user'=>$user]);
    }
    
    public function saveCardDetail()
    {
        $input = Input::all();
        $user = User::find($input['user_id']);
        $strip_key = env('STRIPE_SECRET', '');
        \Stripe\Stripe::setApiKey($strip_key);
        
        $customer = \Stripe\Customer::retrieve($user->stripe_id);
        $result = $customer->sources->create(array("source" => $input['card_token']));
        if($result)
        {
            return Redirect::to('account-cards')->with('message', 'Your credit card details have been added.');
        }
        else
        {
            return Redirect::to('account-cards')->with('message', 'There was a problem with your credit card details. Please check and resubmit.');
        }
    }
    
    public function updateCardDetail()
    {
        $input = Input::all();
        $user = User::find($input['user_id']);
        $strip_key = env('STRIPE_SECRET', '');
        \Stripe\Stripe::setApiKey($strip_key);
        
        $customer = \Stripe\Customer::retrieve($user->stripe_id);
        $card = $customer->sources->retrieve($input['card_id']);
        $card->exp_month = $input['cardExpiryMonth'];
        $card->exp_year = $input['cardExpiryYear'];
        $result = $card->save();
        
        if($result)
        {
            return Redirect::to('account-cards')->with('message', 'Your credit card details have been added.');
        }
        else
        {
            return Redirect::to('account-cards')->with('message', 'There was a problem with your credit card details. Please check and resubmit.');
        }
    }
    
    public function deleteCard()
    {
        $input = Input::all();
        $user = User::find(Auth::user()->id);
        
        $strip_key = env('STRIPE_SECRET', '');
        \Stripe\Stripe::setApiKey($strip_key);
        
        $customer = \Stripe\Customer::retrieve($user->stripe_id);
        $result = $customer->sources->retrieve($input['card_id'])->delete();
        if($result)
        {
            return Redirect::to('account-cards')->with('message', 'Your credit card details have been added.');
        }
        else
        {
            return Redirect::to('account-cards')->with('message', 'There was a problem with your credit card details. Please check and resubmit.');
        }
    }
    
    public function viewTestMail()
    {
        return view('account.testmail');
    }
    
    public function sendTestMail()
    {
        echo '<pre>';print_r(Input::All());
        exit(0);
        
        try{
            
            $data = array('name'=>'Hiren Dave','email'=>Input::get('email'),'password'=>'admin123');
            Mail::send('admin.Emailtemplates.emailTemplate', $data, function($message){
                $message->from(env('MAIL_USERNAME'), 'Indy John Team');
                $message->to(Input::get('email'), 'Hiren Dave')->subject('Quotetek\'r Portal Login');
            });    
        }
        catch (\Exception $e) {
            echo $e;
            exit(0);
        }
        
        
        return Redirect::to('user/testmail')->with('message', 'This e-mail has been sent.');
    }
    
    /**
     * user payment invoice
     */
    public function viewPaymentInvoice($id)
    {
        $paymentDetail = PaymentDetails::find($id);
        if(Auth::user()->id != $paymentDetail->user_id)
        {
            return Redirect::to('not-authorized');
        }
        // for set unique number
        if($paymentDetail->unique_number == '')
        {
            // for user unique number
            $unique = TransactionUnique::first();
            $next = $unique->number+1;
            $unique->number = $next;
            $unique->save();
            
            $unique_number = 'IJV-'.$next;
            
            $paymentDetail->unique_number = $unique_number;
            $paymentDetail->save();
        }
        
        $user_id = $paymentDetail->user_id;
        
        $user = User::find($user_id);
        
        $paymentDetail->user = $user;
        
        if($user->userdetail->company_id != '')
        {
            $paymentDetail->userCompany = Company::find($user->userdetail->company_id);
        }
        else
        {
            $paymentDetail->userCompany = '';
        }
                        
        return view('account.paymentInvoice')->with(['paymentDetail'=>$paymentDetail]);
    }
    
    /**
     * package Invoice
     */
    public function viewPackagesInvoice($id)
    {
        $subscription = Subscriptions::find($id);
        if($subscription->payment_id != '')
        {
            $paymentDetail = PaymentDetails::find($subscription->payment_id);
        
            // for set unique number
            if($paymentDetail->unique_number == '')
            {
                // for user unique number
                $unique = TransactionUnique::first();
                $next = $unique->number+1;
                $unique->number = $next;
                $unique->save();
                
                $unique_number = 'IJV-'.$next;
                
                $paymentDetail->unique_number = $unique_number;
                $paymentDetail->save();
            }
            
            $user_id = $paymentDetail->user_id;
            
            $user = User::find($user_id);
            
            $paymentDetail->user = $user;
            
            if($user->userdetail->company_id != '')
            {
                $paymentDetail->userCompany = Company::find($user->userdetail->company_id);
            }
            else
            {
                $paymentDetail->userCompany = '';
            }
        }
        else
        {
            $paymentDetail = '';
        }
                        
        return view('account.package-invoice')->with(['paymentDetail'=>$paymentDetail,'subscription'=>$subscription]);
    }
    
}
