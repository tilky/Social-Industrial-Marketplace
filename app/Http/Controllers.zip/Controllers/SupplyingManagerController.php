<?php

namespace App\Http\Controllers;

use App\SupplierTeamUserLeadRequest;
use App\SupplierQuotes;
use App\Quotes;
use App\SupplierIgnoreQuotes;

use App\SupplierTeam;
use App\SupplierTeamTags;
use App\SupplierTeamUser;
use App\User;
use App\UserDetails;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Input;
use Auth;
use Session;
use Response;

class SupplyingManagerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $supplierTeam = SupplierTeam::find($id);
        $supplierTeamTags = SupplierTeamTags::where('supplier_team_id',$id)->get();
        if($supplierTeamTags)
        {
            foreach($supplierTeamTags as $tags)
            {
                $tags->delete();
            }
        }

        $supplierTeamUser = SupplierTeamUser::where('supplier_team_id',$id)->get();
        if($supplierTeamUser)
        {
            foreach($supplierTeamUser as $teamUser)
            {
                $teamUser->delete();
            }
        }

        $supplierTeam->delete();

        return Redirect('/manage-supplying-teams')->with('message','Your Supplier Team and its Members has been removed.');
    }

    public function manageSupplyingTeams()
    {
        $userId = Auth::user()->id;
        $supplierTeam = SupplierTeam::where('user_id',$userId)->get()->toArray();
        $allSupplierTeam = array();
        foreach($supplierTeam as $team)
        {
            $teamArray = array();
            $teamArray['id'] = $team['id'];
            $teamArray['nameOfTeam'] = $team['name'];
            $teamArray['teamId'] = $team['supplier_team_id'];
            $teamArray['memberCount'] = SupplierTeamUser::where('supplier_team_id',$team['id'])->where('status',1)->count();
            $teamArray['dateCreated'] = date('d-m-Y',strtotime($team['created_at']));
            $teamArray['dateLastActive'] = $team['modified_date'];
            $allSupplierTeam[] = $teamArray;
        }

        return view('supplying-manager.manage-teams')->with([
            'allSupplierTeam'=>$allSupplierTeam
        ]);
    }

    public function manageMembers()
    {
        $team_id = '';
        $userId = Auth::user()->id;

        $allSupplierTeam = SupplierTeam::where('user_id',$userId)->get();

        if(isset($_REQUEST['team_id']))
        {
            $team_id = $_REQUEST['team_id'];
            Session::put('team_id', $team_id);

            $team_id = Session::get('team_id');
            if($team_id == '')
            {
                $supplierTeam = SupplierTeam::where('user_id',$userId)->get();
            }
            else
            {
                $supplierTeam = SupplierTeam::where('id',$team_id)->get();
            }
        }
        else
        {
            $supplierTeam = SupplierTeam::where('user_id',$userId)->get();
        }

        $supplierTeamArray = array();
        foreach($supplierTeam as $team)
        {
            $supplierTeamUser = SupplierTeamUser::where('supplier_team_id',$team->id)->where('status',1)->get();
            if($supplierTeamUser)
            {
                foreach($supplierTeamUser as $user)
                {
                    $userArray = array();
                    $userArray['userId'] = $user->id;
                    $userArray['teamName'] = $team->name;
                        $userDetails = UserDetails::where('user_id',$user->user_id)->first();
                    $userArray['memberName'] = $userDetails->first_name.' '.$userDetails->last_name;
                    $userArray['memberSince'] = date('d-m-Y',strtotime($user->created_at));
                    $userArray['status'] = $userDetails->is_active;
                    if($team->label == 'Region')
                    {
                        $supplierTeamTags = SupplierTeamTags::where('supplier_team_id',$team->id)->get()->toArray();
                        if(count($supplierTeamTags) > 0)
                        {
                            $userArray['region'] = implode(', ', array_column($supplierTeamTags,'tag'));
                        }
                        else
                        {
                            $userArray['region'] = '';
                        }
                    }
                    else
                    {
                        $userArray['region'] = '';
                    }
                        $users = User::find($user->user_id);
                    $userArray['accountType'] = $users->account_member;
                    $supplierTeamArray[] = $userArray;
                }
            }
            else
            {
                $supplierTeamArray = array();
            }
        }

        return view('supplying-manager.manage-members')->with([
            'allSupplierTeam'=>$allSupplierTeam,
            'supplierTeamArray'=>$supplierTeamArray,
            'team_id'=>$team_id
        ]);
    }

    public function assignLeadRequests()
    {
        $userId = Auth::user()->id;
        $supplierTeam = SupplierTeam::where('user_id',$userId)->get();

        $date = date('Y-m-d');

        $SupplierIgnoreQuotes = SupplierIgnoreQuotes::where('supplier_id',$userId)->get();
        $result = array();
        foreach($SupplierIgnoreQuotes as $ignoreQuote)
        {
            $result[] = $ignoreQuote['quote_id'];
        }
        $quotes = Quotes::whereIn('id',$result)->get();

        $supplierTeamUserLeadRequests = SupplierTeamUserLeadRequest::where('user_id',$userId)->where('created_at','LIKE', '%'.$date.'%')->paginate(10);

        $supplierRequestsArray = array();
        foreach($supplierTeamUserLeadRequests as $teamUserRequest)
        {
            $dataArray = array();
                $quote = Quotes::find($teamUserRequest->lead_request_id);
            $dataArray['lead_request_name'] = $quote->title;
            $dataArray['lead_request_id'] = $quote->unique_number;
            $dataArray['created_on'] = date('d-m-Y',strtotime($quote->created_at));
            $dataArray['assigned_on'] = date('d-m-Y',strtotime($teamUserRequest->created_at));
                $userDetails = UserDetails::where('user_id',$teamUserRequest->supplier_team_user_id)->first();
            $dataArray['assigned_to'] = $userDetails->first_name.' '.$userDetails->last_name;
            $dataArray['teamId'] = $teamUserRequest->supplier_team_id;

            $supplierRequestsArray[] = $dataArray;
        }

        $previousPageUrl = $supplierTeamUserLeadRequests->previousPageUrl();//previous page url
        $nextPageUrl = $supplierTeamUserLeadRequests->nextPageUrl();//next page url
        $lastPage = $supplierTeamUserLeadRequests->lastPage(); //Gives last page number
        $total = $supplierTeamUserLeadRequests->total();

        return view('supplying-manager.assign-lead-requests')->with([
            'supplierTeam'=>$supplierTeam,
            'quotes'=>$quotes,
            'supplierRequestsArray'=>$supplierRequestsArray,
            'supplierTeamUserLeadRequests'=>$supplierTeamUserLeadRequests,
            'previousPageUrl'=>$previousPageUrl,
            'nextPageUrl'=>$nextPageUrl,
            'lastPage'=>$lastPage,
            'total'=>$total
        ]);
    }

    public function searchTeamUser()
    {
        $teamId = Input::get('teamId');

        $supplierTeamUser = SupplierTeamUser::where('supplier_team_id',$teamId)->where('status',1)->get();
        $supplierTeamUserArray = array();
        foreach($supplierTeamUser as $teamUser)
        {
            $dataArray = array();
            $dataArray['id'] = $teamUser->user_id;
                $userDetails = UserDetails::where('user_id',$teamUser->user_id)->first();
            $dataArray['full_name'] = $userDetails->first_name.' '.$userDetails->last_name;
            $supplierTeamUserArray[] = $dataArray;
        }

        $ajaxArray = array();
        $ajaxArray['incomplete_results'] = false;
        $ajaxArray['items'] = $supplierTeamUserArray;
        return Response::json($ajaxArray);
    }

    public function saveLeadRequests()
    {
        $userId = Auth::user()->id;
        $teamMembers = Input::get('recipients');

        foreach($teamMembers as $value)
        {
            $supplierTeamUserLeadRequests = new SupplierTeamUserLeadRequest();
            $supplierTeamUserLeadRequests->user_id = $userId;
            $supplierTeamUserLeadRequests->supplier_team_id = Input::get('team_name');
            $supplierTeamUserLeadRequests->supplier_team_user_id = $value;
            $supplierTeamUserLeadRequests->lead_request_id = Input::get('leadRequest');
            $supplierTeamUserLeadRequests->save();
        }

        return Redirect('manager-assign-lead-requests')->with('message','Lead Request has been assigned.');
    }

    public function assignLeads()
    {
        return view('supplying-manager.assign-leads');
    }

    public function viewAssignedLeadRequests()
    {
        $userId = Auth::user()->id;

        $allSupplierLeadRequestArray = array();

        $supplierTeamUserLeadRequests = SupplierTeamUserLeadRequest::where('user_id',$userId)->paginate(10);
        foreach($supplierTeamUserLeadRequests as $leadRequest)
        {
            $leadRequestArray = array();
            $leadRequestArray['teamId'] = $leadRequest->supplier_team_id;
                $quote = Quotes::find($leadRequest->lead_request_id);
            $leadRequestArray['leadRequestName'] = $quote->title;
            $leadRequestArray['leadRequestId'] = $quote->unique_number;
            $leadRequestArray['createdOn'] = date('d-m-Y',strtotime($quote->created_at));
            $leadRequestArray['assignedOn'] = date('d-m-Y',strtotime($leadRequest->created_at));
                $userDetails = UserDetails::where('user_id',$leadRequest->supplier_team_user_id)->first();
            $leadRequestArray['assignedTo'] = $userDetails->first_name.' '.$userDetails->last_name;
            $allSupplierLeadRequestArray[] = $leadRequestArray;
        }

        $previousPageUrl = $supplierTeamUserLeadRequests->previousPageUrl();//previous page url
        $nextPageUrl = $supplierTeamUserLeadRequests->nextPageUrl();//next page url
        $lastPage = $supplierTeamUserLeadRequests->lastPage(); //Gives last page number
        $total = $supplierTeamUserLeadRequests->total();

        return view('supplying-manager.view-assigned-lead-requests')->with([
            'supplierTeamUserLeadRequests'=>$supplierTeamUserLeadRequests,
            'allSupplierLeadRequestArray'=>$allSupplierLeadRequestArray,
            'previousPageUrl'=>$previousPageUrl,
            'nextPageUrl'=>$nextPageUrl,
            'lastPage'=>$lastPage,
            'total'=>$total
        ]);
    }

    public function viewAssignedLeads(){
        return view('supplying-manager.view-assigned-leads');
    }

    public function teamBilling(){
        return view('supplying-manager.team-billing');
    }

    public function transferTeam(){
        return view('supplying-manager.transfer-team');
    }

}
