@extends('buyer.app')

@section('content')
<style>
@charset "utf-8";
/* CSS Document */

.mt-comments .result .mt-comment-body {
	overflow: visible !important;
	padding-left: 105px;
}
.mt-comments .result:hover {
	background:none;
}
.mt-comments .result .mt-comment-body span.label {
	margin-right: 8px !important;
	border-radius:25px;
	color:#000;
	font-weight: 600;
}
.mt-comments .result .mt-comment-body span.label-warning {
	background-color: #F3C200;
}
.mt-comments .result .mt-comment-body span.label-default {
	background-color: #E0E0E0;
}
.mt-comments .result .mt-comment-img {
	width: 45px;
}
.mt-comments .result .mt-comment-author {
	margin-right:5px !important;
}
.mt-comments .result .mt-comment-author a {
	color:#0C0;
}
.result .mt-comment-text {
	padding:2px 0px;
}
.mt-comments .result .mt-comment-info {
	float: left;
	width: 100%;
}
.center-nav { float: none !important; margin-bottom:-4px !important;}
.res_found{
	padding:0px 10px;
}
.center-nav>li>a {
	padding: 12px 61px 13px !important;
}
.filter_list ul {
	margin:0px;
	padding:0px;
	list-style:none;
}
.mt-comments .result .mt-comment-img {
    width: 90px;
    height: 90px;
	margin:1px 0px;
    float: left;
}
.mt-comments .result .mt-comment-img img {
    width: 90px;
    height: 90px;
}
.filter_list ul li {
	padding:15px 0px;
	border-bottom: 4px solid #36c6d3;
}
.no_filter{ float:none;}
.filter_list ul li ul li {
	border-bottom: 1px solid #999 !important;
}
.filter_list ul li a {
	color:#999;
}
.filter_list .task-list {
	width:100%;
	float:left;
}
.result{min-height: 90px;}
.mt-comments p{margin: 0px!important;}
.fliter:hover, .fliter:focus{ text-decoration:none;}
 @media(max-width:991px) {
 .center-nav>li>a {
 padding: 12px 55px 13px !important;
}
}
 @media(max-width:767px) {
 .center-nav>li>a {
 padding: 12px 24px 13px !important;
}
}
 @media(max-width:480px) {
 .center-nav>li>a {
 padding: 12px 4px 13px !important;
}
.result .mt-comment-body span.label {
 margin-right: 8px !important;
 margin-bottom: 8px;
 display: inline-block;
}

</style>
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url()}}/user-dashboard">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="{{url()}}/contactusers">Contact List</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>Add Contact</span>
        </li>
    </ul>
</div>
<!--<h3 class="page-title"> Result for Search: "{{$search}}" </h3>-->
<div class="col-md-12 main_box">
<div class="row">
    <div class="col-md-12 border2x_bottom" id="form_wizard_1">
                <div class="row">
                  <h3 class="page-title uppercase"> {{$search}}</h3>
</div>
                    
                </div>
            </div>
<div class="row">
    <div class="col-md-12 col-sm-12">
        <div class="portlet light ">
            @if (Session::has('message'))
                <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
            @endif
            @if($search != '')
            <div class="portlet-body">
            <div class="tabbable-line ">
                <ul class="nav nav-tabs">
                    <li>
                        <a href="{{url('general/search')}}?query={{$_REQUEST['query']}}" ><h5 class="bold uppercase"> All Results </h5></a>
                    </li>
                    <li>
                        <a href="{{url('company/search')}}?query={{$_REQUEST['query']}}" ><h5 class="bold uppercase"> Companies </h5></a>
                    </li>
                    <li>
                        <a href="{{url('people/search')}}?query={{$_REQUEST['query']}}"> <h5 class="bold uppercase">People</h5> </a>
                    </li>
                    <li class="active">
                        <a href="{{url('product/search')}}?query={{$_REQUEST['query']}}"><h5 class="bold uppercase"> Products </h5></a>
                    </li>
                    <li>
                        <a href="{{url('jobs/search/result')}}?query={{$_REQUEST['query']}}"><h5 class="bold uppercase"> Jobs </h5></a>
                    </li>
                </ul>
            </div>
            
                <div class="tab-content">
                    <div class="tab-pane active" id="portlet_comments_1"> 
                        <!-- BEGIN: Comments -->
                        @if(count($results) > 0)
                            <div class="mt-comments col-md-12 col-sm-12 center-block margin-bottom-20">
                                <p class="text-right res_found">@if($total == 1){{$total}} Result Found @else {{$total}} Results Found for {{$search}} @endif</p>
                            </div>
                             <div class="clearfix"></div>
                            @foreach ($results as $result)
                                <div class="mt-comments col-md-12 col-sm-12 center-block no_filter">
                                    <p class="text-right res_found">&nbsp;</p>
                                    <div class="mt-comment result">
                                        <div class="mt-comment-img"> 
                                            @if($result->image != '')
                                            <a href="{{url('marketplaceproducts')}}/{{$result->id}}" target="_blank">
                                            <img src="{{url('public/marketplace/product/images')}}/{{$result->image}}" alt="{{$result->name}}" class="img-circle" >
                                            @else
                                            <img src="//www.gravatar.com/avatar/18051c749493cc76ad88dd94789cc74e?s=64" alt="{{$result->name}}" class="img-circle">
                                            @endif 
                                            </a>
                                        </div>
                                        <div class="mt-comment-body">
                                            <div class="mt-comment-info"> 
                                                <a href="{{url('marketplaceproducts')}}/{{$result->id}}" target="_blank">
                                                <span class="mt-comment-author font-20">{{$result->name}}</span>
                                                </a>
                                                <div class="actions pull-right">
                                                    <div class="btn-group"> <a class="btn btn-circle yellow-crusta color-black btn-circle btn-sm" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> Actions <i class="fa fa-angle-down"></i> </a>
                                                        <ul class="dropdown-menu pull-right">
                                                            <li>
                                                                <a href="{{url('marketplaceproducts')}}/{{$result->id}}" target="_blank">
                                                                    <i class="icon-docs"></i> View Listing </a>
                                                            </li>
                                                            <li>
                                                                <a href="{{url('home/user/profile')}}/{{$result->seller->id}}" target="_blank">
                                                                    <i class="icon-docs"></i> View Seller Profile </a>
                                                            </li>
                                                            <li>
                                                                <a href="{{url('messages/create')}}?buyer={{$result->seller->id}}&product={{$result->id}}" target="_blank">
                                                                    <i class="icon-docs"></i> Contact Seller </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mt-comment-author"><a href="#">${{$result->price}}</a> {{$result->brand_name}} | {{$result->model_number}}  | 
                                                @foreach($result->categories as $index=>$category)
                                                    @if($index < 3)
                                                        @if($index == 0)
                                                        {{$category->category->name}}
                                                        @else
                                                        ,{{$category->category->name}}
                                                        @endif
                                                    @endif
                                                @endforeach
                                             </span>
                                            <div class="mt-comment-text"> Listed by : <a href="{{url('home/user/profile')}}/{{$result->seller->id}}" class="font18" target="_blank">{{$result->seller->userdetail->first_name}} {{$result->seller->userdetail->last_name}}</a>
                                                @if($result->star == 'gold')
                                                <span class="label label-sm label-warning gold-member caps-on"> Gold Member </span> 
                                                @elseif($result->star == 'silver')
                                                <span class="label label-sm label-default silver-member caps-on"> Silver Member </span> 
                                                @else
                                                <span class="label label-sm label-default free-member caps-on"> Free Member </span>
                                                @endif
                                                @if($result->seller->quotetek_verify == 1)
                                                <span class="label label-sm label-default verify-member caps-on"> Verified </span>
                                                @else
                                                <span class="label label-sm label-default verify-member caps-on"> Not Verified </span>
                                                @endif
                                            </div>
                                            <span class="mt-comment-status">@if($result->seller->userdetail->city != ''){{$result->seller->userdetail->city}}, {{$result->seller->userdetail->state}}, {{$result->seller->userdetail->country}} @endif  @if($result->seller->userdetail->getUserIndustry)| {{$result->seller->userdetail->getUserIndustry->name}}@endif</span> 
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        @else
                            <div class="mt-comments col-md-12 col-sm-12 center-block">
                                <p>No Listings found. Please try another search query or <a href="{{ URL::to('request-product-quotes/create') }}" class="btn btn-circle btn-sm red pull-right"> Post a Buy Request </a></p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
            @else
                <p>Nothing to search</p>
            @endif
        </div>
        <div class="col-md-12 align-center">
            {!! $results->render() !!}
        </div>
        
              
    </div>
</div>
</div>
<script>
    /* for show menu active */
    $("#dashboard-menu").addClass("active");
	/* end menu active */
    
</script>
@endsection
