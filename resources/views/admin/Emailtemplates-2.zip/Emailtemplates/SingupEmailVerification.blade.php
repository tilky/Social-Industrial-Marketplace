
@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">

  <br />
  Thank you for signing up with <a href="http://indyjohn.com">Indy John</a>.
  <br />
 Please verify your e-mail by clicking the following link:
 
 <br /> <a href="{{$url}}" target="_blank">{{$url}}</a>
 <br />
 <br />
                           If you have any query regarding log in, please <a href="mailto:support@indyjohn.com">Indy John Support Team</a>.

							


</p>

@include('admin.Emailtemplates.footer')
