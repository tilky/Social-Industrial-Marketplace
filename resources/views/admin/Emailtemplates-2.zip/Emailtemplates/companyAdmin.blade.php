@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}}</h3>



<p style="float:left; text-align:left;">


You have been appointed to be the Company Page administrator for {{$company->name}}.
<br /><br />
   <p>Use this link to create an account and complete "{{$company->name}}" page on  <a href="http://indyjohn.com">Indy John</a>.
   


</p>
@include('admin.Emailtemplates.footer')
