
@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">                            Your login has been created for <a href="http://indyjohn.com">Indy John</a>.

                   <br /><br />         Email : {{$email}}

                      <br />      Password : *HIDDEN*

                     <br /><br />       If you have any query regarding log in, please contact <a href="mailto:support@indyjohn.com">Indy John Support</a>.





</p>

@include('admin.Emailtemplates.footer')

