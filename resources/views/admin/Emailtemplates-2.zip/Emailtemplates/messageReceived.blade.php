@include('admin.Emailtemplates.header')


   <h3 style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 18px; line-height: 2em; font-weight: normal; margin: 0 auto 10px; padding: 0;">Hello {{$name}},</h3> 
   

  <p style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 15px; line-height: 1.6em; font-weight: normal; margin: 0 auto 10px; padding: 0;">


You have received a message from {{$sender_first_name}} {{$sender_last_name}} on IndyJohn.com. <br /><br />

Message Details: <br />
"{{$message_detail}}"
<br />

<a href="http://indyjohn.com/auth/login">Log In to Indy John</a> to view the complete message, sender details and to respond.
 <br /><br /><b>
Remember to network more efficiently by sharing your Indy John profile with your co-workers and business associates.</b>


</p>

@include('admin.Emailtemplates.footer')
