@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">

   A new user has been added to {{$company_name}}, company page at <a href="http://indyjohn.com"> Indy John</a>. 
                            
                            New Account Details: 
                            Name: {{$first_name}} {{$last_name}}
                            Date Joined: {{$date_joined}}
                            Please log on to <a href="http://indyjohn.com"> Indy John</a> to manage Users. 



</p>

@include('admin.Emailtemplates.footer')


                         
                    
					
