@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}},</h3>

<p style="float:left; text-align:left;">


Thank you for your payment. Your subscription details are as followed -


   <br />Account Plan: {{$plan}}
   <br />
                            <br />Fee Charged: {{$fees}}
                            <br />Payment Transaction ID: {{$transaction_id}}
                            <br />Invoice ID: {{$invoice_id}}
                            <br /><a href="{{$invoicr_url}}" target="_blank">Click here to Print this Invoice</a>


</p>
@include('admin.Emailtemplates.footer')
