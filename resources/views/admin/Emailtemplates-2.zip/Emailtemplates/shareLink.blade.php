
@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello,</h3>

<br /><br />
Check Link {{$share_link}}   
<br /><br />
Message: {{$custom_message}}
<br /><br /><a href="http://indyjohn.com">Begin Exploring Now</a>                    
@include('admin.Emailtemplates.footer')
