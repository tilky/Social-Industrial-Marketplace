@include('admin.Emailtemplates.header')

<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$company_name}} administrator,</h3>
<p style="float:left; text-align:left;">
A user has been removed from {$company_name}} company user profile page at IndyJohn.com 
<br />Please log on to <a href="http://indyjohn.com"> Indy John</a> to manage Users, and more. 


@include('admin.Emailtemplates.footer')
