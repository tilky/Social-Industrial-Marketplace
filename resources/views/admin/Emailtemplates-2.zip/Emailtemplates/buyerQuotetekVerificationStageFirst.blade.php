@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}}</h3>



<p style="float:left; text-align:left;">

Thank you for choosing to become a Verified User. 
<br /><br />
We have received your application and fee. Please allow 7-10 days for application process to complete. 
<br /><br />
We will contact you shortly if any additional information if needed. 
  <br /><br />Payment Details:
                           <br />Account Name: {{$account_name}}
                           <br />Transaction ID: {{$transaction_id}}
                           <br />Invoice ID: {{$invoice_id}}
							 <br /> <br /> Please log in to <a href="http://indyjohn.com">Indy John</a> to print an invoice. 
</p>
@include('admin.Emailtemplates.footer')

