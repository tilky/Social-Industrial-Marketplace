
@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}}, </h3>



<p style="float:left; text-align:left;">

{{$sender_name}} want's to introduce IndyJohn.com to you.  Indy John is a Social Marketplace for Everything Industrial built for Buyers and Suppliers.
<br /><br />
{{$sender_name}} said, "{{$custome_message}}".
<br /><br />
We have a referral program for our users, if you choose to sign up, please use {{$sender_name}} referral code:  {{$referralCode}} or follow this link {{$url}}
<br /><br />
Please visit <a href="http://indyjohn.com">Indy John</a> now to begin exploring.


</p>
@include('admin.Emailtemplates.footer')
