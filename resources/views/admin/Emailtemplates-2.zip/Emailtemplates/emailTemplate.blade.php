
@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">

                     Welcome and Thank you for signing up with Indy John. You are now a member of the first social marketplace dedicated to the Industrial workforce. We hope you enjoy our service !
                        
                          <br /><br />
                            Please verify your e-mail address by clicking the following link: <br />
                                {{url('quotetekverification')}}
								
								
							
							 <br /><br /><a href="http://indyjohn.com">Begin Exploring Now</a>
                            
                  </p>
				  
@include('admin.Emailtemplates.footer')
