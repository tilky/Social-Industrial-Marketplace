@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}},</h3>

<p style="float:left; text-align:left;">


Unfortunately, we were unable to process your payment. Kindly log in and update your payment settings so that we can try again. You are subscribed for :


   <br />Account Plan: {{$plan}}
   <br />
                            <br />Fee Due: {{$fees}}
                    
                            <br />Invoice ID: {{$invoice_id}}
                            <br /><a href="{{$invoicr_url}}" target="_blank">Click here to View and Print this Invoice</a>


</p>
@include('admin.Emailtemplates.footer')


