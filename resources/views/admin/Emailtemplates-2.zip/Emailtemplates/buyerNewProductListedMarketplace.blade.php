@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">

                            <h3>Hi {{$name}},</h3>
                            <br />A supplier has just posted a product on the Indy John Market that matches your previous buy request. We’re sending this to you just in case you haven’t decided on a supplier and need more options.
							
                            <br /> <br />Here are their details:
                            <br /> <br />Listing Title: {{$title}}
                            <br />Listing Category: {{$product_categories}}
                            <br />Industry: {{$product_industries}}
                            <br />      <br />
                            <br />Seller Name: {{$supplier_name}}
                            <br />Seller Company Name: {{$seller_company}}
                            <br />Seller Profile URL: {{$seller_profile_link}}
                            <br />Sign in to your <a href="http://indyjohn.com">Indy John</a> account to learn more about this product listing. 
                     </p>
						   
@include('admin.Emailtemplates.footer')
