
@include('admin.Emailtemplates.header')


<h3 style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 18px; line-height: 2em; font-weight: normal; margin: 0 auto 10px; padding: 0;">Hello {{$name}},</h3>

<p style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 15px; line-height: 1.6em; font-weight: normal; margin: 0 auto 10px; padding: 0;">

Welcome and Thank you for signing up with <a href="http://indyjohn.com">Indy John</a>. You are now a member of the first social marketplace dedicated to the Industrial workforce. We hope you enjoy our service! 
<br /><br />
  Please verify your e-mail address by clicking the following link: <br /> <a href="{{url('quotetek/user/verification')}}" target="_blank">{{url('quotetek/user/verification')}} </a>
 <br />
 <br />
                           If you have any questions, please contact our <a href="mailto:support@indyjohn.com">Support Team</a>.

							


</p>

@include('admin.Emailtemplates.footer')
