<!-- BEGIN FOOTER -->
<!-- /.modal -->
<div class="modal fade footer-modal" id="basic1" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h3 class="modal-title" style="text-transform: uppercase;">Help us Improve</h3>
                <p class="caption-helper" style="margin: 5px 0px!important;">Your feedback helps us understand what we do well and where we can improve.</p>
            </div>
            <form action="{{url('feedback/message')}}" method="post" class="horizontal-form">
                <input type="hidden" name="_token" value="{{csrf_token()}}" />
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 form-group">
                            <label class="control-label">Subject:</label>
                            <div class="">
                                <input type="text" name="subject" class="form-control" placeholder="Add a subject to your feedback" />
                            </div>
                        </div>
                        <div class="col-md-12 form-group">
                            <label class="control-label">Summary:</label>
                            <div class="">
                                <textarea name="message" class="form-control" rows="4" placeholder="Please describe your comments and feedback."></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-circle default" data-dismiss="modal">Close</button>
                    <button type="submite" class="btn btn-circle blue">Send</button>
                </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<div class="page-footer">
    <div class="page-footer-inner"> © Indy John Inc. All Rights Reserved. <a href="javascript:void(0);" id="footer-feedback"><b>Feedback</b></a>
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<script>
$('#footer-feedback').click(function(){
    jQuery('#basic1').modal('show');    
});

</script>
<!-- END FOOTER -->
