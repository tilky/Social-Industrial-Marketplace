<!-- BEGIN HEADER SEARCH BOX -->

<style>

.serach-head-btn{background: none!important;z-index: 1001!important;}

.header-search{position: absolute!important;}

</style>

<div class="col-md-12 paddin-bottom">

    <!-- DOC: Apply "search-form-expanded" right after the "search-form" class to have half expanded search box -->

    <form class="search-form" action="{{url('general/search')}}"  method="GET" autocomplete="off">

        <div class="input-group pulsate-two-target pulsate-five-target pulsate-six-target pulsate-eight-target search_div">

            @if(isset($_REQUEST['query']))

                <input type="text" class="form-control input-circle search-head-int" value="{{str_replace('+',' ',$_REQUEST['query'])}}" placeholder="Search for People, Companies, Products and Service Providers." name="query">

            @else

                <input type="text" class="form-control input-circle search-head-int" placeholder="Search for People, Companies, Products and Service Providers." name="query">

            @endif

            <span class="input-group-btn btn-circle header-search">

                <button type="submit" class="btn btn-circle submit serach-head-btn">

                    <i class="fa fa-search color-black"></i>

                </button>

            </span>

        </div>

    </form>

</div>
<!-- END HEADER SEARCH BOX -->

