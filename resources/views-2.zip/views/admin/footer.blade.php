<!-- BEGIN FOOTER -->
<!-- /.modal -->
<div class="modal fade " id="overview-select-modal" tabindex="-1" role="basic" aria-hidden="true" data-width="760">
  <div class="modal-dialog">
    <div class="modal-content">
      
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12">
          
            <div class="align-center"><img src="http://cryptdata.com/qt/public/images/indy_john_crm_logo.png" />
            <p>We're a new company with a highly Technical User-Platform.  This diagram will help you understand what Indy John has to offer. </p>
            </div>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <div class="col-md-12 align-center">
              <div class="btn-group overview" data-toggle="buttons">
                <div class="col-md-12 col-sm-12">
                  <div class="row">
                    <div class="clearfix"></div>
                    <label class="btn btn-primary btn-group invite-contact-sec-div overview_quote" id="pulsate-one">
                      <input type="radio" name="user_type" value="2_1" autocomplete="off">
                     quote-lead<br />system

                       </label>
                    <label class="btn btn-primary row-one" id="pulsate-four">
                      <input type="radio" name="user_type" value="3_4" autocomplete="off">
                      <h4>buyers</h4>
<p>submit buy requests
receive quotes
compare & select</p> </label>
                    <label class="btn btn-primary row-one" id="pulsate-nine">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                     <h4> suppliers</h4>
<p>post a lead request
receive leads
quote new buyers</p></label>
                      <label class="btn btn-primary row-one" id="pulsate-nine">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                      <h4>service providers</h4>
<p>post a lead request
receive service leads
send quotes</p> </label>
                      
                      
                      
                  </div>
                </div>
                <div class="col-md-12 col-sm-12">
                  <div class="row"> 
                    <label class="btn btn-primary overview_market" id="pulsate-two">
                      <input type="radio" name="user_type" value="2_2" autocomplete="off">
                      indy john <br />market </label>
                    <label class="btn btn-primary row-two" id="pulsate-eight">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                     <h4> buyers</h4>
<p>shop industrial
explore listings
find new suppliers</p></label>
                    <label class="btn btn-primary row-two" id="pulsate-five">
                      <input type="radio" name="user_type" value="3_5" autocomplete="off">
                     <h4> sellers</h4>
<p>post products
promote listings
reach new buyers</p> </label>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12">
                  <div class="row"> 
                    <label class="btn btn-primary overview_job_board" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      indy john <br />
job board</label>
                    <label class="btn btn-primary row-three" id="pulsate-eight">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                     <h4> job seekers</h4>
<p>search jobso
research companies
apply online</p> </label>
                    <label class="btn btn-primary row-three" id="pulsate-nine">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                     <h4> employers</h4>
<p>list jobs
find qualified talent
manage applicants</p> </label>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12">
                  <div class="row"> 
                    <label class="btn btn-primary overview_search" id="pulsate-three">
                      <input type="radio" name="user_type" value="3_3" autocomplete="off">
                      search<br />
discovery </label>
                    <label class="btn btn-primary row-four" id="pulsate-seven">
                      <input type="radio" name="user_type" value="2_7" autocomplete="off">
                     <p>discover
companies</p> </label>
                    <label class="btn btn-primary row-four" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <p>find people</p></label>
                      <label class="btn btn-primary row-four" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <p>explore <br />
job listings</p> </label>
                      <label class="btn btn-primary row-four" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <p>locate <br />
service providers</p></label>
                      <label class="btn btn-primary row-four" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <p>seek products</p> </label>
                      <label class="btn btn-primary row-four" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <p>find product<br />
 services</p> </label>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12">
                  <div class="row"> 
                    <label class="btn btn-primary overview_social" id="pulsate-three">
                      <input type="radio" name="user_type" value="3_3" autocomplete="off">
                      social<br />
marketplace </label>
                    <label class="btn btn-primary row-five" id="pulsate-seven">
                      <input type="radio" name="user_type" value="2_7" autocomplete="off">
                      <p>endorse users</p> </label>
                    <label class="btn btn-primary row-five" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <p>earn referrals</p> </label>
                      <label class="btn btn-primary row-five" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <p>company pages</p> </label>
                      <label class="btn btn-primary row-five" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <p>connect</p></label>
                      <label class="btn btn-primary row-five" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <p>direct message</p> </label>
                      <label class="btn btn-primary row-five" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <p>invite associates</p></label>
                  </div>
                </div>
                 </div>
            </div>
          </div>
        </div>
        <div class="clearfix"></div>
      </div>
      <div class="clearfix"></div>
    </div>
    <!-- /.modal-content --> 
    <div class="clearfix"></div>
  </div>
  <!-- /.modal-dialog --> 
  <div class="clearfix"></div>
</div>
<!-- /.modal -->
<!-- /.modal -->
<div class="modal fade footer-modal" id="basic1" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h3 class="modal-title" style="text-transform: uppercase;">Help us Improve</h3>
                <p class="caption-helper" style="margin: 5px 0px!important;">Your feedback helps us understand what we do well and where we can improve.</p>
            </div>
            <form action="{{url('feedback/message')}}" method="post" class="horizontal-form">
                <input type="hidden" name="_token" value="{{csrf_token()}}" />
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 form-group">
                            <label class="control-label">Subject:</label>
                            <div class="">
                                <input type="text" name="subject" class="form-control" placeholder="Add a subject to your feedback" />
                            </div>
                        </div>
                        <div class="col-md-12 form-group">
                            <label class="control-label">Summary:</label>
                            <div class="">
                                <textarea name="message" class="form-control" rows="4" placeholder="Please describe your comments and feedback."></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-circle default" data-dismiss="modal">Close</button>
                    <button type="submite" class="btn btn-circle blue">Send</button>
                </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<!-- /.modal -->
<div class="modal fade footer-modal" id="basic" tabindex="-1" role="basic" aria-hidden="true" data-width="760">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
        <h4 class="modal-title align-center" id="myModalLabel"> Tell your Friends and Associates about us! </h4>
      </div>
      <div class="modal-body" id="basic-invite">
        <div class="title align-center">
          <h2>Invite new users or connect with existing associates. </h2>
          <p>Earn referral payouts on users that choose valued accounts. <a href="{{url('referral-link/about-the-program')}}">Learn More</a> </p>
        </div>
        <div class="form align-center paddin-bottom" style="width: 70%;margin: 0 auto;"> 
          <!--  form-body  -->
          
          <div class="align-center" >
            <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-6"> <a href="{{Session::get('google_invite_url')}}" target="_blank"><img src="{{url('public/images/Indy-John/gmail-icon.png')}}" class="img-circle center-block modal-invite-img"></a> </div>
              <div class="col-md-6 col-sm-6 col-xs-6"> <a href="javascript:void(0)" onclick="GetYahooHeaderContact();"><img src="{{url('public/images/Indy-John/yahoo-icon.png')}}" class="img-circle modal-invite-img center-block"></a> </div>
            </div>
            <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-6"> <a href="{{Session::get('msn_invite_url')}}" target="_blank"><img src="{{url('public/images/Indy-John/outlook-icon.png')}}" class="img-circle modal-invite-img center-block"></a> </div>
              <div class="col-md-6 col-sm-6 col-xs-6"> <a href="{{url('invite/email')}}" target="_blank"><img src="{{url('public/images/Indy-John/mail-icon.png')}}" class="img-circle modal-invite-img center-block"></a> </div>
            </div>
          </div>
          <!--  /form-body  --> 
          
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-circle dark btn-outline" data-dismiss="modal">Close</button>
      </div>
    </div>
    <!-- /.modal-content --> 
  </div>
  <!-- /.modal-dialog --> 
</div>
<!-- /.modal -->
<!-- Upgrade account modal -->
   <div class="modal fade general-pricing" id="upgrade-supplier-acount-modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <ul class="nav nav-tabs">
    <li class="active"> <a data-toggle="tab" href="#tab_buyer" aria-expanded="true"> Buyer Dashboard </a> </li>
    <li> <a data-toggle="tab" href="#tab_supplier" aria-expanded="false"> Supplier Crm </a> </li>
  </ul>
  <div style="opacity: 1; transition: opacity 0.1s linear 0s;" class="tab-content">
    <form method="post" action="{{url('user/packages/save')}}" role="form" id="payment-form-pop"  class="form-horizontal form-row-seperated">
      <input type="hidden" name="_token" value="{{csrf_token()}}">
      <input type="hidden" name="card_token" value="" id="card_token_pop" />
      <input type="hidden" name="card_last_4" value="" id="card_last_4_pop" />
      <input type="hidden" name="card_type" id="card_type_pop" value="" />
      <input type="hidden" name="cardNumber" id="cardNumber_pop" value="" />
      <input type="hidden" name="cardExpiry" id="cardExpiry_pop" value="" />
      <input type="hidden" name="cardCVC" id="cardCVC_pop" value="" />
      <input type="hidden" name="billing_plan" id="billing_plan_pop" />
      <input type="hidden" id="modal-type" />
    </form>
    <div id="tab_buyer" class="tab-pane active in">
      <div class="tab-content-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> </button>
        <h4 class="modal-title" id="myModalLabel"> Gain an Edge, Upgrade Your Buyer Dashboard. </h4>
      </div>
      <div class="buyer_content">
        <div class="col-md-12 buyer_content_inner">
          <h5>Gain pricing options by becoming a Buyer+</h5>
          <p>Being a consumer in today's industrial marketplace is difficult and time consuming.
            We've developed features and tools to help buyers get the price they want. Upgrade to our Buyer+ account
            to gain benefits and simplify your purchasing process. </p>
        </div>
        <br>
        <br>
        <div class="clearfix"></div>
        <div class="col-md-4">
          <div class="thumbnail">
            <div class="caption">
              <h1 class="box-title"> FREE </h1>
              <h6>ACCOUNT</h6>
              <h1><span>$</span>0</h1>
              <h6>PER MONTH</h6>
              <hr>
              <ul class="free-list">
                <li>BUY REQUESTS LIMITED TO 30/ MONTH</li>
                <li>QUOTES DELAYED UP TO 1 DAY</li>
                <li>LIMITED TO 10 INDUSTRIAL MARKETS</li>
                <li>POST UP TO 30 MARKET LISTINGS</li>
                <li>MARKET LISTINGS EXPIRE MONTHLY</li>
  <li>NO JOB BOARD CREDITS</li>
                <li><span>VERIFICATION NOT INCLUDED</span></li>
              </ul>
              @if(Auth::user()->account_plan == 'buyerstandard')
              <button id="plan_FREE_2_0">Current Account</button>
              @elseif(Auth::user()->account_plan == 'buyerplus')
              <a id="plan_FREE_2_0" class="downgrade-class" href="{{url('user/packages')}}" >Downgrade</a>
              @else
              <button id="plan_FREE_2_0" class="upgrade" onclick="updatePlan(id,'buyer');">UPGRADE</button>
              @endif
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail gray_color">
            <div class="caption">
              <h1 class="box-title"> BUYER+ </h1>
              <h6>ACCOUNT</h6>
              <h1><span>$</span>199</h1>
              <h6>PER MONTH</h6>
              <hr>
              <ul class="free-list">
                <li><span>UNLIMITED</span> BUY REQUESTS</li>
                <li>QUOTES DELIVERED <span>INSTANTLY</span></li>
                <li><span>UNLIMITED</span> INDUSTRIAL MARKETS</li>
                <li><span>UNLIMITED</span> MARKET LISTINGS</li>
                <li>MARKET LISTINGS <span>DO NOT EXPIRE</span></li>
  <li><span>15</span> JOB BOARD CREDITS</li>
 

                <li><span>VERIFICATION INCLUDED</span></li>
              </ul>
              @if(Auth::user()->account_plan == 'buyerplus')
              <button id="plan_BUYER+_1_19900">Current Account</button>
              @else
              <button class="upgrade" id="plan_BUYER+_1_19900" onclick="updatePlan(id,'buyer');">UPGRADE</button>
              @endif
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
            <div class="caption">
              <h1 class="box-title"> ADVANCED </h1>
              <h6>ACCOUNT</h6>
              <h2>COMING<br/>
                SOON</h2>
              <div class="current-plan">
                <p><span>EXPANDED PURCHASING</span><br/>
                  FEATURES AND TOOLS</p>
              </div>
              <button class="upgrade">COMING SOON</button>
            </div>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="footer-pricing">
          <h4>Industrial Purchasing made Easy, Upgrade Now.</h4>
          <h5>* These rates are set for 2016.</h5>
        </div>
      </div>
    </div>
    <div id="tab_supplier" class="tab-pane">
      <div class="tab-content-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> × </button>
        <h4 class="modal-title" id="myModalLabel"> Gain an Edge, Upgrade Your Supplier CRM. </h4>
      </div>
      <div class="supplier_content">
        <div class="col-md-12 supplier_content_inner">
          <h5>Increase selling opportunities for the price of a cell phone bill.</h5>
          <p> We know sales environments can be very competitive, and prospecting for serious buyers can be very time
            consuming.  Our technologies are designed to produce serious leads, gain advantages now by upgrading
            to one of our valued accounts. </p>
        </div>
        <br>
        <br>
        <div class="clearfix"></div>
        <div class="col-md-4">
          <div class="thumbnail">
            <div class="caption">
              <h1 class="box-title"> FREE </h1>
              <h6>ACCOUNT</h6>
              <h1><span>$</span>0</h1>
              <h6>PER MONTH</h6>
              <ul class="free-list">
                <li>LEADS LIMITED UP TO 10/ MONTH</li>
                <li>LEADS DELAYED UP TO 1 DAY</li>
                <li>LIMITED TO 1 INDUSTRIAL MARKET</li>
                <li>POST UP TO 30 MARKET LISTINGS</li>
                <li>MARKET LISTINGS EXPIRE MONTHLY</li>
 <li>NO JOB BOARD CREDITS</li>
                <li><span>VERIFICATION NOT INCLUDED</span></li>
              </ul>
              @if(Auth::user()->account_plan == 'supplierfree')
              <button id="plan_FREE_5_0" >Current Account</button>
              @elseif(Auth::user()->account_plan == 'suppliersilver' || Auth::user()->account_plan == 'suppliergold')
              <a id="plan_FREE_5_0" class="downgrade-class" href="{{url('user/packages')}}" >Downgrade</a>
              @else
              <button id="plan_FREE_5_0" class="upgrade" onclick="updatePlan(id,'seller');">UPGRADE</button>
              @endif
              
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
            <div class="caption">
              <h1 class="box-title"> SILVER </h1>
              <h6>ACCOUNT</h6>
              <h1><span>$</span>149</h1>
              <h6>PER MONTH</h6>
              <ul class="free-list">
                <li>LEADS LIMITED UP TO 30/ MONTH</li>
                <li>LEADS DELAYED UP TO 12 HOURS</li>
                <li>LIMITED TO 10 INDUSTRIAL MARKETS</li>
                <li>POST UP TO 100 MARKET LISTINGS</li>
                <li>MARKET LISTINGS DO NOT EXPIRE</li>
 <li>5 JOB BOARD CREDITS</li>
                <li><span>VERIFICATION INCLUDED</span></li>
              </ul>
              @if(Auth::user()->account_plan == 'suppliersilver')
              <button id="plan_SILVER_4_14900" >Current Account</button>
              @elseif(Auth::user()->account_plan == 'suppliergold')
              <a id="plan_SILVER_4_14900" class="downgrade-class" href="{{url('user/packages')}}" >Downgrade</a>
              @else
              <button class="upgrade"  id="plan_SILVER_4_14900" onclick="updatePlan(id,'seller');">UPGRADE</button>
              @endif
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail gray_color">
            <div class="most-popular"> MOST POPULAR +<br/>
              UNLIMITED ACCESS </div>
            <div class="caption">
              <h1 class="box-title"> GOLD </h1>
              <h6>ACCOUNT</h6>
              <h1><span>$</span>199</h1>
              <h6>PER MONTH</h6>
              <ul class="free-list">
                <li><span>UNLIMITED</span> LEADS</li>
                <li>LEADS DELIVERED <span> INSTANTLY</span></li>
                <li><span>UNLIMITED</span> INDUSTRIAL MARKETS</li>
                <li><span>UNLIMITED</span> MARKET LISTINGS</li>
                <li>MARKET LISTINGS <span>DO NOT EXPIRE</span></li>
 <li><span>15</span> JOB BOARD CREDITS</li>
                <li><span>VERIFICATION INCLUDED</span></li>
              </ul>
              @if(Auth::user()->account_plan == 'suppliergold')
              <button id="plan_GOLD_3_19900" >Current Account</button>
              @else
              <button class="upgrade" id="plan_GOLD_3_19900" onclick="updatePlan(id,'seller');">UPGRADE</button>
              @endif
            </div>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="footer-pricing">
          <h4>Don't Limit Your Opportunities, Upgrade Now. </h4>
          <h5>* These rates are set for 2016.</h5>
        </div>
      </div>
    </div>
  </div>
</div>
    
    <script src="https://checkout.stripe.com/checkout.js"></script>
    <script>
      var handler = StripeCheckout.configure({
        key: "{{env('STRIPE_PUBLIC_KEY', '')}}",
        image: "{{url('public/images/indy_john_crm_logo.png')}}",
        locale: 'auto',
        token: function(token) {
            
            var user_type = $('#modal-type').val();
            if(user_type == 'seller')
            {
                App.blockUI({
                    target: '#payment-plan-seller-div',
                    animate: true
                });
            }
            else
            {
                App.blockUI({
                    target: '#payment-plan-buyer-div',
                    animate: true
                });
            }
            $('#card_token_pop').val(token.id);
            $('#card_last_4_pop').val(token.card.last4);
            $('#cardNumber_pop').val('');
            $('#cardExpiry_pop').val(token.card.exp_month+' / '+token.card.exp_year);
            $('#cardCVC_pop').val('');
            $('#card_type_pop').val(token.card.brand+' '+token.type);
            $('#payment-form-pop').submit();
          // You can access the token ID with `token.id`.
          // Get the token ID to your server-side code for use.
        }
      });
      
      function updatePlan(id,user_type)
      {
        if(user_type == 'seller')
        {
            $('#modal-type').val('seller');
        }
        else
        {
            $('#modal-type').val('buyer');
        }
        
        var values = id.split('_');
        $('#billing_plan_pop').val(values[2]);
        
        // Open Checkout with further options:
        handler.open({
          name: "{{url('/')}}",
          description: values[1]+' ACCOUNT',
          email:"{{Auth::user()->email}}",
          amount: values[3]
        });
        
      }
      
      // Close Checkout on page navigation:
      $(window).on('popstate', function() {
        handler.close();
      });
    </script>

<!-- /.modal -->
<!-- dashboar select modal -->
<!-- /.modal -->
<div class="modal fade " id="dashboard-select-modal" tabindex="-1" role="basic" aria-hidden="true" data-width="760">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="btn btn-circle btn-outline" class="close" data-dismiss="modal" aria-hidden="true"></button>
        <h3 class="modal-title">WHAT WOULD YOU LIKE TO DO TODAY?</h3>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12">
            <h4 class="align-center">Select one the best applies:</h4>
            <div class="col-md-12 align-center">
              <input type="hidden" id="pulsate-val" value="@if(Session::has('pulsate')) {{Session::get('pulsate')}} @endif" />
              <div class="btn-group quickstart" data-toggle="buttons">
                <div class="col-md-3 col-sm-3">
                  <div class="row"> <span class="quickstart_heading buyers">Buyers</span>
                    <div class="clearfix"></div>
                    <label class="btn btn-primary btn-group invite-contact-sec-div row-one" id="pulsate-one">
                      <input type="radio" name="user_type" value="2_1" autocomplete="off">
                      Get<br />
                      <b>Product Quotes</b> </label>
                    <label class="btn btn-primary row-one" id="pulsate-four">
                      <input type="radio" name="user_type" value="3_4" autocomplete="off">
                      Find <b>Product Service</b> </label>
                    <label class="btn btn-primary row-one" id="pulsate-nine">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                      Locate <b>Industrial<br />
                      Service Providers.</b> </label>
                  </div>
                </div>
                <div class="col-md-3 col-sm-3">
                  <div class="row"> <span class="quickstart_heading suppliers">Suppliers</span>
                    <div class="clearfix"></div>
                    <label class="btn btn-primary row-two" id="pulsate-two">
                      <input type="radio" name="user_type" value="2_2" autocomplete="off">
                      Receive Product & Service Leads</b> </label>
                    <label class="btn btn-primary row-two" id="pulsate-eight">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                      Upload your <br/>
                      Product Catalog </label>
                    <label class="btn btn-primary row-two" id="pulsate-five">
                      <input type="radio" name="user_type" value="3_5" autocomplete="off">
                      Claim or Create a<br />
                      <b>Company Profile</b> </label>
                  </div>
                </div>
                <div class="col-md-3 col-sm-3">
                  <div class="row"> <span class="quickstart_heading multi-user">Multi-User</span>
                    <div class="clearfix"></div>
                    <label class="btn btn-primary row-three" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <b>Upgrade</b> Your <br />
                      Indy John Account </label>
                    <label class="btn btn-primary row-three" id="pulsate-eight">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                      <b>Refer <br/>
                      & Earn</b> </label>
                    <label class="btn btn-primary row-three" id="pulsate-nine">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                      ? <b>Verify</b><br />
                      My Account </label>
                  </div>
                </div>
                <div class="col-md-3 col-sm-3">
                  <div class="row"> <span class="quickstart_heading more-options">More Options</span>
                    <div class="clearfix"></div>
                    <label class="btn btn-primary row-four" id="pulsate-three">
                      <input type="radio" name="user_type" value="3_3" autocomplete="off">
                      Explore<br />
                      <b>Indy John Market</b> </label>
                    <label class="btn btn-primary row-four" id="pulsate-seven">
                      <input type="radio" name="user_type" value="2_7" autocomplete="off">
                      Visit the<br />
                      <b>Job Board</b> </label>
                    <label class="btn btn-primary row-four" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      Search & <br />
                      Discover </label>
                  </div>
                </div>
                <br>
                <a href="">Not Sure yet, butz want to Explore.</a> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.modal-content --> 
  </div>
  <!-- /.modal-dialog --> 
</div>
<div class="page-footer">
    <div class="page-footer-inner"> © Indy John Inc. All Rights Reserved. <a href="javascript:void(0);" id="footer-feedback"><b>Feedback</b></a>
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<script>
$('#footer-feedback').click(function(){
    jQuery('#basic1').modal('show');    
});
$('#invite-user-header').click(function(){
    jQuery('#basic').modal('show');    
});
$('#upgrade-buyer-modal').click(function(){
    jQuery('#upgrade-buyer-acount-modal').modal('show');    
});
$('#upgrade-supplier-modal').click(function(){
    jQuery('#upgrade-supplier-acount-modal').modal('show');    
});
$('#show-dashboad-select').click(function(){
    jQuery('#dashboard-select-modal').modal({
        backdrop: 'static',
        keyboard: false
    });
});

$('#show-overview-info').click(function(){
    jQuery('#overview-select-modal').modal({
        backdrop: 'static',
        keyboard: false
    });	
});	
function GetYahooHeaderContact()
{
    App.blockUI({
        target: '#blockui_sample_1_portlet_body',
        animate: true
    });
    
    jQuery.ajax({
        url: '{{url("invite/yahoo/url")}}',
        type: 'get',
        success: function(data) {
                    //window.location.href = data.url;
                    window.open(data.url,'_blank');
                    App.unblockUI('#blockui_sample_1_portlet_body');
                 },
        done: function() {
            //console.log('error');
        },
        error: function() {
            //console.log('error');
        }
        
    }); 
}
</script>
<script>

$(document).ready(function() {

    $("#pulsate-one").click(function(){
       $(".pulsate-one-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-two").click(function(){
       $(".pulsate-two-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    
    $("#pulsate-three").click(function(){
       $(".pulsate-three-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-four").click(function(){
       $(".pulsate-four-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-five").click(function(){
       $(".pulsate-five-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-six").click(function(){
       $(".pulsate-six-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-seven").click(function(){
       $(".pulsate-seven-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-eight").click(function(){
       $(".pulsate-eight-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
		
 });


</script>
<script src="{{URL::asset('public/metronic/plugins/jquery.pulsate.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-bootpag/jquery.bootpag.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/holder.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/pages/scripts/ui-general.min.js')}}" type="text/javascript"></script>
<!-- END FOOTER -->
