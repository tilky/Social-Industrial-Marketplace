<p style="font-family: 'Open Sans', Helvetica, Arial, 'Lucida Grande', sans-serif; font-size: 15px; line-height: 2em; color: #111111; font-weight: 400; margin: 0px auto 10px; padding: 0 0px;">
                - Indy John Team</p> <br>

          </div>
           

            <p style="border-top: 1px solid #ff0000;font-family: 'Open Sans', 'Helvetica',Helvetica,Arial,sans-serif;font-size: 14px;font-weight: normal;line-height: 1.6em;margin: 0 0 0px;padding: 5px 0px 0;text-align: center;">
               <b>Industrial:</b>  <a href="app.indyjohn.com/user-dashboard" style="text-decoration:none;" >Quote-Lead System</a>  |  <a href="app.indyjohn.com/marketplaceproduct/search" style="text-decoration:none;">I J Market</a> |  <a href="app.indyjohn.com/user-dashboard" style="text-decoration:none;">Search Discovery</a>  |  <a href="app.indyjohn.com/jobs/search" style="text-decoration:none;">Job Board</a> </p>
              

 <p style="font-family: 'Open Sans', 'Helvetica',Helvetica,Arial,sans-serif;font-size: 12px;font-weight: normal;line-height: 1em;margin: 0 0 10px;padding: 5px 10px 0;text-align: center;">
 <br/>Refer and Earn Payouts. <a href="http://cryptdata.com/qt/referral-program">Learn More</a>
</p>
           
        </div>
       

    </td>
    <td style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;"></td>
</tr></table>

<table class="footer-wrap" bgcolor="fbf6f6"  style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; clear: both !important; width: 100%; margin: 0; padding: 0;"><tr style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
    <td style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;"></td>
    <td class="container" style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; clear: both !important; display: block !important; max-width: 600px !important; margin: 0 auto; padding: 0;">


        <div class="content" style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; display: block; max-width: 600px; margin: 0 auto; padding: 0;">
            <table style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; width: 100%; margin: 0; padding: 0;"><tr style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
                <td align="center" style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
                    <p style="text-align: center;font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 12px; line-height: 1.6em; color: #666666; font-weight: normal; margin: 0 0 10px; padding: 0;"><a href="#" style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; color: #999999; margin: 0; padding: 0;">Click here</a> to Manage Your E-mail Subscriptions</a>.
                    <br/><br/>
                        Made with ❤ in Los Angeles. <br> Write to us at: P.O.BOX 86023 Los Angeles, CA 90086-0023
                    </p>
                </td>
            </tr></table>
        </div>
   

    </td>
    <td style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;"></td>
</tr></table>
<!--E-mail FOOTER ENDS-->
</body>
</html>
