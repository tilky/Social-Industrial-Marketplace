@extends('buyer.app')

@section('content')
<style>
.content-img{width: 97%!important;}
.owl-item{padding: 0px 10px!important;}
.test_descri{font-size: 18px;}
.thumbnail{position: relative;}
.white_carasoul .owl-pagination{margin-top: 20px!important;}
.section {padding: 75px 0 100px!important;}
</style>
<link href="{{URL::asset('public/metronic/pages/css/profile.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/pages/css/invoice-2.min.css')}}" rel="stylesheet" type="text/css" />

<link href="{{URL::asset('public/css/style_custom.css')}}" rel="stylesheet">
<link href="{{URL::asset('public/js/owl-carousel/owl.carousel.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{URL::asset('public/css/animations.css')}}" type="text/css">
    <link rel="stylesheet" href="{{URL::asset('public/css/prettyPhoto.css')}}">
    
    <link rel="stylesheet" href="{{URL::asset('public/css/owl.theme.css')}}">
    <link rel="stylesheet" type="text/css" href="{{URL::asset('public/css/ng_responsive_tables.css')}}">
<style>
.invoice-content-2{padding: 0px!important;}
.list-inline>li{padding: 0px!important;}
.padding-right-20{padding-right: 20px!important;}
.btn_org-silver {
background: #c0c0c0 none repeat scroll 0 0;
border: 2px solid transparent;
border-radius: 10px;
box-shadow: 0 0 1px rgba(0, 0, 0, 0);
display: inline-block;
font-family: "Raleway",sans-serif;
font-size: 20px;
font-weight: 500;
overflow: hidden;
padding: 5px 30px;
position: relative;
text-transform: uppercase;
transform: translateZ(0px);
transition: all 0.3s ease-in 0s;
width: 100%;
margin-top: 5px;
color: #000!important;
}
</style>    
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url('user-dashboard')}}">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>User</span>
        </li>
    </ul>
</div>
<div class="row">
    <div class="col-md-12 paddin-npt">
        @if (Session::has('message'))
            <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
        @endif
        <!-- BEGIN PROFILE CONTENT -->
        <div class="invoice-content-2 bordered">
            <div class="section fade">
                <div class="container">
                    <div class="col-md-3 text-center profile_info">
                        <div class="relative">
                            <div class="profile" style="margin-top: 0px!important;">
                                @if($user->userdetail->profile_picture != '')
                                <img src="{{url('')}}/{{$user->userdetail->profile_picture}}"> 
                                @else
                                <img src="{{url('public/images/default-user.png')}}" width="80px">
                                @endif
                                @if($user->quotetek_verify == 1)<div class="check"><img src="{{URL::asset('public/images/check.png')}}"/></div>@endif
                            </div> 
                        </div>
                        <h5> 
                            @if($user->star == 'gold')
                            <a href="" class="btn_org-semib">GOLD MEMBER</a>
                            @elseif($user->star == 'silver')
                            <a href="" class="btn_org-silver silver-member">SILVER MEMBER</a>
                            @else
                            <a href="" class="btn_org-silver free-member">FREE MEMBER</a>
                            @endif
                        </h5>
                        <h5 class="caps-on"> @if($user->quotetek_verify == 1) VERIFIED @else Not Verified @endif </h5>  
                        <!--<h5>Member Since {!! $user->created_at->diffForHumans() !!}</h5>-->
                        <ul class="list-inline profile_num">
                            <li class="padding-left" style="padding: 0px 14px!important;"> <img src="{{URL::asset('public/images/cmnt_icon.png')}}" alt=""> {{$user->message_count}}</li>
                            <li class="padding-left" style="padding: 0px 14px!important;"> <img src="{{URL::asset('public/images/hrt_icon.png')}}" alt=""> {{$user->endorse_count}}</li>
                            <li class="padding-left" style="padding: 0px 14px!important;"> <img src="{{URL::asset('public/images/star_icon.png')}}" alt=""> {{$user->review_count}}</li> 
                        </ul>
                        
                    </div>          
                    <div class="col-md-9 company_info">  
                        <div class="profilehome"> 
                            <!-- Nav tabs -->
                            
                            <!-- Tab panes  inner-->
                            <div class="tab-content tab_content"> 
                                <div role="tabpanel" class="tab-pane active" id="tab_one">
                                    <ul class="nav nav-tabs  btn_industry" role="tablist">
                                    @if($user->userdetail->getUserIndustry)
                                    <li role="presentation" class="active"><a href="javascript:void(0)" aria-controls="home" role="tab" data-toggle="tab">{{$user->userdetail->getUserIndustry->name}}</a></li>
                                    @endif
                                    @foreach($user->userIndustries as $indIndex=>$industry)
                                        @if($indIndex == 0)
                                        <li role="presentation"><a href="javascript:void(0)" aria-controls="home" role="tab" data-toggle="tab">{{$industry->IndustryData->name}}</a></li>
                                        @else
                                        <li role="presentation"><a href="javascript:void(0)" aria-controls="home" role="tab" data-toggle="tab">{{$industry->IndustryData->name}}</a></li>
                                        @endif
                                    @endforeach
                                    
                                    </ul>
                                    <h3 class="header_36" style="color:#ef5350;">{{$user->userdetail->first_name}} {{$user->userdetail->last_name}}</h3>
                                    @if($user->userdetail->current_position != '')<h3 class="header_18">{{$user->userdetail->current_position}} @if($user->company)at {{$user->company->name}}@endif</h3>@endif                        
                                    
                                    
                                    @if($user->userdetail->profile_slogan != '')<h3 class="header_24">{{$user->userdetail->profile_slogan}}. &nbsp; &nbsp; <i><img src="{{URL::asset('public/images/edit.png')}}"/></i></h3>@endif 
                                    {{$user->userdetail->about}}
                                    <div class="margintop15">
                                        <ul class="list-inline">
<li class="header_18 font-18" style="width: 100%;"><i><img src="{{URL::asset('public/images/degree.png')}}"/></i> Indy John UserID: IJU-125221</li
                                        <li class="header_18 font-18" style="width: 100%;"><i><img src="{{URL::asset('public/images/map.png')}}"/></i> TEST TEST TEST TEST </li>
<li class="header_18 font-18" style="width: 100%;"><i><img src="{{URL::asset('public/images/degree.png')}}"/></i> Indy John UserID: IJU-125221</li
                                        <li class="header_18 font-18" style="width: 100%;"><i><img src="{{URL::asset('public/images/map.png')}}"/></i> {{$user->userdetail->city}},{{$user->userdetail->state}},{{$user->userdetail->country}} </li>
                                        @if($user->education != '')<li class="header_18 font-18" style="width: 100%;"><i><img src="{{URL::asset('public/images/degree.png')}}"/></i> {{$user->education->degree}},{{$user->education->institute_name}}({{date('Y',strtotime($user->education->date_received))}})</li>@endif
                                        </ul>
                                        
                                     </div>
                                     
                                </div>
                                <div role="tabpanel" class="tab-pane" id="tab_two"> 
                                    <h3 class="header_36">@if($user->userdetail->getUserIndustry){{$user->userdetail->getUserIndustry->name}}@endif</h3>       
                                </div>
                                <div role="tabpanel" class="tab-pane" id="tab_three"> 
                                    <h3 class="header_36">Additional Industries</h3>  
                                    @if(count($user->userIndustries) > 0)
                                        <p>
                                        @foreach($user->userIndustries as $indIndex=>$industry)
                                            @if($indIndex == 0)
                                            {{$industry->IndustryData->name}}
                                            @else
                                            , {{$industry->IndustryData->name}}
                                            @endif
                                        @endforeach
                                        </p>
                                    @else
                                    <p>No Industry found</p>
                                    @endif
                                </div>
                            </div> 
                        </div>    
                    </div>
                    <div class="col-md-12">
                        <div class="col-md-3">
                            <ul class="list-inline profile_social">
                                <li><a href="{{$user->userdetail->facebook_url}}" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="{{$user->userdetail->insta_url}}" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="{{$user->userdetail->pintress_url}}" target="_blank"><i class="fa fa-pinterest-p"></i></a></li>
                                <li><a href="{{$user->userdetail->youtube_url}}" target="_blank"><i class="fa fa-youtube"></i></a></li>
                            </ul>
                        </div>
                        <div class="col-md-9">
                            <ul class="list-inline button_section_pro padding-top" style="margin-top: 10px;">
                                <li style="padding-right: 20px!important;"><a href="javascrip:void(0);" class="btn">ENDORSE</a></li>
                                <li style="padding-right: 20px!important;"><a href="javascrip:void(0);" class="btn">REQUEST QUOTE</a></li>
                                <li style="padding-right: 20px!important;"><a href="javascrip:void(0);" class="btn">CONTACT</a></li>
                            </ul>
                        </div>
                    </div>       
                </div> 
            </div>
            
            <!-- company details -->
            @if($user->company->name != '')
            <div class="border-section"> </div>
            <div class="section company_info padding-top">
                
                <div class="container"> 
                <!-- Tab panes -->
                    <div class="tab-content tab_content section"> 
                        <div role="tabpanel" class="tab-pane active" id="home"> 
                            <div class="relative col-md-3 text-center profile_info">
                            
                            <div class="uploadimage">
                                @if($company->logo != '')
                                <img src="{{url('/')}}/{{$company->logo}}"> 
                                @else
                                <img src="{{url('public/images/default-user.png')}}" width="80px">
                                @endif
                            </div>
                            @if($company->star == 'gold')
                            <h5> <a href="" class="btn_org-semib gold-member caps-on">GOLD MEMBER</a></h5>
                            @elseif($company->star == 'silver')
                            <h5> <a href="" class="btn_org-semib silver-member caps-on">SILVER MEMBER</a></h5>
                            @else
                            <h5> <a href="" class="btn_org-semib free-member caps-on">FREE MEMBER</a></h5>
                            @endif
                            
				            <h5> 
                                @if($company->user->quotetek_verify == 1)
                                <a href="" class="btn_gry-semib verify-member font-12 caps-on">VERIFIED</a>
                                @else
                                <a href="" class="btn_gry-semib verify-member font-12 caps-on">NOT VERIFIED</a>
                                @endif
                            </h5>
                            <ul class="list-inline profile_num">
                               <li style="padding: 0px 14px!important;"> <img src="{{url('public/images/cmnt_icon.png')}}" alt=""> {{count($company->user->messages)}}</li>
                                <li style="padding: 0px 14px!important;"> <img src="{{url('public/images/hrt_icon.png')}}" alt=""> {{count($company->user->endorsements)}}</li>
                                <li style="padding: 0px 14px!important;"> <img src="{{url('public/images/star_icon.png')}}" alt=""> {{count($company->user->reviews)}}</li> 
                            </ul>
                            
                            </div>    
                        
                        
                            <div class="col-md-9">  
                            <div class="profilehome"> 
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs btn_industry" role="tablist">
                                @foreach($company->industries as $index=>$industry)
                                    @if($index == 0)
                                    <li role="presentation" class="active"><a href="#tab_one_company" aria-controls="home" role="tab" data-toggle="tab" class="btn">{{$industry->industry->name}}</a></li>
                                    @else
                                    <li role="presentation"><a href="#tab_one_company" aria-controls="home" role="tab" data-toggle="tab" class="btn">{{$industry->industry->name}}</a></li>
                                    @endif
                                @endforeach
                            </ul>
                            
                            <!-- Tab panes  inner-->
                            <div class="tab-content tab_content"> 
                                <div role="tabpanel" class="tab-pane active" id="tab_one_company">
                                    <h3 class="header_36">{{$company->name}}</h3>
                                    <h3 class="header_18">{{$company->city}}, {{$company->state}}, {{$company->country}}</h3>                        
                                    <h3 class="header_19">About {{$company->name}}</h3> 
                                    {{$company->description}} 
                                    <h3 class="header_19">Established: {{$company->establishment_year}}. Joined Quotetek: {{date('Y',strtotime($company->created_at))}}</h3>    
                                </div>
                                
                                
                                <div role="tabpanel" class="tab-pane" id="tab_two_company"> 
                                <h3 class="header_36">Industrie</h3>     
                                    @if($company->industries)
                                        @foreach($company->industries as $index=>$industry)
                                            @if($index == 0)
                                            {{$industry->industry->name}}
                                            @else
                                            ,{{$industry->industry->name}}
                                            @endif
                                        @endforeach
                                    @else
                                    No industry found
                                    @endif   
                                </div>
                                
                                </div> 
                                </div>    
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-3">
                                    <ul class="list-inline profile_social">
                                        <li><a href="{{$company->facebook_url}}" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="{{$company->insta_url}}" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                        <li><a href="{{$company->pintress_url}}" target="_blank"><i class="fa fa-pinterest-p"></i></a></li>
                                        <li><a href="{{$company->youtube_url}}" target="_blank"><i class="fa fa-youtube"></i></a></li>
                                    </ul>
                                </div>
                                <div class="col-md-9">
                                    <ul class="list-inline button_section_pro padding-top" style="margin-top: 3px;">
                                        <!--<li><a href="{{url('companies')}}/{{$company->id}}" class="btn">VIEW PROFILE</a></li>-->
                                        <li class="padding-right-20" style="padding-right: 20px!important;"><a href="{{url('endorse-user')}}/{{Auth::user()->id}}/{{$company->user_id}}" class="btn">ENDORSE</a></li>
                                        <li class="padding-right-20" style="padding-right: 20px!important;"><a href="javascript:void(0)" class="btn">REQUEST QUOTE</a></li>
                                        <li class="padding-right-20" style="padding-right: 20px!important;"><a href="{{url('messages/create')}}?buyer={{$company->user_id}}" class="btn">CONTACT</a></li>
                                    </ul>
                                </div>
                            </div>  
                        </div>
                    </div>
                
                </div>
            
            </div>
            @endif
            <!-- end company details-->
            
            <!-- categorie and marketplace -->
            @if(count($user->userCategories) > 0)
            <div class="border-section"> </div>
            <div class="section fade">
                <div class="container "> 
                    <div class="product_section fade catagorysec">
                        <h3 class="header_middle text-center">Categories & Products Offered ({{count($user->userCategories)}})</h3>
                        @foreach($user->userCategories as $category)
                        <div class="col-md-3">
                            <ul class="list-unstyled">
                                <li>{{$category->CategoryData->name}}</li>
                            </ul> 
                        </div>
                        @endforeach
                        <!--<div class="text-center"><a href="#" class="btn btn-circle btnspace_pro">View More</a></div>-->
                    </div>
                </div>
            </div>
            @endif
            
            <!-- marketplace products -->
            @if(count($products) > 0)
            <div class="border-section"> </div>
            <div class="section fade padding-top">
                <div class="container "> 
                    <div class="clearfix"></div>
                    <div class="fade text-center new_pro">
                        <h3 class="header_middle">Indy John Market Listings ({{count($user->marketplaceProducts)}})</h3>
                        <div class="owl-carousel product_demo">
                            @if(count($products) > 0)
                                @foreach($products as $product)
                                <div class="thumbnail align-left">
            						<a href="{{url('marketplaceproducts')}}/{{$product->id}}">
                                        <img alt="Bootstrap Thumbnail First" src="{{url('public/marketplace/product/images')}}/{{$product->image}}" alt="{{ $product->name }}" title="{{ $product->name }}" style="height: 275px;" />
                                    </a>
            						@if($product->star != 'none')<i class="fa fa-star user-star @if($product->star == 'gold') gold-star @else silver-star @endif" aria-hidden="true"></i>@endif
            						<div class="user-img-thumb">
                                        <a class="pull-left" href="{{url('home/user/profile')}}/{{$product->user->id}}" target="_blank">
                                        @if($product->user->userdetail->profile_picture != '')
                                        <img src="{{url('')}}/{{$product->user->userdetail->profile_picture}}" style="width: 100%;"> 
                                        @else
                                        <img src="{{url('public/images/default-user.png')}}" style="width: 100%;">
                                        @endif
                                        </a>
                                    </div>
            						<div class="content-img">
            						<span>NEW</span>
            						<div class="col-md-8 col-xs-8"><span class="fa fa-map-marker"></span> {{$product->location_city}}</div>
            						<div class="col-md-4 col-xs-4 text-right">${{$product->price}}</div>
            						
            						</div>
            						<div class="caption">
            							<h3>
            								{{$product->name}} 
            							</h3>
            							<h5>{{$product->brand_name}} | {{$product->model_number}}</h5>
            							<h4>
                                            @foreach($product->categories as $index=>$category)
                                                @if($index < 5)
                                                    @if($index == 0)
                                                    {{$category->category->name}}
                                                    @else
                                                    ,{{$category->category->name}}
                                                    @endif
                                                @endif
                                            @endforeach
                                        </h4>
            							<p>
            								{{$product->user->userdetail->first_name}} {{$product->user->userdetail->last_name}}@if($product->user->company) - {{$product->user->company->name}}@endif
            							</p>
            							
            						</div>
            					</div>
                                @endforeach
                            @else
                            <p>No Product Available</p>
                            @endif
                        </div>  
                        <div class="clearfix"></div>
                        <!--<div class="text-center margintop15"><a href="#" class="btn btn-circle btnspace_pro">View More</a></div>-->
                    </div>
                </div>
            </div>
            @endif
            <!-- end -->
            
            <!-- industries services -->
            @if(count($user->techServices) > 0)
            <div class="border-section"> </div>
            <div class="section fade new_pro">
                <div class="container "> 
                    <div class="product_section fade catagorysec">
                        <h3 class="header_middle text-center">Industrial Services ({{count($user->techServices)}})</h3>
                        @foreach($user->techServices as $techService)
                        <div class="col-md-3">
                            <ul class="list-unstyled">
                                <li><a href="" class="category-names">{{$techService->techService->name}}</a></li>
                            </ul> 
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
            @endif
            <!-- end -->
            
            <!--- Reviews Section -->
            @if(count($reviews) > 0)
            <div class="border-section"> </div>
            <div class=" fade section">
                <div class="process" style="background-image:url({{url('public/images/testi_bg.jpg')}}); ">
                    <div class="colored_bg section text-center testi_sec">
                        <div class="container"> 
                            <div class="owl-carousel" id="testimonial">
                                @foreach($reviews as $index=>$review)
                                    <div class="items">
                                        <h3 class="header_middle text-center pb30">Reviews @if($review->review != 0)({{$review->review}})@endif</h3> 
                                        <div class="testi_profile">
                                            @if($review->sender_avatar != '')
                                            <img src="{{url('')}}/{{$review->sender_avatar}}">
                                            @else
                                            <img src="{{url('public/images/default-user.png')}}" alt="sell" class="img-circle" width="80px">
                                            @endif
                                        </div>
                                        <div class="client_name">{{$review->sendername}}</div>
                                        <div class="client_name" style="font-size: 15px;">@if($review->user->userdetail->current_position != ''){{$review->user->userdetail->current_position}} @if($review->user->company)at {{$review->user->company->name}}@endif @endif</div>
                                        <div class="date_des">
                                          <span class="pull-left">{{$review->senderfrom}}</span>
                                            <span class="pull-right">{{date('m/d/Y',strtotime($review->created_at))}}</span>
                                        </div>
                                        <div class="test_descri">{{$review->comment}}</div>
                                        <!--<div class="test_btn"><a href="" class="btn">view more</a></div>-->
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            <!-- End Reviews --> 
            @if(count($user->userJobs) > 0)
            <div class="border-section"> </div>
            <div class="section fade padding-top">
                <div class="container">
                    <!-- Employeement -->
                    <h3 class="header_middle text-center">Employment History</h3>
                    <div class="table-responsive table_section">
                        <table class="table table-bordered responsive">
                            <tr>
                                <th>Company Name</th>
                                <th>Position Held</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Company Location</th>
                            </tr>
                             @foreach($user->userJobs as $job)
                                <tr>
                                <td>{{$job->company_name}}</td>
                                <td>{{$job->job_title}}</td>
                                <td>{{$job->date_from}}</td>
                                @if($job->current != '')
                                <td>{{$job->current}}</td>
                                @else
                                <td>{{$job->date_to}}</td>
                                @endif
                                <td class="iconfield"><i  class="mapicon"></i> <h5 style="margin-top: 15px;font-size: 16px;">{{$job->location}}</h5></td>
                                </tr>
                            @endforeach
                        </table>
                    </div> 
                </div>
            </div>
            @endif
            <!-- end -->
            @if(count($user->userEducationDetails) > 0)
            <div class="border-section"> </div>
            <div class="section fade padding-top">
                <div class="container">
                    <!-- Education -->
                    <h3 class="header_middle text-center">Education History</h3> 
                    <div class="table-responsive table_section">
                        <table class="table table-bordered responsive">
                            <tr>
                                <th>Degree Title</th>
                                <th>Institution Name</th>
                                <th>Location</th>
                                <th>Date Received</th>
                            </tr>
                            @foreach($user->userEducationDetails as $education)
                            <tr>
                                <td>{{$education->degree}}</td>
                                <td class="iconfield"><i  class="mapicon"></i> <h5 style="margin-top: 15px;font-size: 16px;">{{$education->institute_name}}</h5> </td>
                                <td>{{$education->location}}</td>
                                @if($education->current != '')
                                <td>{{$education->current}}</td>
                                @else
                                <td>{{$education->date_received}}</td>
                                @endif
                            </tr>
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
            @endif
            <!-- end -->
            
            @if(count($user->userCertifications) > 0)
            <div class="border-section"> </div>
            <div class="section fade padding-top">
                <div class="container">
                    <!-- Certification -->
                    <h3 class="header_middle text-center">Certifications & Licenses</h3>
                    <div class="table-responsive table_section">
                        <table class="table table-bordered responsive">
                            <tr>
                                <th>Certifications Name</th>
                                <th>Certifying authority</th>
                                <th>Received</th>
                                <th>Valid Till</th>
                            </tr>
                            @foreach($user->userCertifications as $certification)
                            <tr>
                                <td>{{$certification->certification_name}}</td>
                                <td>{{$certification->certifying_authority}}</td>
                                <td>{{$certification->date_received}}</td>
                                <td>
                                    @if(strtotime($certification->valid_till) == 0)
                                        N/A
                                    @else
                                    {{$certification->valid_till}}
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
            @endif
            <!-- End -->
            
            @if(count($user->userAwards) > 0) 
            <div class="border-section"> </div>
            <div class="section fade padding-top">
                <div class="container">
                    <!-- Award -->
                    <div class="margintop40">
                        <h3 class="header_middle text-center">Awards & Honors</h3>
                        
                        <div class="table-responsive table_section">
                            <table class="table table-bordered responsive">
                                <tr>
                                    <th>Award / Honor Name</th>
                                    <th>Issuing authority</th>
                                    <th>Location</th>
                                    <th>Received Date</th> 
                                </tr>
                                @foreach($user->userAwards as $award)
                                <tr>
                                    <td>{{$award->awards_name}}</td>
                                    <td>{{$award->awarding_authority}}</td>
                                    <td class="iconfield"><i class="mapicon"></i> <h5 style="margin-top: 15px;font-size: 16px;">{{$award->location}}</h5></td>
                                    <td>{{$award->date_received}}</td> 
                                </tr>
                                @endforeach
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            <!-- end -->
            @if(count($user->userMemberOrganizations) > 0)
            <div class="border-section"> </div>
            <div class="section fade padding-top">
                <div class="container">
                    <!-- member org -->
                    <h3 class="header_middle text-center">Member Organizations</h3> 
                    <div class="table-responsive table_section">
                        <table class="table table-bordered responsive">
                            <tr>
                                <th>Position Held</th>
                                <th>Organization Name</th>
                                <th>Member Since</th>
                                <th>Valid Till</th>
                            </tr>
                            @foreach($user->userMemberOrganizations as $member)
                            <tr>
                                <td>{{$member->postion}}</td>
                                <td class="iconfield"><i  class="mapicon"></i><h5 style="margin-top: 15px;font-size: 16px;">{{$member->membership_organization}}</h5></td>
                                <td>{{$member->member_since}}</td>
                                <td>
                                    @if(strtotime($member->valid_till) == 0)
                                        N/A
                                    @else
                                    {{$member->valid_till}}
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
            @endif
            <!-- end -->
                
            
            <!-- Endorsements -->
            @if(count($endorsements) > 0)
            <div class="border-section"> </div>
            <div class="section fade">
                <h3 class="header_middle text-center pb30">Meet the Endorsers</h3>
                <div class="text-center white_carasoul">
                    <div class="container">  
                        <div class="owl-carousel profileslider">
                            @foreach($endorsements as $index=>$endorsement)
                            <div class="items"> 
                                <div class="testi_profile">
                                    @if($endorsement->sender_avatar != '')
                                    <img src="{{url('')}}/{{$endorsement->sender_avatar}}" alt="sell" class="img-circle" width="60px">
                                    @else
                                    <img src="{{url('public/images/default-user.png')}}" alt="sell" class="img-circle" width="80px">
                                    @endif
                                </div> 
                                <div class="client_name">{{$endorsement->sendername}}</div> 
                                @if($endorsement->user->userdetail->current_position != '')<div style="font-size: 15px;">{{$endorsement->user->userdetail->current_position}} </div>@endif
                                @if($endorsement->user->company)<div style="font-size: 15px;"> <b>{{$endorsement->user->company->name}} </b></div>@endif
                            </div>
                            @endforeach
                        </div>
                        <div class="clearfix"></div>  
                    </div>
                </div>
            </div>
            @endif
            <!-- end endorsement --> 
             
            <!-- Coworkers -->
            @if(!empty($coworkers))  
            <div class="border-section"> </div>    
            <div class="section fade">
                <div class="process" style="background-image:url({{url('public/images/testi_bg.jpg')}}); ">
                    <div class="colored_bg section text-center testi_sec">
                        <div class="container"> 
                            <h3 class="header_middle text-center pb30 paddin-bottom">Coworkers</h3>
                            <div class="text-center white_carasoul red_text no_btn">
                                <div class="container">  
                                    <div class="owl-carousel profileslider">
                                        @foreach($coworkers as $coworker)
                                        <div class="items"> 
                                            <div class="testi_profile">
                                                @if($coworker['profile_picture'] != '')
                                                <img src="{{url('')}}/{{$coworker['profile_picture']}}">
                                                @else
                                                <img src="{{url('public/images/default-user.png')}}" width="80px">
                                                @endif
                                            </div> 
                                            <div class="client_name">{{$coworker['first_name']}} {{$coworker['last_name']}}</div>
                                        </div>
                                        @endforeach
                                    </div>
                                    <div class="clearfix"></div>  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            <!-- end Coworkers -->    
              
            <!-- Network Adds -->
            @if(count($contacts) > 0)  
            <div class="border-section"> </div> 
            <div class="section fade "> 
                <h3 class="header_middle text-center pb30 paddin-bottom">Recent Connections</h3>
                <div class="text-center white_carasoul no_btn">
                    <div class="container">  
                        <div class="owl-carousel profileslider">
                            @foreach($contacts as $contact)
                                <div class="items"> 
                                    <div class="testi_profile">
                                        @if($contact->receiver->profile_picture != '')
                                        <img src="{{url('')}}/{{$contact->receiver->profile_picture}}" alt="sell" class="img-circle" width="60px">
                                        @else
                                        <img src="{{url('public/images/default-user.png')}}" alt="sell" class="img-circle" width="80px">
                                        @endif
                                    </div> 
                                    <div class="client_name">{{$contact->receiver->first_name}} {{$contact->receiver->last_name}}</div>
                                    @if($contact->user->userdetail->current_position != '')<div style="font-size: 15px;">{{$contact->user->userdetail->current_position}} @endif</div>
                                    @if($contact->user->company)<div style="font-size: 15px;"> {{$contact->user->company->name}}@endif </div>
                                </div>
                            @endforeach
                        </div> 
                        <div class="clearfix"></div>  
                    </div>
                </div> 
            </div>
            @endif
            <!-- end Networks Adds -->
            <div class="clearfix"></div>
        </div>    
        <!-- END PROFILE CONTENT -->
    </div>
</div>
<script>
$('#user-profile-view').addClass('active');
</script>
<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
     
    <script src="{{URL::asset('public/js/bootstrap.min.js')}}"></script>
    
    <script type="text/javascript" src="{{URL::asset('public/js/owl-carousel/owl.carousel.js')}}"></script>
       <script type="text/javascript" src="{{URL::asset('public/js/animate.js')}}"></script>
       <script type="text/javascript" src="{{URL::asset('public/js/ng_responsive_tables.js')}}"></script>
 
      <script> 
          $(document).ready(function() {
      $("#owl-demo").owlCarousel({ 
     items : 3,
      navigation : false,
      slideSpeed : 300,
      paginationSpeed : 500,
      singleItem : true,       
       autoPlay : true,
        pagination : false,
  });
  
  
    $("#testimonial").owlCarousel({ 
     navigation : true, // Show next and prev buttons
      pagination : false,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:true,
         navigationText : ["<img src='{{URL::asset('public/images/left_wh.png')}}' alt='' />", "<img src='{{URL::asset('public/images/rt_wh.png')}}' alt='' />"],
      
  });
  
    $(".product_demo").owlCarousel({ 
      navigation : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : false,  
      pagination : false,
       items : 3,
      itemsDesktop : [1199, 4],
        itemsDesktopSmall : [991, 3],
        itemsTablet : [768, 2],       
        itemsMobile : [479, 1],
         navigationText : ["<img src='{{URL::asset('public/images/left_arrow.png')}}' alt='' />", "<img src='{{URL::asset('public/images/right_arrow.png')}}' alt='' />"],
          
  });
  
      $(".profileslider").owlCarousel({ 
      navigation : false,
       pagination : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : false,  
       items : 4,
      itemsDesktop : [1199, 4],
        itemsDesktopSmall : [991, 3],
        itemsTablet : [768, 2],       
        itemsMobile : [479, 1],
       
          
  });
      
      
       $(".scrollar_btn").click(function(){
        $('html,body').animate({scrollTop: 630 }, 1000);     
    });
    
     $('.scrolltotop').hide();
    
     $(".scrolltotop").click(function(){
        $('html,body').animate({scrollTop: 0 }, 1000);     
    });
    
    
    
    $(window).scroll(function() {
    if ($(window).scrollTop() >= 500 ) {
     $('.scrolltotop').show('2000');   
    } else { 
         $('.scrolltotop').hide('2000'); 
    }
});
    
    
    
     $(function loop_charch() { 
     $(" .scrollar_btn btn-circle .circle").animate({height:50}, 1000)
       $(" .scrollar_btn btn-circle .circle").animate({height:40}, 1000,loop_charch);
       
   }); //loop_charch();
   
   
    });
    
    $(window).on("load",function() {
    function fade() {
        var animation_height = $(window).innerHeight() * 0.25;
        var ratio = Math.round( (1 / animation_height) * 10000 ) / 10000;

        $('.fade').each(function() {            
            var objectTop = $(this).offset().top;
            var windowBottom = $(window).scrollTop() + $(window).innerHeight();
            
            if ( objectTop < windowBottom ) {
                if ( objectTop < windowBottom - animation_height ) {
                  
                    $(this).css( {
                        transition: 'opacity 0.1s linear',
                        opacity: 1
                    } );

                } else {
                   
                    $(this).css( {
                        transition: 'opacity 0.25s linear',
                        opacity: (windowBottom - objectTop) * ratio
                    } );
                }
            } 
        }); 
        
    }
    $('.fade').css( 'opacity', 0 );
    fade();
    $(window).scroll(function() {fade();});
});
          
           
   
      $(window).load(function(){    
      if($(window).width() < 1600){
        $('.custom_nav').css({"padding-left":"20px",  "padding-right":"20px"});
      }
    });
     
     </script>
     
     <script type="text/javascript">
		$(function(){
		  $('table.responsive').ngResponsiveTables({
		  	smallPaddingCharNo: 13,
	    	mediumPaddingCharNo: 18,
	    	largePaddingCharNo: 30
		  });
		});
	</script>
     
     
     
     
      
   
  
     <script> 
 

 


$(document).ready(function() {


    
    
  $('li.dropdown').hover(function() {
$('ul.dropdown-menu', this).stop(true, true). fadeIn('fast', 'easeOutElastic');
$(this).addClass('open'); 
$(this).addClass('radius'); 
      }, function() {
$('ul.dropdown-menu', this).stop(true, true).fadeOut('fast', 'easeInElastic');
$(this).removeClass('open'); 
$(this).removeClass('radius'); 
      });
      
      $('.dropdown-menu').hover(function() { 
$(this).parent('li').stop(true, true).addClass('selectli');
 
      },function() { 
$(this).parent('li').stop(true, true).removeClass('selectli'); 
      });
   });



  </script>
  
 <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
 <script>
    $("#industry").autocomplete({
    source: ["Industry", "Boy", "Cat"],
    minLength: 0,
}).focus(function () {
    $(this).autocomplete("search");
});
 
   $("#catagory").autocomplete({
    source: ["Catgory", "Boy", "Cat"],
    minLength: 0,
}).focus(function () {
    $(this).autocomplete("search");
});

$('.infoeabout').click(function() {
   $('#autocomplete').trigger("focus"); //or "click", at least one should work
});

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
 
  </script>
   <script src="{{URL::asset('public/js/jquery.prettyPhoto.js')}}"></script>
 <script type="text/javascript" charset="utf-8">
			$(document).ready(function(){
			 
				
				$(".gallery:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal', social_tools: false});
				 
		 
				 
			});
			</script>
  
  
  <script type="text/javascript"> 
 
      
      $('input').bind('copy paste', function (e) {
        e.preventDefault();
    });
     
</script> 
@endsection
