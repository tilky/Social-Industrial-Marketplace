@extends('buyer.app')

@section('content')
<style>
.content-img{width: 97%!important;}
.slider{margin: 0px!important;}
.owl-item{padding: 0px 10px!important;}
.test_descri{font-size: 18px;}
.thumbnail{position: relative;}
.white_carasoul .owl-pagination{margin-top: 20px!important;}
.list-inline>li{padding: 0px!important;}
.invoice-content-2{padding: 0px!important;}
.padding-right-20{padding-right: 20px!important;}
.section {padding: 75px 0 100px!important;}
</style>
<link href="{{URL::asset('public/metronic/pages/css/profile.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/pages/css/invoice-2.min.css')}}" rel="stylesheet" type="text/css" />

<link href="{{URL::asset('public/css/style_custom.css')}}" rel="stylesheet">
<link href="{{URL::asset('public/js/owl-carousel/owl.carousel.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{URL::asset('public/css/animations.css')}}" type="text/css">
    <link rel="stylesheet" href="{{URL::asset('public/css/prettyPhoto.css')}}">
    
    <link rel="stylesheet" href="{{URL::asset('public/css/owl.theme.css')}}">
    <link rel="stylesheet" type="text/css" href="{{URL::asset('public/css/ng_responsive_tables.css')}}">
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url('user-dashboard')}}">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>User</span>
        </li>
    </ul>
</div>
<div class="row">
    <div class="col-md-12">
        @if (Session::has('message'))
            <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
        @endif
        <!-- BEGIN PROFILE CONTENT -->
        <div class="invoice-content-2 row bordered">
            <!-- Main Image -->
            <div class="slider inner_slide banner_form small_banner" @if($company->background_image != '') style="background-image: url({{url('')}}/{{$company->background_image}})" @else style="background-image: url({{url('public/images/banner_4.jpg')}})" @endif>
                <div class="slider_overlay">
                
                    <div class="container vericle_table animatedParent"> 
                        <div class="verticle_row">
                            <h1 class="banner_header">
                                @if($company->logo != '')
                                <img src="{{url('')}}/{{$company->logo}}" width="230" height="221" alt="{{$company->name}}" style="border-radius: 50%;"> 
                                @else
                                <img src="//www.gravatar.com/avatar/18051c749493cc76ad88dd94789cc74e?s=64">
                                @endif
                               <br/>  <span>{{$company->name}}</span> </h1>
                                @if($company->star == 'gold')
                                <a class="btn_org gold-member caps-on" href="">GOLD MEMBER</a>
                                @elseif($company->star == 'silver')
                                <a href="" class="btn_org silver-member caps-on">SILVER MEMBER</a>
                                @else
                                <a href="" class="btn_org free-member caps-on">FREE MEMBER</a>
                                @endif
                        </div> 
                    </div> 
                </div>
            </div>
            <div class="color_bg"> 
                    <div class="container"> 
                    </div>
                </div>
            <div class="section company_info padding-top">
                
                <div class="container"> 
                <!-- Tab panes -->
                    <div class="tab-content tab_content section"> 
                        <div role="tabpanel" class="tab-pane active" id="home"> 
                            <div class="relative col-md-3 text-center profile_info">
                            
                            <div class="uploadimage">
                                @if($company->logo != '')
                                <img src="{{url('/')}}/{{$company->logo}}"> 
                                @else
                                <img src="//www.gravatar.com/avatar/18051c749493cc76ad88dd94789cc74e?s=64">
                                @endif
                            </div>
                            @if($company->star == 'gold')
                            <h5> <a href="" class="btn_org-semib gold-member caps-on">GOLD MEMBER</a></h5>
                            @elseif($company->star == 'silver')
                            <h5> <a href="" class="btn_org-semib silver-member caps-on">SILVER MEMBER</a></h5>
                            @else
                            <h5> <a href="" class="btn_org-semib free-member caps-on">FREE MEMBER</a></h5>
                            @endif
                            
				            <h5> 
                                @if($company->user->quotetek_verify == 1)
                                <a href="" class="btn_gry-semib verify-member font-12 caps-on">VERIFIED</a>
                                @else
                                <a href="" class="btn_gry-semib verify-member font-12 caps-on">NOT VERIFIED</a>
                                @endif
                            </h5>
                            <ul class="list-inline profile_num">
                               <li style="padding: 0px 14px!important;"> <img src="{{url('public/images/cmnt_icon.png')}}" alt=""> {{count($company->user->messages)}}</li>
                                <li style="padding: 0px 14px!important;"> <img src="{{url('public/images/hrt_icon.png')}}" alt=""> {{count($company->user->endorsements)}}</li>
                                <li style="padding: 0px 14px!important;"> <img src="{{url('public/images/star_icon.png')}}" alt=""> {{count($company->user->reviews)}}</li> 
                            </ul>
                            
                            </div>    
                        
                        
                            <div class="col-md-9">  
                            <div class="profilehome"> 
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs btn_industry" role="tablist">
                                @foreach($company->industries as $index=>$industry)
                                    @if($index == 0)
                                    <li role="presentation" class="active"><a href="#tab_one_company" aria-controls="home" role="tab" data-toggle="tab" class="btn">{{$industry->industry->name}}</a></li>
                                    @else
                                    <li role="presentation"><a href="#tab_one_company" aria-controls="home" role="tab" data-toggle="tab" class="btn">{{$industry->industry->name}}</a></li>
                                    @endif
                                @endforeach
                            </ul>
                            
                            <!-- Tab panes  inner-->
                            <div class="tab-content tab_content"> 
                                <div role="tabpanel" class="tab-pane active" id="tab_one_company">
                                    <h3 class="header_36">{{$company->name}}</h3>
                                    <h3 class="header_18">{{$company->city}}, {{$company->state}}, {{$company->country}}</h3>                        
                                    <h3 class="header_19">About {{$company->name}}</h3> 
                                    {{$company->description}} 
                                    <h3 class="header_19">Established: {{$company->establishment_year}}. Joined Quotetek: {{date('Y',strtotime($company->created_at))}}</h3>    
                                </div>
                                
                                
                                <div role="tabpanel" class="tab-pane" id="tab_two_company"> 
                                <h3 class="header_36">Industrie</h3>     
                                    @if($company->industries)
                                        @foreach($company->industries as $index=>$industry)
                                            @if($index == 0)
                                            {{$industry->industry->name}}
                                            @else
                                            ,{{$industry->industry->name}}
                                            @endif
                                        @endforeach
                                    @else
                                    No industry found
                                    @endif   
                                </div>
                                
                                </div> 
                                </div>    
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-3">
                                    <ul class="list-inline profile_social">
                                        <li><a href="{{$company->facebook_url}}" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="{{$company->insta_url}}" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                        <li><a href="{{$company->pintress_url}}" target="_blank"><i class="fa fa-pinterest-p"></i></a></li>
                                        <li><a href="{{$company->youtube_url}}" target="_blank"><i class="fa fa-youtube"></i></a></li>
                                    </ul>
                                </div>
                                <div class="col-md-9">
                                    <ul class="list-inline button_section_pro padding-top" style="margin-top: 3px;">
                                        <!--<li><a href="{{url('companies')}}/{{$company->id}}" class="btn">VIEW PROFILE</a></li>-->
                                        <li class="padding-right-20" style="padding-right: 20px!important;"><a href="{{url('endorse-user')}}/{{Auth::user()->id}}/{{$company->user_id}}" class="btn">ENDORSE</a></li>
                                        <li class="padding-right-20" style="padding-right: 20px!important;"><a href="javascript:void(0)" class="btn">REQUEST QUOTE</a></li>
                                        <li class="padding-right-20" style="padding-right: 20px!important;"><a href="{{url('messages/create')}}?buyer={{$company->user_id}}" class="btn">CONTACT</a></li>
                                    </ul>
                                </div>
                            </div>  
                        </div>
                    </div>
                
                </div>
            
            </div>
            <!-- end -->
            
            <!-- showcase -->
            @if(count($company->gallery) > 0)
            <div class="border-section"> </div>
            <div class="section fade text-center">
               <h3 class="header_middle">Company Showcase</h3>
                <div class="photo_gallery gallery">
                   <div class="col-md-12 leftside_gal">  
                        <ul>
                            @foreach($company->gallery as $gallery)
                            <li>
                                <a href="{{url('public/uploads')}}/{{$gallery->path}}" class="hvr-rectangle-out" rel="prettyPhoto[gallery1]"><div class="viewmore"><h4>View Image</h4></div><img src="{{url('public/uploads')}}/{{$gallery->path}}"  alt="Photo Gallery"/></a>
                            </li>
                            @endforeach
                            
                        </ul>
                       
                      
                   </div>
                    
                   
               </div>
               <div class="clearfix"></div>
            </div>
            @endif
            <!-- end -->
            
            <!-- category and products -->
            @if(count($company->Categories) > 0)
            <div class="border-section"> </div>
            <div class="section fade">
                <div class="container "> 
                    <div class="product_section fade catagorysec">
                        <h3 class="header_middle text-center">Categories & Products Offered ({{count($company->Categories)}})</h3>
                        @foreach($company->Categories as $category)
                        <div class="col-md-3">
                            <ul class="list-unstyled">
                                <li>
                                    <a href="" class="category-names">
                                    @if(strlen($category->category->name) > 27)
                                    {{substr($category->category->name,0,27)}}...
                                    @else
                                    {{$category->category->name}}
                                    @endif
                                    </a>
                                </li>
                            </ul> 
                        </div>
                        @endforeach
                        <!--<div class="text-center"><a href="#" class="btn btn-circle btnspace_pro">View More</a></div>-->
                    </div>
                </div>
            </div>
            @endif
            
            @if(count($products) > 0)
            <div class="border-section"> </div>
            <div class="section fade">
                <div class="container "> 
                    <div class="clearfix"></div>
                    <div class=" fade text-center new_pro paddin-bottom">
                        <h3 class="header_middle">New Products</h3>
                        <div class="owl-carousel product_demo">
                            @if(count($products) > 0)
                                @foreach($products as $product)
                                <div class="thumbnail align-left">
            						<a href="{{url('marketplaceproducts')}}/{{$product->id}}">
                                        <img alt="Bootstrap Thumbnail First" src="{{url('public/marketplace/product/images')}}/{{$product->image}}" alt="{{ $product->name }}" title="{{ $product->name }}" style="height: 275px;" />
                                    </a>
            						@if($product->star != 'none')<i class="fa fa-star user-star @if($product->star == 'gold') gold-star @else silver-star @endif" aria-hidden="true"></i>@endif
            						<div class="user-img-thumb">
                                        <a class="pull-left" href="{{url('home/user/profile')}}/{{$product->user->id}}" target="_blank">
                                        @if($product->user->userdetail->profile_picture != '')
                                        <img src="{{url('')}}/{{$product->user->userdetail->profile_picture}}" style="width: 100%;"> 
                                        @else
                                        <img src="//www.gravatar.com/avatar/18051c749493cc76ad88dd94789cc74e?s=64" style="width: 100%;">
                                        @endif
                                        </a>
                                    </div>
            						<div class="content-img">
            						<span>NEW</span>
            						<div class="col-md-8 col-xs-8"><span class="fa fa-map-marker"></span> {{$product->location_city}}</div>
            						<div class="col-md-4 col-xs-4 text-right">${{$product->price}}</div>
            						
            						</div>
            						<div class="caption">
            							<h3>
            								{{$product->name}} 
            							</h3>
            							<h5>{{$product->brand_name}} | {{$product->model_number}}</h5>
            							<h4>
                                            @foreach($product->categories as $index=>$category)
                                                @if($index < 5)
                                                    @if($index == 0)
                                                    {{$category->category->name}}
                                                    @else
                                                    ,{{$category->category->name}}
                                                    @endif
                                                @endif
                                            @endforeach
                                        </h4>
            							<p>
            								{{$product->user->userdetail->first_name}} {{$product->user->userdetail->last_name}}@if($product->user->company) - {{$product->user->company->name}}@endif
            							</p>
            							
            						</div>
            					</div>
                                @endforeach
                            @else
                            <p>No Product Available</p>
                            @endif
                        </div>  
                        <div class="clearfix"></div>
                        <!--<div class="text-center margintop15"><a href="#" class="btn btn-circle btnspace_pro">View More</a></div>-->
                    </div>
                </div>
            </div>
            @endif
            <!-- end -->
            
            <!-- industries services -->
            @if(count($company->techServices) > 0)
            <div class="border-section"> </div>
            <div class="section fade new_pro">
                <h3 class="header_middle text-center">Industrial Services ({{count($company->techServices)}})</h3>
                @foreach($company->techServices as $techService)
                <div class="col-md-3">
                    <ul class="list-unstyled">
                        <li>
                            @if(strlen($techService->techService->name) > 27)
                            {{substr($techService->techService->name,0,27)}}...
                            @else
                            {{$techService->techService->name}}
                            @endif
                        </li>
                    </ul> 
                </div>
                @endforeach
            </div>
            @endif
            <!-- end -->
            
            <!--- Reviews Section -->
            @if(count($reviews) > 0)
            <div class="border-section"> </div>
            <div class="fade section">
                <div class="process" style="background-image:url({{url('public/images/testi_bg.jpg')}}); ">
                    <div class="colored_bg section text-center testi_sec">
                        <div class="container"> 
                            <div class="owl-carousel" id="testimonial">
                                @foreach($reviews as $index=>$review)
                                    <div class="items">
                                        <h3 class="header_middle text-center pb30">Company Reviews @if($review->review != 0)({{$review->review}})@endif</h3> 
                                        <div class="testi_profile">
                                            @if($review->sender_avatar != '')
                                            <img src="{{url('')}}/{{$review->sender_avatar}}">
                                            @else
                                            <img src="//www.gravatar.com/avatar/18051c749493cc76ad88dd94789cc74e?s=64" alt="sell" class="img-circle">
                                            @endif
                                        </div>
                                        <div class="client_name">{{$review->sendername}}</div>
                                        <div class="client_name" style="font-size: 15px;">@if($review->user->userdetail->current_position != ''){{$review->user->userdetail->current_position}} @if($review->user->company)at {{$review->user->company->name}}@endif @endif</div>
                                        <div class="date_des">
                                          <span class="pull-left">{{$review->senderfrom}}</span>
                                            <span class="pull-right">{{date('m/d/Y',strtotime($review->created_at))}}</span>
                                        </div>
                                        <div class="test_descri">{{$review->comment}}</div>
                                        <!--<div class="test_btn"><a href="" class="btn">view more</a></div>-->
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            <!-- End Reviews -->  
            
            <!-- Endorsements -->
            @if(count($endorsements) > 0)
            <div class="border-section"> </div>
            <div class="section fade">
                <h3 class="header_middle text-center pb30">Meet the Endorsers</h3>
                <div class="text-center white_carasoul">
                    <div class="container">  
                        <div class="owl-carousel profileslider">
                            @foreach($endorsements as $index=>$endorsement)
                            <div class="items"> 
                                <div class="testi_profile">
                                    @if($endorsement->sender_avatar != '')
                                    <img src="{{url('')}}/{{$endorsement->sender_avatar}}" alt="sell" class="img-circle" width="60px">
                                    @else
                                    <img src="//www.gravatar.com/avatar/18051c749493cc76ad88dd94789cc74e?s=64" alt="sell" class="img-circle">
                                    @endif
                                </div> 
                                <div class="client_name">{{$endorsement->sendername}}</div> 
                                @if($endorsement->user->userdetail->current_position != '')<div style="font-size: 15px;">{{$endorsement->user->userdetail->current_position}} </div>@endif
                                @if($endorsement->user->company)<div style="font-size: 15px;"> <b>{{$endorsement->user->company->name}} </b></div>@endif
                            </div>
                            @endforeach
                        </div>
                        <div class="clearfix"></div>  
                    </div>
                </div>
            </div>
            @endif
            
            <!-- end endorsement -->
            
            <!-- Company Co-workers -->
            @if(count($company->users) > 0)
            <div class="border-section"> </div>
            <div class="section fade">
                <div class="process" style="background-image:url({{url('public/images/testi_bg.jpg')}}); ">
                    <div class="colored_bg section text-center testi_sec">
                        <div class="container"> 
                        
                            <h3 class="header_middle text-center pb30">People who work at {{$company->name}}</h3>
                            
                            <div class="text-center white_carasoul red_text no_btn">
                                <div class="container">  
                                    <div class="owl-carousel profileslider">
                                        @foreach($company->users as $user)
                                        <div class="items"> 
                                            <div class="testi_profile">
                                                @if($user->profile_picture != '')
                                                <img src="{{url('')}}/{{$user->profile_picture}}">
                                                @else
                                                <img src="//www.gravatar.com/avatar/18051c749493cc76ad88dd94789cc74e?s=64">
                                                @endif
                                            </div> 
                                            <div class="client_name">{{$user->first_name}} {{$user->last_name}}</div> 
                                            <div>{{$user->current_position}}</div> 
                                        
                                        </div>
                                        @endforeach
                                    </div>
                                    
                                    <div class="clearfix"></div>  
                                </div>
                            </div>
                        
                        
                        </div>
                    </div>
                
                </div>
            </div>
            @endif
            <!-- end -->
            <!-- certification -->
            
            @if(count($company->companyCertifications) > 0)
            <div class="border-section"> </div>
            <div class="section fad">
                <h3 class="font42 fontnormal text-center">Certifications & Accreditations</h3> 
                <div class="table-responsive table_section">
                    <table class="table table-bordered responsive">
                        <tr>
                            <th>Certification Name</th>
                            <th>Issuing Authority</th>
                            <th>Received</th>
                            <th>Valid Till</th>
                        </tr>
                        @foreach($company->companyCertifications as $certification)
                        <tr>
                            <td>{{$certification->certification_name}}</td>
                            <td>{{$certification->certifying_authority}}</td>
                            <td>{{$certification->date_received}}</td>
                            <td>{{$certification->valid_till}}</td>
                        </tr>
                        @endforeach
                    </table>
                </div>
            </div>
            @endif
            <!-- end -->
            <div class="border-section"> </div>
            <!-- Additional -->
            <div class="section nopadding_bottom fade">
                <div class="process" style="background-image:url(images/company_info.jpg); ">
                    <div class="colored_bg section text-center company_info_des">
                        <div class="container"> 
                            <h3 class="header_36 text-center">Additional Information</h3>
                            <div class="info_col border_rt">
                                <ul class="list-unstyled">
                                    @if($company->employees_count != '')<li>Number of Employees</li>@endif
                                    @if($company->total_sales != '')<li>Estimated Annual Revenue</li>@endif
                                    @if($company->trade_capacity != '')<li>Total Trade Capacity</li>@endif
                                    @if($company->production_capacity != '')<li>Total Production Capacity</li>@endif
                                    @if($company->rAndD != '')<li>Total R&D Capacity</li>@endif
                                    @if($company->production_line_count != '')<li>Number of Production Lines</li>@endif
                                    @if(count($payment_str ) > 0)<li>Accepted Payment Currency</li>@endif
                                </ul>
                            </div>
                            <div class="info_col">
                                <ul class="list-unstyled">
                                    @if($company->employees_count != '')<li>{{$company->employees_count}}</li>@endif
                                    @if($company->total_sales != '')<li>{{$company->total_sales}}</li>@endif
                                    @if($company->trade_capacity != '')<li>{{$company->trade_capacity}}</li>@endif
                                    @if($company->production_capacity != '')<li>{{$company->production_capacity}}</li>@endif
                                    @if($company->rAndD != '')<li>{{$company->rAndD}}</li>@endif
                                    @if($company->production_line_count != '')<li>{{$company->production_line_count}}</li>@endif
                                    @if(count($payment_str ) > 0)<li>
                                        @foreach($payment_str as $index=>$payment)
                                            @if($index == 0)
                                                {{$payment}}
                                            @else
                                                ,{{$payment}}
                                            @endif
                                        @endforeach
                                    </li>@endif
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end -->
        </div>    
        <!-- END PROFILE CONTENT -->
    </div>
</div>
<script>
$('#user-profile-view').addClass('active');
</script>
<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
     
    <script src="{{URL::asset('public/js/bootstrap.min.js')}}"></script>
    
    <script type="text/javascript" src="{{URL::asset('public/js/owl-carousel/owl.carousel.js')}}"></script>
       <script type="text/javascript" src="{{URL::asset('public/js/animate.js')}}"></script>
       <script type="text/javascript" src="{{URL::asset('public/js/ng_responsive_tables.js')}}"></script>
 
      <script> 
          $(document).ready(function() {
      $("#owl-demo").owlCarousel({ 
     items : 3,
      navigation : false,
      slideSpeed : 300,
      paginationSpeed : 500,
      singleItem : true,       
       autoPlay : true,
        pagination : false,
  });
  
  
    $("#testimonial").owlCarousel({ 
     navigation : true, // Show next and prev buttons
      pagination : false,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:true,
         navigationText : ["<img src='{{URL::asset('public/images/left_wh.png')}}' alt='' />", "<img src='{{URL::asset('public/images/rt_wh.png')}}' alt='' />"],
      
  });
  
    $(".product_demo").owlCarousel({ 
      navigation : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : false,  
      pagination : false,
       items : 3,
      itemsDesktop : [1199, 4],
        itemsDesktopSmall : [991, 3],
        itemsTablet : [768, 2],       
        itemsMobile : [479, 1],
         navigationText : ["<img src='{{URL::asset('public/images/left_arrow.png')}}' alt='' />", "<img src='{{URL::asset('public/images/right_arrow.png')}}' alt='' />"],
          
  });
  
      $(".profileslider").owlCarousel({ 
      navigation : false,
       pagination : true,
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem : false,  
       items : 4,
      itemsDesktop : [1199, 4],
        itemsDesktopSmall : [991, 3],
        itemsTablet : [768, 2],       
        itemsMobile : [479, 1],
       
          
  });
      
      
       $(".scrollar_btn").click(function(){
        $('html,body').animate({scrollTop: 630 }, 1000);     
    });
    
     $('.scrolltotop').hide();
    
     $(".scrolltotop").click(function(){
        $('html,body').animate({scrollTop: 0 }, 1000);     
    });
    
    
    
    $(window).scroll(function() {
    if ($(window).scrollTop() >= 500 ) {
     $('.scrolltotop').show('2000');   
    } else { 
         $('.scrolltotop').hide('2000'); 
    }
});
    
    
    
     $(function loop_charch() { 
     $(" .scrollar_btn btn-circle .circle").animate({height:50}, 1000)
       $(" .scrollar_btn btn-circle .circle").animate({height:40}, 1000,loop_charch);
       
   }); //loop_charch();
   
   
    });
    
    $(window).on("load",function() {
    function fade() {
        var animation_height = $(window).innerHeight() * 0.25;
        var ratio = Math.round( (1 / animation_height) * 10000 ) / 10000;

        $('.fade').each(function() {            
            var objectTop = $(this).offset().top;
            var windowBottom = $(window).scrollTop() + $(window).innerHeight();
            
            if ( objectTop < windowBottom ) {
                if ( objectTop < windowBottom - animation_height ) {
                  
                    $(this).css( {
                        transition: 'opacity 0.1s linear',
                        opacity: 1
                    } );

                } else {
                   
                    $(this).css( {
                        transition: 'opacity 0.25s linear',
                        opacity: (windowBottom - objectTop) * ratio
                    } );
                }
            } 
        }); 
        
    }
    $('.fade').css( 'opacity', 0 );
    fade();
    $(window).scroll(function() {fade();});
});
          
           
   
      $(window).load(function(){    
      if($(window).width() < 1600){
        $('.custom_nav').css({"padding-left":"20px",  "padding-right":"20px"});
      }
    });
     
     </script>
     
     <script type="text/javascript">
		$(function(){
		  $('table.responsive').ngResponsiveTables({
		  	smallPaddingCharNo: 13,
	    	mediumPaddingCharNo: 18,
	    	largePaddingCharNo: 30
		  });
		});
	</script>
     
     
     
     
      
   
  
     <script> 
 

 


$(document).ready(function() {


    
    
  $('li.dropdown').hover(function() {
$('ul.dropdown-menu', this).stop(true, true). fadeIn('fast', 'easeOutElastic');
$(this).addClass('open'); 
$(this).addClass('radius'); 
      }, function() {
$('ul.dropdown-menu', this).stop(true, true).fadeOut('fast', 'easeInElastic');
$(this).removeClass('open'); 
$(this).removeClass('radius'); 
      });
      
      $('.dropdown-menu').hover(function() { 
$(this).parent('li').stop(true, true).addClass('selectli');
 
      },function() { 
$(this).parent('li').stop(true, true).removeClass('selectli'); 
      });
   });



  </script>
  
 <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
 <script>
    $("#industry").autocomplete({
    source: ["Industry", "Boy", "Cat"],
    minLength: 0,
}).focus(function () {
    $(this).autocomplete("search");
});
 
   $("#catagory").autocomplete({
    source: ["Catgory", "Boy", "Cat"],
    minLength: 0,
}).focus(function () {
    $(this).autocomplete("search");
});

$('.infoeabout').click(function() {
   $('#autocomplete').trigger("focus"); //or "click", at least one should work
});

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
 
  </script>
   <script src="{{URL::asset('public/js/jquery.prettyPhoto.js')}}"></script>
 <script type="text/javascript" charset="utf-8">
			$(document).ready(function(){
			 
				
				$(".gallery:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal', social_tools: false});
				 
		 
				 
			});
			</script>
  
  
  <script type="text/javascript"> 
 
      
      $('input').bind('copy paste', function (e) {
        e.preventDefault();
    });
     
</script> 
@endsection
