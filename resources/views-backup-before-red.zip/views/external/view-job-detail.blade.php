@extends('home.app')
@section('content')
@include('home.header')

<div class=" padding75">


    <div class="helpsection fade margintop20">
        <div class="col-md-12 col-sm-12 margin-top-30">
              <div class="portlet light portlet-fit product_details">
                <div class="portlet-title"> <a data-toggle="collapse" href="#job_details" aria-expanded="" class="caption-subject">
                  <h3 class="font-red-mint pull-left">Job Details</h3>
                  <i class="fa fa-2x fa-plus pull-right"></i>
                  <div class="clearfix"></div>
                  </a> </div>
                <div class="all_details collapse in" id="job_details" aria-expanded="true">
                  <div class="col-md-12">
                    <div class="row">
                      


                      <div class="col-md-12 border_top border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                            <h4>Company:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">


                            <h4> <a target="_blank" href="{{url('company/profile')}}/{{$user->company->id}}">{{$user->company->name}}</a> </li> </h4>
                          </div>
                        </div>
                      </div>
                      




                      @if($job->job_type_function != '')
                      <div class="col-md-12 border_top border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                            <h4>Position:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">
                            <h4>{{$job->job_type_function}}</h4>
                          </div>
                        </div>
                      </div>
                      @endif
                      
                      @if($job->job_type != '')
                      <div class="col-md-12 margin-top-15 border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                            <h4>Job Type:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">
                            <h4>{{$job->job_type}}</h4>
                          </div>
                        </div>
                      </div>
                      @endif
                      
                      @if($job->job_position_title != '')
                      <div class="col-md-12 margin-top-15 border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                            <h4>Title:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">
                            <h4>{{$job->job_position_title}}</h4>
                          </div>
                        </div>
                      </div>
                      @endif
                      
                      <div class="col-md-12 margin-top-15 border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                          <h4>Location:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">
                            @if($job->does_not_apply == 1)
                                <h4>Does not Apply</h4>
                            @else
                            <h4>{{$job->city}},{{$job->state}},{{$job->country}}</h4>
                            @endif
                          </div>
                        </div>
                      </div>
                      
                      <div class="col-md-12 margin-top-15 border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                            <h4>Travel Required:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">
                            @if($job->travel_required == 1)
                                <h4>{{$job->how_often}}</h4>
                            @else
                            <h4>Not Required</h4>
                            @endif
                          </div>
                        </div>
                      </div>
                      
                      @if($job->compensation_type != '')
                      <div class="col-md-12 margin-top-15 border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                            <h4>Compensation Type:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">
                            <h4>{{$job->compensation_type}}</h4>
                          </div>
                        </div>
                      </div>
                      @endif
                      
                      @if($job->compensation_range != '')
                      <div class="col-md-12 margin-top-15 border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                            <h4>Compensation Range:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">
                            <h4>{{$job->compensation_range}}</h4>
                          </div>
                        </div>
                      </div>
                      @endif
                      
                      @if($job->additional_compensation)
                      <div class="col-md-12 margin-top-15 border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                            <h4>Compensation & Benefit Details:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">
                            <h4>{{$job->additional_compensation}}</h4>
                          </div>
                        </div>
                      </div>
                      @endif
                      
                      @if($job->education_level != '')
                      <div class="col-md-12 margin-top-15 border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                            <h4>Education Required:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">
                            <h4>{{$job->education_level}}</h4>
                          </div>
                        </div>
                      </div>
                      @endif
                      
                      @if($job->experience_required != '')
                      <div class="col-md-12 margin-top-15 border_bottom">
                        <div class="col-md-5 col-sm-4">
                          <div class="row">
                            <h4>Experience Required:</h4>
                          </div>
                        </div>
                        <div class="col-md-7 col-sm-8">
                          <div class="row">
                            <h4>{{$job->experience_required}}</h4>
                          </div>
                        </div>
                      </div>
                      @endif
                      
                      
                      
                    </div>
                  </div>
                </div>
              </div>
              

              <div class="clearfix"></div>
              <div class="portlet light portlet-fit product_details">
                <div class="portlet-title"> <a data-toggle="collapse" href="#comapny" aria-expanded="" class="caption-subject">
                  <h3 class="pull-left font-red-mint ">Company Profile</h3>
                  <i class="fa fa-2x fa-plus pull-right"></i>
                  <div class="clearfix"></div>
                  </a> 
                </div>
                @if($user->company->name != '')
                <div class="all_details collapse in" id="comapny" aria-expanded="true">
                  <div class="col-md-12 all_border margin-bottom-15">
                  <div class="row">
                   <div class="col-md-3 col-sm-3 text-center user_info company_info">
                      <div class="row">
                        <div class="mt-comment-img">
                            @if($user->company->logo != '')
                            <img src="{{url('/')}}/{{$user->company->logo}}" height="80px" width="80px"> 
                            @else
                            <img src="{{url('public/images/default-user.png')}}" height="80px" width="80px">
                            @endif 
                        </div>
                        <div class="clearfix"></div>
                        @if($user->company->user->account_member == 'gold')
                        <span class="label label-sm label-default gold-member">GOLD MEMBER</span>
                        @elseif($user->company->user->account_member == 'silver')
                        <span class="label label-sm label-default silver-member">SILVER MEMBER</span>
                        @else
                        <span class="label label-sm label-default">FREE MEMBER</span>
                        @endif
                        
                        <div class="clearfix"></div>
                        @if($user->company->user->quotetek_verify == 1)
                        <span class="label label-sm label-default"> VERIFIED </span>
                        @else
                        <span class="label label-sm label-default"> NOT VERIFIED </span>
                        @endif
                        
                        <div class="clearfix"></div>
                        <ul>
                            <li><i class="fa fa-comment-o"></i> {{count($user->company->user->messages)}}</li>
                            <li><i class="glyphicon glyphicon-heart-empty"></i> {{count($user->company->user->endorsements)}}</li>
                            <li><i class="glyphicon glyphicon-star-empty"></i> {{count($user->company->user->reviews)}}</li> 
                          
                        </ul>
                        <ul class="social_icons">
                            <li><a href="{{$user->company->facebook_url}}" target="_blank"><span class="fa fa-2x fa-facebook"></span></a></li>
                            <li><a href="{{$user->company->insta_url}}" target="_blank"pr><span class="fa fa-2x fa-instagram"></span></a></li>
                            <li><a href="{{$user->company->pintress_url}}" target="_blank"><span class="fa fa-2x fa-pinterest"></span></a></li>
                            <li><a href="{{$user->company->youtube_url}}" target="_blank"><span class="fa fa-2x fa-youtube"></span></a></li>
                        </ul>
                        <div class="clearfix"></div>
                      </div>
                    </div>
                    <div class="col-md-9 col-sm-9">
                      <div class="row">
                        <div class="mt-comment-body"> 
                            @if($company->industries)
                                @foreach($company->industries as $index=>$industry)
                                    <span class="label font-red-haze label-default btn-circle  bio">{{$industry->industry->name}}</span>
                                @endforeach
                            @endif
                            
                          <div class="mt-comment-info margin-top-20"> <span class="mt-comment-author company_name">{{$company->name}} </span> </div>
                          <div class="clearfix"></div>
                          <div class="h4">{{$company->city}}, {{$company->state}}, {{$company->country}}</div>
                          <div class="clearfix"></div>
                          <div class="h4">About {{$company->name}}</div>
                          <div class="clearfix"></div>
                          <div class="mt-comment-status">{{$company->description}}</div>
                          <div class="h4"> Establish {{$company->establishment_year}}, Join us: {{date('Y',strtotime($company->created_at))}}</div>
                          
                        </div>
                      </div>
                    </div>
                    </div>
                  </div>
                </div>
                @else
                    <p>No Company Details Available.</p>
                @endif
              </div>


              <div class="clearfix"></div>
              <div class="portlet light portlet-fit product_details">
                <div class="portlet-title"> <a data-toggle="collapse" href="#qualifications" aria-expanded="" class="caption-subject">
                  <h3 class="pull-left font-red-mint "> Qualifications & Requirements</h3>
                  <i class="fa fa-2x fa-plus pull-right"></i>
                  <div class="clearfix"></div>
                  </a> </div>
                <div class="all_details collapse in" id="qualifications" aria-expanded="true">
                  <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-7 col-md-offset-5">
                            <div class="row">
                                {!! $job->addition_qualification_requirement !!}
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="clearfix"></div>
              <div class="portlet light portlet-fit product_details">
                <div class="portlet-title"> <a data-toggle="collapse" href="#responsibilities" aria-expanded="" class="caption-subject">
                  <h3 class="pull-left font-red-mint ">Responsibilities & Position Summary</h3>
                  <i class="fa fa-2x fa-plus pull-right"></i>
                  <div class="clearfix"></div>
                  </a> </div>
                <div class="all_details collapse in" id="responsibilities" aria-expanded="true">
                  <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-7 col-md-offset-5">
                            <div class="row">
                                <p class="no-margin">{!! $job->summary !!}</p>
                            </div>
                        </div>
                    </div>
                  </div>
                  <div class="clearfix"></div>
                </div>
              </div>
              <div class="clearfix"></div>
              <div class="portlet light portlet-fit product_details">
                <div class="portlet-title"> <a data-toggle="collapse" href="#tags" aria-expanded="" class="caption-subject">
                  <h3 class="pull-left font-red-mint ">Desired Skills & Keywords</h3>
                  <i class="fa fa-2x fa-plus pull-right"></i>
                  <div class="clearfix"></div>
                  </a> </div>
                <div class="all_details collapse in" id="tags" aria-expanded="true">
                  <div class="col-md-12">
                    <div class="row">
                      <div class="col-md-8 margin-top-15 margin-bottom-15 col-md-offset-4">
                        @foreach($job->specification as $skill)
                        <div class="col-md-4 col-sm-4">
                          <div class="row">
                            <h4>{{$skill['name']}}</h4>
                          </div>
                        </div>
                        @endforeach
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
             
              <div class="clearfix"></div>
              <!-- similar jobs -->
              @if(count($similar_jobs) > 0)
              <div class="portlet light portlet-fit product_details">
                <div class="portlet-title"> <a data-toggle="collapse" href="#similar" aria-expanded="" class="caption-subject">
                  <h3 class="pull-left font-red-mint ">Similar Jobs</h3>
                  <i class="fa fa-2x fa-plus pull-right"></i>
                  <div class="clearfix"></div>

                  </a> </div>
                <div class="all_details collapse in" id="similar" aria-expanded="true">
                  <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-7 col-sm-12 col-md-offset-5">
                          <div class="row">
                              
                                @foreach($similar_jobs as $sm_job)
                                    <div class="col-md-12 margin-bottom-20">
                                      <div class="row">
                                        <h4>
                                            <a href="{{url('job/view')}}/{{$sm_job->id}}" target="_blank" class="color-black">
                                                {{$sm_job->title}}
                                            </a>
                                        </h4>
                                        <p class="no-margin">@if($sm_job->company)<b><a href="{{url('company/profile')}}/{{$sm_job->company->id}}" class="color-black">{{$sm_job->company->name}}</a></b>,@endif 
                                        @if($sm_job->does_not_apply == 1)
                                            Does not Apply
                                        @else
                                        {{$sm_job->city}},{{$sm_job->state}},{{$sm_job->country}}
                                        @endif
                                        , {{$sm_job->compensation_range}}</p>
                                      </div>
                                      </div>
                                @endforeach
                              
                          </div>
                      </div>
                      </div>
                      </div>
                </div>
              </div>
              @endif
              
              <!-- More Jobs of job posted user -->
              <div class="clearfix"></div>
              @if(count($moreJobs) > 0)
              <div class="portlet light portlet-fit product_details">
                <div class="portlet-title"> <a data-toggle="collapse" href="#morejob" aria-expanded="" class="caption-subject">
                  <h3 class="pull-left font-red-mint ">Additional Jobs Posted by this Employer</h3>
                  <i class="fa fa-2x fa-plus pull-right"></i>
                  <div class="clearfix"></div>
                  </a> </div>
                <div class="all_details collapse in" id="morejob" aria-expanded="true">
                  <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-7 col-sm-12 col-md-offset-5">
                          <div class="row">
                              
                                @foreach($moreJobs as $moreJob)
                                    <div class="col-md-12 margin-bottom-20">
                                      <div class="row">
                                        <h4>
                                            <a href="{{url('job/view')}}/{{$moreJob->id}}" target="_blank" class="color-black">
                                                {{$moreJob->title}}
                                            </a>
                                        </h4>
                                        <p class="no-margin">@if($moreJob->company)<b><a href="{{url('company/profile')}}/{{$moreJob->company->id}}" class="color-black">{{$moreJob->company->name}}</a></b>,@endif 
                                        @if($moreJob->does_not_apply == 1)
                                            Does not Apply
                                        @else
                                        {{$moreJob->city}},{{$moreJob->state}},{{$moreJob->country}}
                                        @endif
                                        , {{$moreJob->compensation_range}}</p>
                                      </div>
                                      </div>
                                @endforeach
                              
                          </div>
                      </div>
                      </div>
                      </div>
                </div>
              </div>
              @endif
             <!-- <button class="btn btn-circle btn-success pull-right" onclick="printDiv('print_section')" ><i class="glyphicon glyphicon-print"></i> Print</button>-->
            </div>
        <div class="clearfix"></div>

    </div>
</div>


@include('home.footerlinks')
@endsection
