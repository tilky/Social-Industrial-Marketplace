@extends('buyer.app')

@section('content')
<link href="{{URL::asset('public/metronic/plugins/bootstrap-daterangepicker/daterangepicker.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')}}" rel="stylesheet" type="text/css" />
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url('user-dashboard')}}">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>Jobs</span>
        </li>
    </ul>
</div>
<div class="col-md-12 main_box">
<div class="row">
<div class="col-md-12 border2x_bottom">
<h3 class="page-title uppercase"> 
<i class="fa fa-server color-black"></i> Manage Listed Jobs
</h3>
</div>
</div>
<div class="row">
    <div class="col-md-12">
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet-body">
                @if (Session::has('message'))
                    <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
                @endif
                <div class="col-md-9 paddin-npt">
                    <p class="caption-helper">Manage the Jobs that you have listed.</p>
                </div>                
                    <div class="col-md-12 paddin-npt">
                        <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                        <thead>
                            <tr>
                                <th> Job Title </th>
                                <th> Status </th>
                                <th> Posted on </th>
                                <th> Expires on </th>
                                <th> Payment </th>
                                <th> Action </th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach ($jobs as $job)
                        <tr class="odd gradeX">
                            <td>{{$job->title}}</td>
                            <td>
                                @if($job->status == 1)
                                    Active
                                @else
                                    Disabled 
                                @endif
                            </td>
                            <td>
                                {{date('M d, Y',strtotime($job->created_at))}}
                            </td>
                            <td>
                                {{date('M d, Y',strtotime($job->expiry_date))}}
                            </td>
                            <td>
                                @if($job->payment_status == 0)
                                    pending
                                @else
                                    Paid 
                                @endif
                            </td>
                            <td>
                                <a href="{{url('job/view')}}/{{$job->id}}" class="btn btn-circle red btn-sm" target="_blank"><i class="fa fa-eye"></i> View</a>
                                @if($job->status == 1)
                                <a href="{{url('job/status')}}/{{$job->id}}/0" class="btn btn-circle red btn-sm"><i class="fa fa-remove"></i> Disable</a>
                                @else
                                <a href="{{url('job/status')}}/{{$job->id}}/1" class="btn btn-circle red btn-sm"><i class="fa fa-check"></i> Enable</a>
                                @endif
                                <a href="{{ route('job.edit', $job->id) }}" class="btn btn-circle btn-sm red"><i class="fa fa-pencil-square-o"></i> Modify</a>
                                
                                <a id="deleteButton" data-id="{{$job->id}}" data-toggle="modal" href="#deleteConfirmation" class="btn btn-circle btn-danger btn-sm">
    
                                {!! Form::open([
    
                                'method' => 'DELETE',
    
                                'id' => 'DELETE_FORM_'.$job->id,
    
                                'route' => ['job.destroy', $job->id]
    
                                ]) !!}
    
                                {!! Form::close() !!}
    
                                    <i class="fa fa-remove"></i> Delete </a>
                                <a href="javascript:void(0)" id="{{url('job/extend')}}/{{$job->id}}" class="btn btn-circle btn-sm red" onclick="showModal(id)">
                                            <i class="fa fa-pencil-square-o"></i> Extend </a>
                            </td>
                        </tr>
                        @endforeach
                        </tbody>
                    </table>    
                </div>
                <ul class="pager">
                    @if($previousPageUrl != '')
                    <li class="previous">
                        <a href="{{$previousPageUrl}}"> ← Prev </a>
                    </li>
                    @endif
                    @if($nextPageUrl != '')
                    <li class="next">
                        <a href="{{$nextPageUrl}}"> Next → </a>
                    </li>
                    @endif
                </ul>
            </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>
</div>
<!-- responsive -->
<div id="responsive" class="modal fade" tabindex="-1" data-width="760"></div>
<!-- BEGIN EXAMPLE TABLE PORTLET-->
<script>

    /* for show menu active */

    $("#jobs-main-menu").addClass("active");

	$('#jobs-main-menu' ).click();

	$('#jobs-menu-arrow').addClass('open');

	$('#jobs-view-menu').addClass('active');

    /* end menu active */

    $(document).on("click", "#deleteButton", function () {

        var id = $(this).data('id');

        jQuery('#deleteConfirmation .modal-body #objectId').val( id );

    });



    jQuery('#deleteConfirmation .modal-footer button').on('click', function (e) {

        var $target = $(e.target); // Clicked button element

        $(this).closest('.modal').on('hidden.bs.modal', function () {

            if($target[0].id == 'confirmDelete'){

                $( "#DELETE_FORM_" + jQuery('#deleteConfirmation .modal-body #objectId').val() ).submit();

            }

        });

    });

function showModal(id)
{
    App.blockUI({
        target: '#blockui_sample_1_portlet_body',
        animate: true
    });
      var url = id;
      $.ajax({
        url: url,
        type: 'get',
        success: function(data) {
            $('#responsive').html('');
            $('#responsive').html(data.html);
            $('#responsive').modal('show');
            $('.date-picker').datepicker({
                rtl: App.isRTL(),
                orientation: "left",
                autoclose: true
            });
            App.unblockUI('#blockui_sample_1_portlet_body');
        },   
        done: function() {
            //console.log('error');
            App.unblockUI('#blockui_sample_1_portlet_body');
        },
        error: function() {
            //console.log('error');
            App.unblockUI('#blockui_sample_1_portlet_body');
        }
        
    });
}
</script>
<script src="{{URL::asset('public/metronic/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')}}" type="text/javascript"></script>
@endsection
