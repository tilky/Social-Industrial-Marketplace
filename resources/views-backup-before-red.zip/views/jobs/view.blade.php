@extends('buyer.app')

@section('content') 
<link href="{{URL::asset('public/css/style_custom.css')}}" rel="stylesheet" type="text/css" />
<!--======================= layout ========================-->

<div class="page-bar">
  <ul class="page-breadcrumb">
    <li> <a href="{{url('user-dashboard')}}">Home</a> <i class="fa fa-circle"></i> </li>
    <li> <a href="{{url('job')}}">Jobs</a> <i class="fa fa-circle"></i> </li>
    <li> <span>Job Listing</span> </li>
  </ul>
</div>

<!--=======================================================-->
<div class="col-md-12 main_box" id="print_section">
  <div class="row">
    @if (Session::has('message'))
        <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
    @endif
    <div class="col-md-12 border2x_bottom">
      <div class="col-md-9 col-sm-9">
        <div class="row">
          <h3 class="page-title uppercase"> {{$job->title}} </h3>
        </div>
      </div>
      <div class="col-md-3 col-sm-3 text-right hide_print">
        <div class="row">
          <div class="btn-group margin-top-10"> <a class="btn action_bg listing_btn" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> Actions <i class="fa fa-angle-down"></i> </a>
            <ul class="dropdown-menu pull-right">
              <li> <a href="javascript:;">Save</a> </li>
              <li class="divider"> </li>
              <li> <a href="#job_apply" data-toggle="modal" data-target="#job_apply">Apply</a> </li>
              <li class="divider"> </li>
              <li> <a href="javascript:;">View Company Profile</a> </li>
              <li class="divider"> </li>
              <li> <a href="javascript:void(0)" id="{{url('view/job')}}/{{$job->external_url}}" onclick="showShare(id,'{{$job->title}}')">Share</a></li>
              <li class="divider"> </li>
              <li> <a href="#" onclick="printDiv('print_section')">Print</a> </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!--
<div class="row">
          <div class="portlet light request_page">
           
           
            <h5 class="border_bottom border_top padding-tittle">
            <ul class="job_listing">
            <li><a href="#job_details"><b>Job Details</b></a></li>
            <li><a href="#comapny"><b>Company Profile</b></a></li>
            <li><a href="#qualifications"><b>Qualifications & Requirements</b></a></li>
            <li><a href="#responsibilities"><b>Responsibilities & Position Summary</b></a></li>
            <li><a href="#tags"><b>Tags</b></a></li>
            <li><a href="#similar"><b>Similar Jobs</b></a></li>
            </ul>
            
            
            </h5>

-->
  
  <div class="col-md-12 col-sm-12 margin-top-10">
  <h5 class="border_bottom border_top padding-tittle">
            <ul class="job_listing">
            <li><a href="#job_details"><b>Job Details</b></a></li>
            <li><a href="#comapny"><b>Company Profile</b></a></li>
            <li><a href="#qualifications"><b>Qualifications &amp; Requirements</b></a></li>
            <li><a href="#responsibilities"><b>Responsibilities &amp; Position Summary</b></a></li>
            <li><a href="#tags"><b>Tags</b></a></li>
            <li><a href="#similar"><b>Similar Jobs</b></a></li>
            <li><a href="#morejob"><b>More Jobs</b></a></li>
            </ul>
            
            
            </h5>
    <div class="portlet light portlet-fit product_details">
      <div class="portlet-title"> <a data-toggle="collapse" href="#job_details" aria-expanded="" class="caption-subject">
        <h3 class=" pull-left">Job Details</h3>
        <i class="fa fa-2x fa-plus pull-right"></i>
        <div class="clearfix"></div>
        </a> </div>
      <div class="all_details collapse in" id="job_details" aria-expanded="true">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-12 border_top border_bottom">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Company:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row">
                  <h4> <a target="_blank" href="{{url('company/profile')}}/{{$user->company->id}}">{{$user->company->name}}</a>
                    </li>
                  </h4>
                </div>
              </div>
            </div>
            @if($job->job_type_function != '')
            <div class="col-md-12 border_top border_bottom">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Position:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row">
                  <h4>{{$job->job_type_function}}</h4>
                </div>
              </div>
            </div>
            @endif
            
            @if($job->job_type != '')
            <div class="col-md-12 margin-top-15 border_bottom">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Job Type:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row">
                  <h4>{{$job->job_type}}</h4>
                </div>
              </div>
            </div>
            @endif
            
            @if($job->job_position_title != '')
            <div class="col-md-12 margin-top-15 border_bottom">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Title:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row">
                  <h4>{{$job->job_position_title}}</h4>
                </div>
              </div>
            </div>
            @endif
            <div class="col-md-12 margin-top-15 border_bottom">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Location:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row"> @if($job->does_not_apply == 1)
                  <h4>Does not Apply</h4>
                  @else
                  <h4>{{$job->city}},{{$job->state}},{{$job->country}}</h4>
                  @endif </div>
              </div>
            </div>
            <div class="col-md-12 margin-top-15 border_bottom">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Travel Required:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row"> @if($job->travel_required == 1)
                  <h4>{{$job->how_often}}</h4>
                  @else
                  <h4>Not Required</h4>
                  @endif </div>
              </div>
            </div>
            @if($job->compensation_type != '')
            <div class="col-md-12 margin-top-15 border_bottom">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Compensation Type:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row">
                  <h4>{{$job->compensation_type}}</h4>
                </div>
              </div>
            </div>
            @endif
            
            @if($job->compensation_range != '')
            <div class="col-md-12 margin-top-15 border_bottom">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Compensation Range:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row">
                  <h4>{{$job->compensation_range}}</h4>
                </div>
              </div>
            </div>
            @endif
            
            @if($job->additional_compensation)
            <div class="col-md-12 margin-top-15 border_bottom">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Compensation & Benefit Details:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row">
                  <h4>{{$job->additional_compensation}}</h4>
                </div>
              </div>
            </div>
            @endif
            
            @if($job->education_level != '')
            <div class="col-md-12 margin-top-15 border_bottom">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Education Required:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row">
                  <h4>{{$job->education_level}}</h4>
                </div>
              </div>
            </div>
            @endif
            
            @if($job->experience_required != '')
            <div class="col-md-12 margin-top-15 border_bottom ">
              <div class="col-md-5 col-sm-4">
                <div class="row">
                  <h4>Experience Required:</h4>
                </div>
              </div>
              <div class="col-md-7 col-sm-8">
                <div class="row">
                  <h4>{{$job->experience_required}}</h4>
                </div>
              </div>
            </div>
            @endif
            
            
            @if($job->user_id != Auth::user()->id)
            <div class="col-md-12 margin-top-15 margin-bottom-40 text-center"> <a href="#job_apply" data-toggle="modal" data-target="#job_apply" class="btn btn-lg action_bg large_btn color-black">
              <h4><b>Apply for this Position</b></h4>
              </a>
              <p class="no-margin"><a href="{{url('job/user/save')}}/{{$job->id}}/{{Auth::user()->id}}"></a>SAVE JOB LISTING</p>
            </div>
            @endif </div>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="portlet light portlet-fit product_details">
      <div class="portlet-title"> <a data-toggle="collapse" href="#comapny" aria-expanded="" class="caption-subject">
        <h3 class="pull-left ">Company Profile</h3>
        <i class="fa fa-2x fa-plus pull-right"></i>
        <div class="clearfix"></div>
        </a> </div>
      @if($user->company->name != '')
      <div class="all_details collapse in" id="comapny" aria-expanded="true">
        <!--<div class="col-md-12 all_border margin-bottom-40">
          <div class="row">
            <div class="col-md-3 col-sm-3 text-center user_info company_info">
              <div class="row">
                <div class="mt-comment-img"> @if($user->company->logo != '') <img src="{{$user->company->logo}}" height="80px" width="80px"> @else <img src="{{url('public/images/default-user.png')}}" height="80px" width="80px"> @endif </div>
                <div class="clearfix"></div>
                @if($user->company->user->account_member == 'gold') <span class="label label-sm label-default gold-member">GOLD MEMBER</span> @elseif($user->company->user->account_member == 'silver') <span class="label label-sm label-default silver-member">SILVER MEMBER</span> @else <span class="label label-sm label-default">FREE MEMBER</span> @endif
                <div class="clearfix"></div>
                @if($user->company->user->quotetek_verify == 1) <span class="label label-sm label-default"> VERIFIED </span> @else <span class="label label-sm label-default"> NOT VERIFIED </span> @endif
                <div class="clearfix"></div>
                <ul>
                  <li><i class="fa fa-comment-o"></i> {{count($user->company->user->messages)}}</li>
                  <li><i class="glyphicon glyphicon-heart-empty"></i> {{count($user->company->user->endorsements)}}</li>
                  <li><i class="glyphicon glyphicon-star-empty"></i> {{count($user->company->user->reviews)}}</li>
                </ul>
                <ul class="social_icons">
                  <li><a href="{{$user->company->facebook_url}}" target="_blank"><span class="fa fa-2x fa-facebook"></span></a></li>
                  <li><a href="{{$user->company->insta_url}}" target="_blank"pr><span class="fa fa-2x fa-instagram"></span></a></li>
                  <li><a href="{{$user->company->pintress_url}}" target="_blank"><span class="fa fa-2x fa-pinterest"></span></a></li>
                  <li><a href="{{$user->company->youtube_url}}" target="_blank"><span class="fa fa-2x fa-youtube"></span></a></li>
                </ul>
                <div class="clearfix"></div>
              </div>
            </div>
            <div class="col-md-9 col-sm-9">
              <div class="row">
                <div class="mt-comment-body"> @if($company->industries)
                  @foreach($company->industries as $index=>$industry) <span class="label font-red-haze label-default btn-circle  bio">{{$industry->industry->name}}</span> @endforeach
                  @endif
                  <div class="mt-comment-info margin-top-20"> <span class="mt-comment-author company_name">{{$company->name}} </span> </div>
                  <div class="clearfix"></div>
                  <div class="h4">{{$company->city}}, {{$company->state}}, {{$company->country}}</div>
                  <div class="clearfix"></div>
                  <div class="h4">About {{$company->name}}</div>
                  <div class="clearfix"></div>
                  <div class="mt-comment-status">{{$company->description}}</div>
                  <div class="h4"> Establish {{$company->establishment_year}}, Join us: {{date('Y',strtotime($company->created_at))}}</div>
                  @if($company->id != Auth::user()->userdetail->company_id)
                  <div class="col-md-12 margin-top-15">
                    <div class="row"> <a href="{{url('endorse-user')}}/{{Auth::user()->id}}/{{$company->user_id}}" class="btn btn-lg with_border btn-circle yellow-crusta">Endrose </a> <a href="javascript:void(0)" class="btn btn-lg with_border btn-circle yellow-crusta">Request Quote </a> <a href="{{url('messages/create')}}?buyer={{$company->user_id}}" class="btn btn-lg with_border btn-circle yellow-crusta">Contact </a> </div>
                  </div>
                  @endif </div>
              </div>
            </div>
          </div>
        </div>-->
        
        <div class="profile-inner-section margin-bottom-40">
                    <div class="col-md-3 text-center profile_info">
                      <div class="stopMenu" id="stopMenu" style="padding-top: 0px;">
                        <div class="relative"> <span class="verified-text pull-left"> <a class="btn btn-circle btn-icon-only red" href="javascript:;"> <i class="fa fa fa-close"></i> </a> NOT VERIFIED </span>
                          <div class="profile" style="margin-top: 0px!important;"> <img src="http://cryptdata.com/qt/public/company/logo/ShakeShacker_26930.jpg" width="230" height="221" alt="ShakeShacker" style="border-radius: 50%;"> </div>
                          <div class="profile_name">ShakeShacker</div>
                          <div class="position">Los Angeles, California, United States</div>
                          <div class="company_name">www.shackeghash.com</div>
                          <div class="membership"> <a href="" class="btn yellow-crusta color-black btn-circle font-yellow-crusta silver-member">FREE MEMBER</a> </div>
                        </div>
                       
                            <div class="todo-tasklist">
                                <div class="todo-tasklist-item todo-tasklist-item-border-green">
                                    <a href="#"><i class="fa fa-home pull-left"></i>
                                    <div class="todo-tasklist-item-title"> CONNECT </div></a>
                                </div>

                                <div class="todo-tasklist-item todo-tasklist-item-border-green">
                                    <a href="#message_modal" data-toggle="modal" data-target="#message_modal"> <i class="fa fa-cog  pull-left"></i>
                                    <div class="todo-tasklist-item-title"> Message </div></a>
                                </div>

                            </div>
                                
                        
                        
                      </div>
                    </div>
                    <div class="col-md-9 profile_details">
                      <div class="profile_details_inner"> 
                        <!-- Nav tabs -->
                        
                        <div class="profile-details-block aboutme">
                          <h3> ShakeShacker<span class="pull-right">User ID: </span></h3>
                          <div class="profile-block col-md-12">
                            <p>I do plumI do plumbing and I do plumbing and bing and I do plumbing and I do plumbing and I do plumbing and I do plumbing and I do plumbing and I do plumbing and I do plumbing and I do plumbing and. </p>
                            <div class="mt-element-list">
                              <div class="mt-list-container list-simple">
                                <ul>
                                  <li class="mt-list-item"> <a class="btn dark btn-red btn-circle btn-default" href="javascript:;"> Biomedical </a> </li>
                                  <li class="mt-list-item"> <i class="fa fa-circle"></i> <span class="list-content"> Industry Classification:
                                    Service Provider </span> </li>
                                  <li class="mt-list-item"> <i class="fa fa-circle"></i> <span class="list-content">Established:2005. Joined Quotetek:  2016 </span> </li>
                                  <li class="mt-list-item"> <i class="fa fa-circle"></i> <span class="list-content"> <strong> ShakeShacker has Expertise in:</strong> </span> 
                                    <!-- industries services -->
                                    <div class="expertise"> <a class="btn dark btn-outline btn-circle btn-sm" href="javascript:;"> Plumbing</a> <a class="btn dark btn-outline btn-circle btn-sm" href="javascript:;"> Air-Conditioning and Warm Air Heating Equipment and Commercial and Industrial Refrigeration Equipment</a> <a class="btn dark btn-outline btn-circle btn-sm" href="javascript:;"> Hardware and Plumbing and Heating Equipment and Supplies</a> </div>
                                    <!-- end --> 
                                  </li>
                                </ul>
                              </div>
                            </div>
                            @if($company->id != Auth::user()->userdetail->company_id)
                  <div class="col-md-12 margin-top-15">
                    <div class="row"> <a href="{{url('endorse-user')}}/{{Auth::user()->id}}/{{$company->user_id}}" class="btn btn-lg with_border btn-circle yellow-crusta">Endrose </a> <a href="javascript:void(0)" class="btn btn-lg with_border btn-circle yellow-crusta">Request Quote </a> <a href="{{url('messages/create')}}?buyer={{$company->user_id}}" class="btn btn-lg with_border btn-circle yellow-crusta">Contact </a> </div>
                  </div>
                  @endif
                            
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
      </div>
      @else
      <p>No Company Details Available.</p>
      @endif </div>
    <div class="clearfix"></div>
    <div class="portlet light portlet-fit product_details">
      <div class="portlet-title"> <a data-toggle="collapse" href="#qualifications" aria-expanded="" class="caption-subject">
        <h3 class="pull-left"> Qualifications & Requirements</h3>
        <i class="fa fa-2x fa-plus pull-right"></i>
        <div class="clearfix"></div>
        </a> </div>
      <div class="all_details collapse in" id="qualifications" aria-expanded="true">
        <div class="col-md-12 margin-bottom-40">
          <div class="col-md-12"><h4> {!! $job->addition_qualification_requirement !!}</h4> </div>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="portlet light portlet-fit product_details">
      <div class="portlet-title"> <a data-toggle="collapse" href="#responsibilities" aria-expanded="" class="caption-subject">
        <h3 class="pull-left ">Responsibilities & Position Summary</h3>
        <i class="fa fa-2x fa-plus pull-right"></i>
        <div class="clearfix"></div>
        </a> </div>
      <div class="all_details collapse in" id="responsibilities" aria-expanded="true">
        <div class="col-md-12 margin-bottom-40">
          <div class="col-md-12">
            <h4>{!! $job->summary !!}</h4>
          </div>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="portlet light portlet-fit product_details">
      <div class="portlet-title"> <a data-toggle="collapse" href="#tags" aria-expanded="" class="caption-subject">
        <h3 class="pull-left ">Desired Skills & Keywords</h3>
        <i class="fa fa-2x fa-plus pull-right"></i>
        <div class="clearfix"></div>
        </a> </div>
      <div class="all_details collapse in" id="tags" aria-expanded="true">
        <div class="col-md-12 margin-bottom-40">
          <div class="col-md-12"> @foreach($job->specification as $skill)
            <div class="col-md-4 col-sm-4">
              <div class="row">
                <h4>{{$skill['name']}}</h4>
              </div>
            </div>
            @endforeach </div>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
    <!-- similar jobs --> 
    @if(count($similar_jobs) > 0)
    <div class="portlet light portlet-fit product_details">
      <div class="portlet-title"> <a data-toggle="collapse" href="#similar" aria-expanded="" class="caption-subject">
        <h3 class="pull-left ">Similar Jobs</h3>
        <i class="fa fa-2x fa-plus pull-right"></i>
        <div class="clearfix"></div>
        </a> </div>
      <div class="all_details collapse in" id="similar" aria-expanded="true">
        <div class="col-md-12 margin-bottom-40">
          <div class="row"> @foreach($similar_jobs as $sm_job)
            <div class="col-md-12 margin-bottom-20">
              <div class="col-md-12 border_bottom">
                <h4> <a href="{{url('job/view')}}/{{$sm_job->id}}" target="_blank" class="color-black"> {{$sm_job->title}} </a> </h4>
                <p class="no-margin">@if($sm_job->company)<b><a href="{{url('company/profile')}}/{{$sm_job->company->id}}" class="color-black">{{$sm_job->company->name}}</a></b>,@endif 
                  @if($sm_job->does_not_apply == 1)
                  Does not Apply
                  @else
                  {{$sm_job->city}},{{$sm_job->state}},{{$sm_job->country}}
                  @endif
                  , {{$sm_job->compensation_range}}</p>
              </div>
            </div>
            @endforeach </div>
        </div>
      </div>
    </div>
    @endif 
    
    <!-- More Jobs of job posted user -->
    <div class="clearfix"></div>
    @if(count($moreJobs) > 0)
    <div class="portlet light portlet-fit product_details">
      <div class="portlet-title"> <a data-toggle="collapse" href="#morejob" aria-expanded="" class="caption-subject">
        <h3 class="pull-left ">Additional Jobs Posted by this Employer</h3>
        <i class="fa fa-2x fa-plus pull-right"></i>
        <div class="clearfix"></div>
        </a> </div>
      <div class="all_details collapse in" id="morejob" aria-expanded="true">
        <div class="col-md-12">
             @foreach($moreJobs as $moreJob)
                <div class="col-md-12 margin-bottom-20">
               
                    <h4> <a href="{{url('job/view')}}/{{$moreJob->id}}" target="_blank" class="color-black"> {{$moreJob->title}} </a> </h4>
                    <p class="no-margin">@if($moreJob->company)<b><a href="{{url('company/profile')}}/{{$moreJob->company->id}}" class="color-black">{{$moreJob->company->name}}</a></b>,@endif 
                      @if($moreJob->does_not_apply == 1)
                      Does not Apply
                      @else
                      {{$moreJob->city}},{{$moreJob->state}},{{$moreJob->country}}
                      @endif
                      , {{$moreJob->compensation_range}}</p>
                  </div>
                
                @endforeach 
        </div>
      </div>
    </div>
    @endif 
    <!-- <button class="btn btn-circle btn-success pull-right" onclick="printDiv('print_section')" ><i class="glyphicon glyphicon-print"></i> Print</button>--> 
  </div>
  <div class="clearfix"></div>
</div>
<div class="clearfix"></div>
</div>
</div>
<script>
// ------------------------------
// http://twitter.com/mattsince87
// ------------------------------

function scrollNav() {
  $('.job_listing a').click(function(){  
    //Toggle Class
    $(".active").removeClass("active");      
    $(this).closest('li').addClass("active");
    var theClass = $(this).attr("class");
    $('.'+theClass).parent('li').addClass('active');
    //Animate
    $('html, body').stop().animate({
        scrollTop: $( $(this).attr('href') ).offset().top - 160
    }, 400);
    return false;
  });
  $('.scrollTop a').scrollTop();
}
scrollNav();
</script>
@endsection 
