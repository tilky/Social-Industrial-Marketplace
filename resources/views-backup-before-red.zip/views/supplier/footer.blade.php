<!-- BEGIN FOOTER -->
<!-- /.modal -->
<div class="modal fade footer-modal" id="basic1" tabindex="-1" role="basic" aria-hidden="true" data-width="760">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h3 class="modal-title" style="text-transform: uppercase;">Help us Improve</h3>
                <p class="caption-helper" style="margin: 5px 0px!important;">Your feedback helps us understand what we do well and where we can improve.</p>
            </div>
            <form action="{{url('feedback/message')}}" method="post" class="horizontal-form">
                <input type="hidden" name="_token" value="{{csrf_token()}}" />
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 form-group">
                            <label class="control-label">Subject:</label>
                            <div class="">
                                <input type="text" name="subject" class="form-control" placeholder="Add a subject to your feedback" />
                            </div>
                        </div>
                        <div class="col-md-12 form-group">
                            <label class="control-label">Summary:</label>
                            <div class="">
                                <textarea name="message" class="form-control" rows="4" placeholder="Please describe your comments and feedback."></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-circle default" data-dismiss="modal">Close</button>
                    <button type="submite" class="btn btn-circle blue">Send</button>
                </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<!-- /.modal -->
<div class="modal fade footer-modal" id="basic" tabindex="-1" role="basic" aria-hidden="true" data-width="760">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="btn btn-circle btn-outline" class="close" data-dismiss="modal" aria-hidden="true"></button>
               <h4 class="modal-title align-center" id="myModalLabel">
                    	Tell your Professional Network about us!
                    </h4>
            </div>
            <div class="modal-body" id="basic-invite"> 
                <div class="title align-center">
                       <h2>Invite new users or connect with existing associates. </h2>
                        <p>Earn referral payouts on users that choose valued accounts. <a href="{{url('referral-link/about-the-program')}}">Learn More</a>
</p>
                    </div>
                    <div class="form align-center paddin-bottom" style="width: 70%;margin: 0 auto;">
                        <!--  form-body  -->
            
                        <div class="align-center" >
                            <div class="row">
                                <div class="col-md-6 ">
                                    <a href="{{Session::get('google_invite_url')}}" target="_blank"><img src="{{url('public/images/Indy-John/gmail-icon.png')}}" class="img-circle center-block modal-invite-img"></a>
                                </div>
                                <div class="col-md-6 ">
                                    <a href="javascript:void(0)" onclick="GetYahooHeaderContact();"><img src="{{url('public/images/Indy-John/yahoo-icon.png')}}" class="img-circle modal-invite-img center-block"></a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 ">
                                    <a href="{{Session::get('msn_invite_url')}}" target="_blank"><img src="{{url('public/images/Indy-John/outlook-icon.png')}}" class="img-circle modal-invite-img center-block"></a>
                                </div>
                                <div class="col-md-6 ">
                                    <a href="{{url('invite/email')}}" target="_blank"><img src="{{url('public/images/Indy-John/mail-icon.png')}}" class="img-circle modal-invite-img center-block"></a>
                                </div>
                            </div>
                        </div>
                        <!--  /form-body  -->
            
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-circle dark btn-outline" data-dismiss="modal">Close</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<!-- /.modal -->
<div class="modal fade footer-modal" id="share" tabindex="-1" role="basic" aria-hidden="true" data-width="760">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="portlet">
        <div class="portlet-body">
          <div class="modal-header">
            <h3 class="modal-title pull-left" style="text-transform: uppercase;">Share BY </h3>
            <ul class="nav pull-left share_icon">
              <li><a class="green" href="#tab_2_1" data-toggle="tab"><i class="fa fa-link"></i></a></li>
              <li><a class="yellow" href="#tab_2_2" data-toggle="tab"><i class="fa fa-envelope-o"></i></a></li>
              <li><a class="blue1" href="#" id="share-linkedin" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a class="blue2" href="#" id="share-facebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a class="blue3" href="#" id="share-twitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a class="red" href="#" id="share-google" target="_blank"><i class="fa fa-google-plus"></i></a></li>
            </ul>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
          </div>
          <div class="tab-content">
            <div class="tab-pane fade active in" id="tab_2_1">
              <form  method="post" class="horizontal-form">
                <div class="modal-body">
                  <div class="form-body">
                    <div class="row">
                      <div class="col-md-12 margin_input">
                        <div class="form-group form-md-line-input">
                          <div class="col-md-12">
                            <div class="input-group input-group-sm">
                              <div class="input-group-control">
                                <input id="copyTarget" type="text" class="form-control input-sm" placeholder="" value="#" >
                              </div>
                              <span class="input-group-btn btn-right">
                              <button id="copyButton" class="btn default relative" type="button">COPY <i class="fa fa-link green"></i></button>
                              </span> </div>
                          </div>
                        </div>
                        <div class="col-md-12">
                          <p id="msg"></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="modal-footer"> &nbsp; </div>
              </form>
            </div>
            <div class="tab-pane fade" id="tab_2_2">
              <form action="{{url('mail/share/link')}}" method="post" class="horizontal-form">
                <input type="hidden" name="_token" value="{{csrf_token()}}" />
                <input type="hidden" name="share_link" id="share-mail" value="" />
                <div class="modal-body">
                  <div class="form-body">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group form-md-line-input">
                          <div class="input-icon">
                            <input type="email" name="recipient_email" required="" class="form-control" placeholder="RECIPIENT'S E-MAIL">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group form-md-line-input">
                          <div class="input-icon">
                            <input type="email" name="user_email" readonly="" required="" value="{{Auth::user()->email}}" class="form-control" placeholder="YOUR E-MAIL">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group form-md-line-input">
                          <div class="input-icon">
                            <input type="text" name="message" class="form-control" placeholder="OPTIONAL MESSAGE">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-actions noborder text-right">
                    <button type="submit" class="btn blue">SEND</button>
                  </div>
                </div>
                <div class="modal-footer"> &nbsp; </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /.modal -->

<!-- Upgrade account modal -->

<!--<div class="modal fade general-pricing" id="upgrade-buyer-acount-modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

    <ul class="nav nav-tabs">
        <li class="">
            <a data-toggle="tab" href="#tab_1_1" aria-expanded="false"> Buyer Dashboard </a>
        </li>
        <li class="active">
            <a data-toggle="tab" href="#tab_1_2" aria-expanded="true"> Supplier Crm </a>
        </li>

    </ul>

    <div style="opacity: 1; transition: opacity 0.1s linear 0s;" class="tab-content">
        <div id="tab_1_2" class="tab-pane fade active in">
            <div class="tab-content-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    ×
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Gain an Edge, Upgrade Your Supplier CRM.
                </h4>
            </div>
            <div class="supplier_content">
                <div class="col-md-12 supplier_content_inner">
                    <h5>Increase selling opportunities for the price of a cell phone bill.</h5>
                    <p>
                        We know sales environments can be very competitive, and prospecting for serious buyers can be very time
                        consuming.  Our technologies are designed to produce serious leads, gain advantages now by upgrading
                        to one of our valued accounts designed to help you reach your sales goals.
                    </p>
                </div>
                <br>
                <br>
                <div class="clearfix"></div>

                <div class="col-md-4">
                    <div class="thumbnail">

                        <div class="caption">
                            <h1 class="box-title">
                                FREE
                            </h1>
                            <h6>ACCOUNT</h6>
                            <h1><span>$</span>0</h1>
                            <h6>PER MONTH</h6>
                            <ul class="free-list">
                                 <li>LEADS LIMITED UP TO 10/ MONTH</li>
                <li>LEADS DELAYED UP TO 1 DAY</li>
                <li>LIMITED TO 1 INDUSTRIAL MARKET</li>
                <li>POST UP TO 30 MARKET LISTINGS</li>
                <li>MARKET LISTINGS EXPIRE MONTHLY</li>
 <li>NO JOB BOARD CREDITS</li>
                <li><span>VERIFICATION NOT INCLUDED</span></li>
                            </ul>
                            <button id="plan_FREE_5_0" onclick="updatePlan(id,'seller');">Current Plan</button>

                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="thumbnail">

                        <div class="caption">
                            <h1 class="box-title">
                                SILVER
                            </h1>
                            <h6>ACCOUNT</h6>
                            <h1><span>$</span>149</h1>
                            <h6>PER MONTH</h6>
                            <ul class="free-list">
                               <li>LEADS LIMITED UP TO 30/ MONTH</li>
                <li>LEADS DELAYED UP TO 12 HOURS</li>
                <li>LIMITED TO 10 INDUSTRIAL MARKETS</li>
                <li>POST UP TO 100 MARKET LISTINGS</li>
                <li>MARKET LISTINGS DO NOT EXPIRE</li>
 <li>5 JOB BOARD CREDITS</li>
                <li><span>VERIFICATION INCLUDED</span></li>
                            </ul>
                            <button class="upgrade-btn"  id="plan_SILVER_4_14900" onclick="updatePlan(id,'seller');">UPGRADE</button>

                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="thumbnail gray_color">
                        <div class="most-popular">
                            MOST POPULAR +<br/>
                            UNLIMITED ACCESS
                        </div>
                        <div class="caption">
                            <h1 class="box-title">
                                GOLD
                            </h1>
                            <h6>ACCOUNT</h6>
                            <h1><span>$</span>199</h1>
                            <h6>PER MONTH</h6>
                            <ul class="free-list">
                                 <li><span>UNLIMITED</span> LEADS</li>
                <li>LEADS DELIVERED <span> INSTANTLY</span></li>
                <li><span>UNLIMITED</span> INDUSTRIAL MARKETS</li>
                <li><span>UNLIMITED</span> MARKET LISTINGS</li>
                <li>MARKET LISTINGS <span>DO NOT EXPIRE</span></li>
 <li><span>15</span> JOB BOARD CREDITS</li>
                <li><span>VERIFICATION INCLUDED</span></li>
                            </ul>
                            <button class="upgrade" id="plan_GOLD_3_19900" onclick="updatePlan(id,'seller');">UPGRADE</button>

                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="footer-pricing">
                    <h4>Don’t Limit Your Opportunities, Upgrade Now. </h4>
                    <h5>* These rates are set for 2016.</h5>
                </div>
            </div>
        </div>
        <div id="tab_1_1" class="tab-pane fade">
            <form method="post" action="{{url('user/packages/save')}}" role="form" id="payment-form-pop"  class="form-horizontal form-row-seperated">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <input type="hidden" name="card_token" value="" id="card_token_pop" />
                <input type="hidden" name="card_last_4" value="" id="card_last_4_pop" />
                <input type="hidden" name="card_type" id="card_type_pop" value="" />
                <input type="hidden" name="cardNumber" id="cardNumber_pop" value="" />
                <input type="hidden" name="cardExpiry" id="cardExpiry_pop" value="" />
                <input type="hidden" name="cardCVC" id="cardCVC_pop" value="" />
                <input type="hidden" name="billing_plan" id="billing_plan_pop" />
                <input type="hidden" id="modal-type" />
            </form>
            <div class="tab-content-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">

                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Gain an Edge, Upgrade Your Buyer Dashboard.
                </h4>
            </div>
            <div class="buyer_content">
                <div class="col-md-12 buyer_content_inner">
                    <h5>Gain pricing options by becoming a Buyer+</h5>
                    <p>Being a consumer in today’s industrial marketplace is difficult and desperately needs to be overhauled.
                        We’ve developed features and tools to help buyers get the price they want. Upgrade to our Buyer+ account
                        to gain benefits and simplify your purchasing process.  </p>
                </div>
                <br>
                <br>
                <div class="clearfix"></div>

                <div class="col-md-4">
                    <div class="thumbnail">

                        <div class="caption">
                            <h1 class="box-title">
                                FREE
                            </h1>
                            <h6>ACCOUNT</h6>
                            <h1><span>$</span>0</h1>
                            <h6>PER MONTH</h6>
                            <hr>
                            <ul class="free-list">
                               <li>BUY REQUESTS LIMITED TO 30/ MONTH</li>
                <li>QUOTES DELAYED UP TO 1 DAY</li>
                <li>LIMITED TO 10 INDUSTRIAL MARKETS</li>
                <li>POST UP TO 30 MARKET LISTINGS</li>
                <li>MARKET LISTINGS EXPIRE MONTHLY</li>
  <li>NO JOB BOARD CREDITS</li>
                <li><span>VERIFICATION NOT INCLUDED</span></li>
                            </ul>
                            <button id="plan_FREE_2_0" onclick="updatePlan(id,'buyer');">Current Plan</button>

                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="thumbnail gray_color">

                        <div class="caption">
                            <h1 class="box-title">
                                BUYER+
                            </h1>
                            <h6>ACCOUNT</h6>
                            <h1><span>$</span>199</h1>
                            <h6>PER MONTH</h6>
                            <hr>
                            <ul class="free-list">
                                <li><span>UNLIMITED</span> BUY REQUESTS</li>
                                <li>QUOTES DELIVERED <span>INSTANTLY</span></li>
                                <li><span>UNLIMITED</span> INDUSTRIAL MARKETS</li>
                                <li><span>UNLIMITED</span> MARKET LISTINGS</li>
                                <li>MARKET LISTINGS DO NOT EXPIRE</li>
                                <li><span>VERIFICATION INCLUDED</span></li>
                            </ul>
                            <button class="upgrade" id="plan_BUYER+_1_19900" onclick="updatePlan(id,'buyer');">UPGRADE</button>

                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="thumbnail">

                        <div class="caption">
                            <h1 class="box-title">
                                ADVANCED
                            </h1>
                            <h6>ACCOUNT</h6>
                            <h2>COMING<br/> SOON</h2>
                            <div class="current-plan">
                                <p><span>EXPANDED</span> FEATURES<br/> AND TOOLS</p>
                            </div>
                            <button class="upgrade">COMING SOON</button>

                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="footer-pricing">
                    <h4>Industrial Purchasing made Easy, Upgrade Now.</h4>
                    <h5>* These rates are set for 2016.</h5>
                </div>
            </div>

        </div>
    </div>
</div>-->
    
   
    <div class="modal fade general-pricing" id="upgrade-supplier-acount-modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <ul class="nav nav-tabs">
    <li class="active"> <a data-toggle="tab" href="#tab_1_1" aria-expanded="true"> Buyer Dashboard </a> </li>
    <li> <a data-toggle="tab" href="#tab_1_2" aria-expanded="false"> Supplier Crm </a> </li>
  </ul>
  <div style="opacity: 1; transition: opacity 0.1s linear 0s;" class="tab-content">
    <form method="post" action="{{url('user/packages/save')}}" role="form" id="payment-form-pop"  class="form-horizontal form-row-seperated">
      <input type="hidden" name="_token" value="{{csrf_token()}}">
      <input type="hidden" name="card_token" value="" id="card_token_pop" />
      <input type="hidden" name="card_last_4" value="" id="card_last_4_pop" />
      <input type="hidden" name="card_type" id="card_type_pop" value="" />
      <input type="hidden" name="cardNumber" id="cardNumber_pop" value="" />
      <input type="hidden" name="cardExpiry" id="cardExpiry_pop" value="" />
      <input type="hidden" name="cardCVC" id="cardCVC_pop" value="" />
      <input type="hidden" name="billing_plan" id="billing_plan_pop" />
      <input type="hidden" id="modal-type" />
    </form>
    <div id="tab_1_1" class="tab-pane active in">
      <div class="tab-content-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> </button>
        <h4 class="modal-title" id="myModalLabel"> Gain an Edge, Upgrade Your Buyer Dashboard. </h4>
      </div>
      <div class="buyer_content">
        <div class="col-md-12 buyer_content_inner">
          <h5>Gain pricing options by becoming a Buyer+</h5>
          <p>Being a consumer in today's industrial marketplace is difficult and desperately needs to be overhauled.
            We've developed features and tools to help buyers get the price they want. Upgrade to our Buyer+ account
            to gain benefits and simplify your purchasing process. </p>
        </div>
        <br>
        <br>
        <div class="clearfix"></div>
        <div class="col-md-4">
          <div class="thumbnail">
            <div class="caption">
              <h1 class="box-title"> FREE </h1>
              <h6>ACCOUNT</h6>
              <h1><span>$</span>0</h1>
              <h6>PER MONTH</h6>
              <hr>
              <ul class="free-list">
                <li>REQUESTS LIMITED TO 5/ DAY</li>
                <li>QUOTES DELAYED UP TO 1 DAY</li>
                <li>LIMITED TO 5 INDUSTRIAL MARKETS</li>
                <li>POST UP TO 30 MARKET LISTINGS</li>
                <li>MARKET LISTINGS EXPIRE MONTHLY</li>
                <li><span>VERIFICATION NOT INCLUDED</span></li>
              </ul>
              @if(Auth::user()->account_plan == 'buyerstandard')
              <button id="plan_FREE_2_0">Current Account</button>
              @elseif(Auth::user()->account_plan == 'buyerplus')
              <a id="plan_FREE_2_0" class="downgrade-class" href="{{url('user/packages')}}" >Downgrade</a>
              @else
              <button id="plan_FREE_2_0" class="upgrade" onclick="updatePlan(id,'buyer');">UPGRADE</button>
              @endif
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail gray_color">
            <div class="caption">
              <h1 class="box-title"> BUYER+ </h1>
              <h6>ACCOUNT</h6>
              <h1><span>$</span>199</h1>
              <h6>PER MONTH</h6>
              <hr>
              <ul class="free-list">
                <li><span>UNLIMITED</span> BUY REQUESTS</li>
                <li>QUOTES DELIVERED <span>INSTANTLY</span></li>
                <li><span>UNLIMITED</span> INDUSTRIAL MARKETS</li>
                <li><span>UNLIMITED</span> MARKET LISTINGS</li>
                <li>MARKET LISTINGS DO NOT EXPIRE</li>
                <li><span>VERIFICATION INCLUDED</span></li>
              </ul>
              @if(Auth::user()->account_plan == 'buyerplus')
              <button id="plan_BUYER+_1_19900">Current Account</button>
              @else
              <button class="upgrade" id="plan_BUYER+_1_19900" onclick="updatePlan(id,'buyer');">UPGRADE</button>
              @endif
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
            <div class="caption">
              <h1 class="box-title"> ADVANCED </h1>
              <h6>ACCOUNT</h6>
              <h2>COMING<br/>
                SOON</h2>
              <div class="current-plan">
                <p><span>EXPANDED</span> FEATURES<br/>
                  AND TOOLS</p>
              </div>
              <button class="upgrade">COMING SOON</button>
            </div>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="footer-pricing">
          <h4>Industrial Purchasing made Easy, Upgrade Now.</h4>
          <h5>* These rates are set for 2016.</h5>
        </div>
      </div>
    </div>
    <div id="tab_1_2" class="tab-pane">
      <div class="tab-content-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> × </button>
        <h4 class="modal-title" id="myModalLabel"> Gain an Edge, Upgrade Your Supplier CRM. </h4>
      </div>
      <div class="supplier_content">
        <div class="col-md-12 supplier_content_inner">
          <h5>Increase selling opportunities for the price of a cell phone bill.</h5>
          <p> We know sales environments can be very competitive, and prospecting for serious buyers can be very time
            consuming.  Our technologies are designed to produce serious leads, gain advantages now by upgrading
            to one of our valued accounts designed to help you reach your sales goals. </p>
        </div>
        <br>
        <br>
        <div class="clearfix"></div>
        <div class="col-md-4">
          <div class="thumbnail">
            <div class="caption">
              <h1 class="box-title"> FREE </h1>
              <h6>ACCOUNT</h6>
              <h1><span>$</span>0</h1>
              <h6>PER MONTH</h6>
              <ul class="free-list">
                <li>REQUESTS LIMITED TO 5/ DAY</li>
                <li>QUOTES DELAYED UP TO 1 DAY</li>
                <li>LIMITED TO 5 INDUSTRIAL MARKETS</li>
                <li>POST UP TO 30 MARKET LISTINGS</li>
                <li>MARKET LISTINGS EXPIRE MONTHLY</li>
                <li><span>VERIFICATION NOT INCLUDED</span></li>
              </ul>
              @if(Auth::user()->account_plan == 'supplierfree')
              <button id="plan_FREE_5_0" >Current Account</button>
              @elseif(Auth::user()->account_plan == 'suppliersilver' || Auth::user()->account_plan == 'suppliergold')
              <a id="plan_FREE_5_0" class="downgrade-class" href="{{url('user/packages')}}" >Downgrade</a>
              @else
              <button id="plan_FREE_5_0" class="upgrade" onclick="updatePlan(id,'seller');">UPGRADE</button>
              @endif
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
            <div class="caption">
              <h1 class="box-title"> SILVER </h1>
              <h6>ACCOUNT</h6>
              <h1><span>$</span>149</h1>
              <h6>PER MONTH</h6>
              <ul class="free-list">
                <li>LEADS LIMITED TO 100 CATEGORIES</li>
                <li>LEADS DELAYEDUP TO 12 HOURS</li>
                <li>LIMITED TO 3 INDUSTRIAL MARKETS</li>
                <li>POST UP TO 100 MARKET LISTINGS</li>
                <li>LEADS LIMITED TO 150 PER MONTH</li>
                <li><span>VERIFICATION INCLUDED</span></li>
              </ul>
              @if(Auth::user()->account_plan == 'suppliersilver')
              <button id="plan_SILVER_4_14900" >Current Account</button>
              @elseif(Auth::user()->account_plan == 'suppliergold')
              <a id="plan_SILVER_4_14900" class="downgrade-class" href="{{url('user/packages')}}" >Downgrade</a>
              @else
              <button class="upgrade"  id="plan_SILVER_4_14900" onclick="updatePlan(id,'seller');">UPGRADE</button>
              @endif
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail gray_color">
            <div class="most-popular"> MOST POPULAR +<br/>
              UNLIMITED ACCESS </div>
            <div class="caption">
              <h1 class="box-title"> GOLD </h1>
              <h6>ACCOUNT</h6>
              <h1><span>$</span>199</h1>
              <h6>PER MONTH</h6>
              <ul class="free-list">
                <li><span>UNLIMITED</span> CATEGORIES</li>
                <li>LEADS DELIVERED <span> INSTANTLY</span></li>
                <li><span>UNLIMITED</span> INDUSTRIAL MARKETS</li>
                <li><span>UNLIMITED</span> MARKET LISTINGS</li>
                <li>RECIEVE <span>UNLIMITED</span>LEADS</li>
                <li><span>VERIFICATION INCLUDED</span></li>
              </ul>
              @if(Auth::user()->account_plan == 'suppliergold')
              <button id="plan_GOLD_3_19900" >Current Account</button>
              @else
              <button class="upgrade" id="plan_GOLD_3_19900" onclick="updatePlan(id,'seller');">UPGRADE</button>
              @endif
            </div>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="footer-pricing">
          <h4>Don't Limit Your Opportunities, Upgrade Now. </h4>
          <h5>* These rates are set for 2016.</h5>
        </div>
      </div>
    </div>
  </div>
</div>
    
<script src="https://checkout.stripe.com/checkout.js"></script>
<script>

$(document).ready(function(){
    if($(window).width() < 769){
        console.log($(window).width());
        $('.page-header-inner').find('.buttons-toggle').addClass('navbar-collapse collapse').css('overflow','hidden');
        $('.page-top').addClass('navbar-collapse collapse').css('overflow','hidden').css('height','1px');
    }
    
    
});

function showShare(id,title)
{
    console.log(id);
    var mainUrl = id;
    var linkedIn = 'https://www.linkedin.com/shareArticle?mini=true&url='+id;
    var facebook = 'https://www.facebook.com/sharer/sharer.php?u='+id;
    var twitter = 'https://twitter.com/home?status='+title+','+id;
    var google_plus = 'https://plus.google.com/share?url='+id;
    $('#copyTarget').val(mainUrl);
    $('#share-mail').val(id);
    $('#share-linkedin').attr('href',linkedIn);
    $('#share-facebook').attr('href',facebook);
    $('#share-twitter').attr('href',twitter);
    $('#share-google').attr('href',google_plus);
    $('#share').modal('show');
}
      function updatePlan(id,user_type)
      {
        if(user_type == 'seller')
        {
            $('#modal-type').val('seller');
        }
        else
        {
            $('#modal-type').val('buyer');
        }
        
        var values = id.split('_');
        $('#billing_plan_pop').val(values[2]);
        
        var handler = StripeCheckout.configure({
            key: "{{env('STRIPE_PUBLIC_KEY', '')}}",
            image: "{{url('public/images/indy_john_crm_logo.png')}}",
            locale: 'auto',
            token: function(token) {
                
                var user_type = $('#modal-type').val();
                if(user_type == 'seller')
                {
                    App.blockUI({
                        target: '#payment-plan-seller-div',
                        animate: true
                    });
                }
                else
                {
                    App.blockUI({
                        target: '#payment-plan-buyer-div',
                        animate: true
                    });
                }
                $('#card_token_pop').val(token.id);
                $('#card_last_4_pop').val(token.card.last4);
                $('#cardNumber_pop').val('');
                $('#cardExpiry_pop').val(token.card.exp_month+' / '+token.card.exp_year);
                $('#cardCVC_pop').val('');
                $('#card_type_pop').val(token.card.brand+' '+token.type);
                $('#payment-form-pop').submit();
              // You can access the token ID with `token.id`.
              // Get the token ID to your server-side code for use.
            }
          });
        
        // Open Checkout with further options:
        handler.open({
          name: "{{url('/')}}",
          description: values[1]+' ACCOUNT',
          email:"{{Auth::user()->email}}",
          amount: values[3]
        });
        
      }
      
      // Close Checkout on page navigation:
      $(window).on('popstate', function() {
        handler.close();
      });
    </script>
   
<!-- /.modal --> 
<!-- dashboar select modal -->
<!-- /.modal -->
<div class="modal fade general-pricing" id="dashboard-select-modal" tabindex="-1" role="basic" aria-hidden="true" data-width="760">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="btn btn-circle btn-outline" class="close" data-dismiss="modal" aria-hidden="true"></button>
        <h3 class="modal-title">WHAT WOULD YOU LIKE TO DO TODAY?</h3>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12">
            <h4 class="align-center">Select one the best applies:</h4>
            <div class="col-md-12 align-center">
              <input type="hidden" id="pulsate-val" value="@if(Session::has('pulsate')) {{Session::get('pulsate')}} @endif" />
              <div class="btn-group quickstart" data-toggle="buttons">
                <div class="col-md-3 col-sm-3">
                  <div class="row"> <span class="quickstart_heading buyers">Buyers</span>
                    <div class="clearfix"></div>
                    <label class="btn btn-primary btn-group invite-contact-sec-div row-one" id="pulsate-one">
                      <input type="radio" name="user_type" value="2_1" autocomplete="off">
                      Get<br />
                      <b>Product Quotes</b> </label>
                    <label class="btn btn-primary row-one" id="pulsate-four">
                      <input type="radio" name="user_type" value="3_4" autocomplete="off">
                      Find <b>Product Service</b> </label>
                    <label class="btn btn-primary row-one" id="pulsate-nine">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                      Locate <b>Industrial<br />
                      Service Providers.</b> </label>
                  </div>
                </div>
                <div class="col-md-3 col-sm-3">
                  <div class="row"> <span class="quickstart_heading suppliers">Suppliers</span>
                    <div class="clearfix"></div>
                    <label class="btn btn-primary row-two" id="pulsate-two">
                      <input type="radio" name="user_type" value="2_2" autocomplete="off">
                      Receive Product & Service Leads</b> </label>
                    <label class="btn btn-primary row-two" id="pulsate-eight">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                      Upload your <br/>
                      Product Catalog </label>
                    <label class="btn btn-primary row-two" id="pulsate-five">
                      <input type="radio" name="user_type" value="3_5" autocomplete="off">
                      Claim or Create a<br />
                      <b>Company Profile</b> </label>
                  </div>
                </div>
                <div class="col-md-3 col-sm-3">
                  <div class="row"> <span class="quickstart_heading multi-user">Multi-User</span>
                    <div class="clearfix"></div>
                    <label class="btn btn-primary row-three" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      <b>Upgrade</b> Your <br />
                      Indy John Account </label>
                    <label class="btn btn-primary row-three" id="pulsate-eight">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                      <b>Refer <br/>
                      & Earn</b> </label>
                    <label class="btn btn-primary row-three" id="pulsate-nine">
                      <input type="radio" name="user_type" value="2_8" autocomplete="off">
                      ? <b>Verify</b><br />
                      My Account </label>
                  </div>
                </div>
                <div class="col-md-3 col-sm-3">
                  <div class="row"> <span class="quickstart_heading more-options">More Options</span>
                    <div class="clearfix"></div>
                    <label class="btn btn-primary row-four" id="pulsate-three">
                      <input type="radio" name="user_type" value="3_3" autocomplete="off">
                      Explore<br />
                      <b>Indy John Market</b> </label>
                    <label class="btn btn-primary row-four" id="pulsate-seven">
                      <input type="radio" name="user_type" value="2_7" autocomplete="off">
                      Visit the<br />
                      <b>Job Board</b> </label>
                    <label class="btn btn-primary row-four" id="pulsate-six">
                      <input type="radio" name="user_type" value="2_6" autocomplete="off">
                      Search & <br />
                      Discover </label>
                  </div>
                </div>
                <br>
                <a href="">Not Sure yet, butz want to Explore.</a> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.modal-content --> 
  </div>
  <!-- /.modal-dialog --> 
</div>

<!-- Welcome modal --> 
<!-- /.modal -->
<div class="modal fade footer-modal" id="user-welcome-modal" tabindex="-1" role="basic" aria-hidden="true" data-width="400">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="pull-left">&nbsp;</h4>
        <button type="button" class="close pull-right" data-dismiss="modal" aria-hidden="true"></button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12 margin-top-40 margin-bottom-40">
            <input type="hidden" id="user-reg-first" value="@if(Session::has('new_user_first')) 1 @endif" />
            <h1 class="align-center">Welcome To <img src="http://cryptdata.com/qt/public/images/indy_john_crm_logo.png" /></h1>
            <br />
            <div class="col-md-12 align-center">
              <h3 class="modal-title">Please take a few minutes to Complete Your <b>User Profile</b> <br />
                before Exploring Indy John.</h3>
              <br />
              <div id="timer"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <h3>&nbsp;</h3>
      </div>
    </div>
    <!-- /.modal-content --> 
  </div>
  <!-- /.modal-dialog --> 
</div>

<div class="page-footer">
    <div class="page-footer-inner"> © Indy John Inc. All Rights Reserved. <a href="javascript:void(0);" id="footer-feedback"><b>Feedback</b></a>
    
    </div>
    <img class="footer_logo" src="http://cryptdata.com/qt/public/livesite/images/powered-by-indy-john.png" height="25px" width="200px">
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>

<script>
$('#footer-feedback').click(function(){
    jQuery('#basic1').modal('show');    
});
$('#invite-user-header').click(function(){
    jQuery('#basic').modal('show');    
});
$('#upgrade-buyer-modal').click(function(){
    jQuery('#upgrade-buyer-acount-modal').modal('show');    
});
$('#upgrade-buyer-modal-notification').click(function(){
    jQuery('#upgrade-buyer-acount-modal').modal('show');    
});
$('#sidebar-upgrade-buyer').click(function(){
    jQuery('#upgrade-buyer-acount-modal').modal('show');    
});
$('#upgrade-supplier-modal').click(function(){
    jQuery('#upgrade-supplier-acount-modal').modal('show');    
});
$('#upgrade-supplier-modal-notification').click(function(){
    jQuery('#upgrade-supplier-acount-modal').modal('show');    
});
$('#sidebar-upgrade-supplier').click(function(){
    jQuery('#upgrade-supplier-acount-modal').modal('show');    
});
$('#show-dashboad-select').click(function(){
    jQuery('#dashboard-select-modal').modal({
        backdrop: 'static',
        keyboard: false
    }); 
       
});
function getQueryStringValue (key) {  
  return unescape(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + escape(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));  
}  
function GetYahooHeaderContact()
{
    App.blockUI({
        target: '#basic-invite',
        animate: true
    });
    
    jQuery.ajax({
        url: '{{url("invite/yahoo/url")}}',
        type: 'get',
        success: function(data) {
                    //window.location.href = data.url;
                    window.open(data.url,'_blank');
                    App.unblockUI('#basic-invite');
                 },
        done: function() {
            App.unblockUI('#basic-invite');
            //console.log('error');
        },
        error: function() {
            //console.log('error');
        }
        
    }); 
}
</script>
<script>

$(document).ready(function() {

    $('input[name="user_type"]').on('click change', function(e) {
        //console.log($('[name="user_type"]:checked').val());
        var vals = $('[name="user_type"]:checked').val().split('_');
        if(vals[0] == 3)
        {
            window.location.href = "{{url('dashboard/buyer')}}?pulsate="+vals[1];
        }
        else
        {
            window.location.href = "{{url('dashboard/supplier')}}?pulsate="+vals[1];
        }
    });
    
    var pulsate_val = $('#pulsate-val').val();
    if(pulsate_val == 1)
    {
        $(".pulsate-one-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 100,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    }
    else if(pulsate_val == 2)
    {
        $(".pulsate-two-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 100,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    }
    else if(pulsate_val == 3)
    {
        $(".pulsate-three-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 100,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    }
    else if(pulsate_val == 4)
    {
        $(".pulsate-four-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 100,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    }
    else if(pulsate_val == 5)
    {
        $(".pulsate-five-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 100,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    }
    else if(pulsate_val == 6)
    {
        $(".pulsate-six-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 100,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    }
    else if(pulsate_val == 7)
    {
        $(".pulsate-seven-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 100,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    }
    else if(pulsate_val == 8)
    {
        $(".pulsate-eight-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 100,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    }
    if(pulsate_val > 0)
    {
        $.getJSON("{{url('clear/pulsate/session')}}",
        function(data) {
            //doSomethingWith(data); 
        });
    }
		
 });


</script>

<script>
function clock(){
    
    var totalSeconds = 10;
    $('#timer').html();
    $('#timer').html('<button class="btn btn-circle yellow-crusta color-black bold" id="clock" type="button" data-dismiss="modal"> Continue (<label id="seconds">0'+totalSeconds+'</label>)</button><div ></div>');
         
        setInterval(setTime, 1000);
        function setTime()
        {
            --totalSeconds;
            if(totalSeconds != 0){
                $('#clock > #seconds').html(pad(totalSeconds%60));
                $('#clock > #minutes').html(pad(parseInt(totalSeconds/60)));    
            }
            else
            {
                $.getJSON("{{url('clear/session/new_user_first')}}",
                function(data) {
                    //doSomethingWith(data); 
                });
                $('#user-welcome-modal').modal('hide');
                
            }
        }
        function pad(val)
        {
            var valString = val + "";
            if(valString.length < 2)
            {
                return "0" + valString;
            }
            else
            {
                return valString;
            }
        }
}

// for tutorial
$(document).ready(function(){
   var _slides = [
            {
    		 content: '<b>Get Pricing Options</b><br/><span>Get Pricing Options using our Quote-Lead System.<span><br/><br/><b>Receive New Leads</b><br/><span>Receive more Sales Leads using our Quote-Lead System.</span>',
    		 selector: '#buyer-tool-main-menu',
             position: 'right-top',
    		 title: '<b>Quote-Lead System</b>'
    		},
    		{
    		 content: 'Feel free to jump back-and-forth between buying and selling features.',
    		 selector: '#switch-crm-menu',
    		 position: 'bottom-left',
    		 title: 'Toggle between Supplier and Buyer',
             onNext: function(){
                    $("#marketplace-main-menu").addClass("active");
                	$('#marketplace-menu-arrow').addClass('open');
                    $.tutorialize.next();
                }
    		},
    		{
    		 content: 'Post and Search Items in a New Industrial-Only Market.',
    		 selector: '#marketplace-main-menu',
    		 position: 'right-top',
    		 title: 'Indy John Market',
             onNext: function(){
                    $("#marketplace-main-menu").removeClass("active");
                	$('#marketplace-menu-arrow').removeClass('open');
                    $("#jobs-main-menu").addClass("active");
                	$('#jobs-main-menu-arrow').addClass('open');
                    $.tutorialize.next();
                },
             onPrev: function(){
                    $("#marketplace-main-menu").removeClass("active");
                	$('#marketplace-menu-arrow').removeClass('open');
                    $.tutorialize.prev();
                }
    		},
    		{
    		 content: 'Post and Search for Industrial Jobs on our Job Board.',
    		 selector: '#jobs-main-menu',
    		 position: 'right-bottom',
    		 title: 'Job Board',
             onNext: function(){
                    $("#jobs-main-menu").removeClass("active");
                	$('#jobs-main-menu-arrow').removeClass('open');
                    $.tutorialize.next();
                },
             onPrev: function(){
                    $("#marketplace-main-menu").addClass("active");
                	$('#marketplace-menu-arrow').addClass('open');
                    $("#jobs-main-menu").removeClass("active");
                	$('#jobs-main-menu-arrow').removeClass('open');
                    $.tutorialize.prev();
                }
    		},
    		{
    		 content: 'Gain an edge by upgrading your account',
    		 selector: '#upgrade-supplier-modal',
    		 position: 'bottom-right',
    		 title: 'Upgrade your Account',
             onNext: function(){
                    $("#account-main-menu").addClass("active");
                	$('#account-main-menu-arrow').addClass('open');
                    $.tutorialize.next();
                },
             onPrev: function(){
                    $("#jobs-main-menu").addClass("active");
                	$('#jobs-main-menu-arrow').addClass('open');
                    $.tutorialize.prev();
                }
    		},
    		{
    		 content: 'Get verified and gain trust Online.',
    		 selector: '#quotetek-user-verification-menu',
    		 position: 'right-top',
    		 title: 'Verify your Account',
             onNext: function(){
                    $("#account-main-menu").removeClass("active");
                	$('#account-main-menu-arrow').removeClass('open');
                    $.tutorialize.next();
                },
             onPrev: function(){
                    $("#account-main-menu").removeClass("active");
                	$('#account-main-menu-arrow').removeClass('open');
                    $.tutorialize.prev();
                }
    		  
            },
    		{
    		 content: 'Grow your network by inviting others.',
    		 selector: '#invite-user-header',
             position: 'bottom-right',
    		 title: 'Invite Users',
             onNext: function(){
                    $("#referrals-main-menu").addClass("active");
                	$('#referrals-main-menu-arrow').addClass('open');
                    $.tutorialize.next();
                },
             onPrev: function(){
                    $("#account-main-menu").addClass("active");
                	$('#account-main-menu-arrow').addClass('open');
                    $.tutorialize.prev();
                }
    		},
            {
    		 content: 'Start Referring and Earning now.',
    		 selector: '#referrals-main-menu',
    		 position: 'right-top',
    		 title: 'Refer Users',
             onNext: function(){
                    $("#referrals-main-menu").removeClass("active");
                	$('#referrals-main-menu-arrow').removeClass('open');
                    $.tutorialize.next();
                },
             onPrev: function(){
                    $("#referrals-main-menu").removeClass("active");
                	$('#referrals-main-menu-arrow').removeClass('open');
                    $.tutorialize.prev();
                }
    		},
            {
    		 content: 'Streamline the Indy John process.',
    		 selector: '#header-quick-start',
    		 position: 'bottom-left',
    		 title: 'Quick Start',
             onPrev: function(){
                    $("#referrals-main-menu").addClass("active");
                	$('#referrals-main-menu-arrow').addClass('open');
                    $.tutorialize.prev();
                }
    		}
    ];
    
    
    
    //$.tutorialize.start();
    if(getQueryStringValue("setup") == 'tutorial') 
    {
        $.tutorialize({
         slides: _slides,
         arrowPath: "{{url('public/tutorialize/arrows/arrow-red.png')}}",
         bgColor: '#ea6f5d',
         buttonBgColor: '#ea6f5d',
         buttonFontColor: '#fff',
         fontColor: '#666',
         padding:'0px',
         overlayMode: 'focus',
         showClose: true,
         theme: 'lined',
         width: 350,
         onStop: function(){
    				jQuery('#dashboard-select-modal').modal({
                        backdrop: 'static',
                        keyboard: false
                    });
    			}
        });
       $.tutorialize.start();
    }
    
    if(getQueryStringValue("setup") == 'company_admin') 
    {
       $.tutorialize({
         slides: _slides,
         arrowPath: "{{url('public/tutorialize/arrows/arrow-red.png')}}",
         bgColor: '#ea6f5d',
         buttonBgColor: '#ea6f5d',
         buttonFontColor: '#fff',
         fontColor: '#666',
         padding:'0px',
         overlayMode: 'focus',
         showClose: true,
         theme: 'lined',
         width: 350,
         onStop: function(){
    				jQuery('#dashboard-select-modal').modal({
                        backdrop: 'static',
                        keyboard: false
                    });
    			}
        });
       $.tutorialize.start(); 
    }    
            
    //setTimeout(function(){ $.tutorialize.start(); }, 2000); 
});

</script> 

<!-- END FOOTER -->
