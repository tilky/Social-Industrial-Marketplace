@extends('buyer.app')

@section('content')

<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url()}}/user-dashboard">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="{{url()}}/supplier-quotes">Quotes</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>View</span>
        </li>
    </ul>
</div>

<div class="row">
    <div class="col-md-12">
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
        <div class="portlet box red">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-server"></i>Quote Sent to {{$userData->first_name}} {{$userData->last_name}} 
                </div>
            </div>
            <div class="portlet-body form">
                @if (Session::has('message'))
                    <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
                @endif
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-12 padding-top">
                            <h3>Quote Items</h3>
                            <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                <thead>
                                <tr>
                                    <th> Sr. No. </th>
                                    <th> Item Title </th>
                                    <th> Description </th>
                                    <th> Quantity </th>
                                    <th> Price </th>
                                    <th> Total Max Quantity  </th>
                                </tr>
                                </thead>
                                <tbody>
                                    @foreach($quotes->SupplierQuoteItems as $index=>$item)
                                        <tr>
                                            <td>{{$index+1}}</td>
                                            <td>{{$item->title}}</td>
                                            <td>{{$item->description}}</td>
                                            <td>{{$item->qty}}</td>
                                            <td>{{$item->price}}</td>
                                            <td>{{$item->max_qty}}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-12 padding-top">
                            <p>Shipping Fee: {{$quotes->shipping_fee}}</p>
                            <p>Shipped Via: {{$quotes->shipped_via}}</p>
                            <p>Payment Terms: {{$quotes->payment_terms}}</p>
                            <p>Payment Via: {{$quotes->payment_via}}</p>
                            <p>Estimated Time to make: {{$quotes->estimated_time}} hrs</p>
                            <p>Estimated Delivery by: {{$quotes->estimated_delivery}}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>
<script>
/* for show menu active */
$("#quote-main-menu").addClass("active");
$('#quote-main-menu' ).click();
$('#quote-menu-arrow').addClass('open')
$('#quote-sent-menu').addClass('active');
/* end menu active */

</script>
@endsection
