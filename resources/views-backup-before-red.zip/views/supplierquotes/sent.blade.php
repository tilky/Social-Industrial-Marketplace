@extends('buyer.app')

@section('content')
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url()}}/user-dashboard">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>Supplier Quotes</span>
        </li>
    </ul>
</div>
<div class="col-md-12 main_box">
<div class="row">
<div class="col-md-12 border2x_bottom">
<h3 class="page-title uppercase"> 
<i class="fa fa-rocket"></i> Quotes Sent Out
</h3>
</div>
</div>
<div class="row">
    <div class="col-md-12">
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet-body">
            
                @if (Session::has('message'))
                    <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
                @endif
                <div class="padding-top">
                        <p class="caption-helper">Thank you for using Indy John. Browse your quoting history here. </p>
                    </div>
                <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                    <thead>
                    <tr>
                        <th> Sr. No. </th>
                        <th> Sent to </th>
                        <th> Item count </th>
                        <th> Status </th>
                        <th> Action </th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach ($SupplierQuotes as $index=>$quote)
                    <tr class="odd gradeX">
                        <td>{{$index+1}}</td>
                        <td>{{ $quote->buyerData->name }}</td>
                        <td>
                            {{count($quote->SupplierQuoteItems)}}
                        </td>
                        <td>
                            @if($quote->status == 0)
                            <span class="label label-sm label-danger"> Unaccepted </span>
                            @else
                            <span class="label label-sm label-info"> Accepted </span>
                            @endif
                        </td>
                        <td>
                            <a href="{{url('supplier-sent-quote/view')}}/{{$quote->id}}" class="btn btn-circle btn-success btn-sm">
                                <i class="fa fa-eye"></i> View </a>
                        </td>
                    </tr>
                    @endforeach
                    </tbody>
                </table>
                <ul class="pager">
                    @if($previousPageUrl != '')
                    <li class="previous">
                        <a href="{{$previousPageUrl}}"> <i class="fa fa-long-arrow-left"></i> Prev </a>
                    </li>
                    @endif
                    @if($nextPageUrl != '')
                    <li class="next">
                        <a href="{{$nextPageUrl}}"> Next <i class="fa fa-long-arrow-right"></i> </a>
                    </li>
                    @endif
                </ul>
            </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>
</div>
<script>
    /* for show menu active */
    $("#quote-main-menu").addClass("active");
	$('#quote-main-menu' ).click();
	$('#quote-menu-arrow').addClass('open')
	$('#quote-sent-menu').addClass('active');
    /* end menu active */
    
    
</script>
@endsection
