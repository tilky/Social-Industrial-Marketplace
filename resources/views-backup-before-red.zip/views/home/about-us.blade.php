@extends('home.app')
@section('content')
@include('home.header')
<!--======================= layout ========================-->

<div class="small-layout animatedParent" style="background-image: url('{{URL::asset('public/livesite/images/banners/1.jpg')}}') ;">
    <div class="mask"></div>
    <h1 class="header_middle text-center animated bounceInDown slower go">About Us</h1>
</div>


<!--=======================================================-->



<!--======================= Navbar ========================-->
<div class="simple-navbar text-center relative">
    <ul class="list-inline">
        <li class="active"><a href="{{url('about-us')}}">About Us</a></li>
        <li><a href="{{url('faq')}}">FAQ</a></li>
        <li><a href="{{url('news')}}">Indy John News</a></li>
        <li><a href="{{url('investor-outreach')}}">Investor Outreach</a></li>
        <li><a href="{{url('contact-us')}}">Contact Us</a></li>
    </ul>
    <div class="vertical_lines"></div>
</div>
<!--=======================================================-->

<div class="section mincontainer_height animatedParent">
    <div class="container">
        <div class="col-md-12">
            <h3>About Indy John</h3>

            <p>Connecting today's professionals is not enough and going forward people will use more third party tools and services. What if there was an Industrial marketplace built on a social selling platform that was designed to simplify the experience and consolidate the processes of Buyers and Suppliers? </p>

           
            <p>Well that is Indy John and that is exactly what we built, the first Everything Industrial social selling platform for Buyers and Suppliers. We've very recently expanded our customer outreach and upgraded our platform with new features and tools, all designed to benefit our users. </p>
<p> <a href="{{url('/')}}">Create your free account</a>, take a look for yourself and begin exploring.</p>

        </div>
        <div class=" col-md-12">
            <h3>The Indy John Team</h3>

            <p>

                Indy John is a startup company with a clear vision, preparing for big expansion.  Our team is made up of experienced industrial, business, and technical professionals.  Since our launch in 2014, our company has gone through exciting changes and we truly believe we are building something great to offer the industrial world.  Customer feedback continues to pour in, so our platform will remain in expansion mode focused on building new features and tools to ensure the success of our users.</p>
            <p>And yes, we do have a simple mission statement - Our goal is to Simplify the experience and Consolidate all processes of Industrial Buyers and Suppliers.</p>

            <p>Feel free to <a href="{{url('contact-us')}}">reach out to us</a>, we'd love to hear your thoughts or ideas.</p>

        </div>






    </div>
</div>

<div class="clearfix"></div>
@include('home.footerlinks')
@endsection
