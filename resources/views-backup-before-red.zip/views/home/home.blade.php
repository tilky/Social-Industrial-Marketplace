@extends('home.app')
@section('content')
@include('home.header')
<div class="banner_content animatedParent ">
  <div class="container">
    <h1 class="banner_header animated bounceInDown slower">Welcome TO <span>Indy John</span></h1>
    <h3 class="h5_head  animated bounceInUp slower">A Social Marketplace for the <span>Industrial World</span>.</h3>
    <h3 class="h3_head  animated bounceInUp slower text-uppercase nomargin-bottom margintop60"><b>As a Buyer, you can : </b></h3>
    <div class="button_section">
      <ul class="clearfix animated bounceInUp findMe">
        <li><a href="#" class="btn btn-circle " data-toggle="popover" data-placement="top" data-trigger="focus" data-content="Submit one buy request and we’ll bring the suppliers to you.">Receive Product Quotes</a></li>
        <li><a href="#" class="btn" data-toggle="popover"  data-placement="top" data-trigger="focus" data-content="Meet new companies and leave your worries behind.">Find Trusted Suppliers</a></li>
        <li><a href="#" class="btn" data-toggle="popover" data-placement="top" data-trigger="focus" data-content="Finally, a market focused on Industrial products and supplies.">Explore Market Listings</a></li>
        <li><a href="#" class="btn" data-toggle="popover" data-placement="top" data-trigger="focus" data-content="Finding the right service provider is tough, we can help!">Search Service Providers</a></li>
      </ul>
      <div class="clearfix"></div>
      <!-- signup- form -->
      <div class="signup-form">
        <h3 class="h3_head  animated bounceInUp slower nomargin-bottom margintop60"><b> SIGN UP FOR FREE </b></h3>
        @if(count($errors) > 0)
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                &times;
            </button>
            @foreach ($errors->all() as $error)
            {{ $error }}
            @endforeach
        </div>
        @endif
        <div class="form_div">
        <form method="post" action="{{url('signup/email/verification')}}">
            <input type="hidden" name="_token" value="{{csrf_token()}}" />
            @if(isset($_GET['referral']))
            <input type="hidden" name="referral_singup" value="{{$_GET['referral']}}" />
            @endif
          <div class="form">
            <div class="form-inline ">
              <div class="form-group col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                    <input type="hidden" name="user_type" id="home-user-type" value="2" />
                    <input type="email" class="form-control" id="home-email" name="email" value="{{Request::old('email')}}" placeholder="Enter your E-mail address" required="">
                </div>
              </div>
              <div class="form-group btn_signup text-center col-md-2 col-sm-2 col-xs-12">
                <div class="row">
                    @if(Auth::check())
                        @if(Auth::user()->access_level == 1)
                            <a href="{{url('sa')}}" class="btn">Sign Up</a>
                        @else
                            <a href="{{url('user-dashboard')}}" class="btn">Sign Up</a>
                        @endif
                    @else
                        <!--<button type="button" onclick="ShowRegisterModal()" data-toggle="modal" data-target="#signup" class="btn">Sign Up</button>-->
                        <button type="submit"  class="btn">Sign Up</button>
                    @endif
                  <div class="row"> </div>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
          </div>
        </form>
        </div>
        <h6>By Signing Up, You Agree To Our <a href="terms">Terms & Conditions</a> & <a href="privacy-policy">Privacy Policy</a>.</h6>
      </div>
      <div class="clearfix"></div>
      <div class="text-center clearfix margintop40 service_provider animated growIn slowest"> 
        <a href="{{url('supplier-home')}}@if(isset($_GET['referral']))?referral={{$_GET['referral']}} @endif" class="btn_blue">I'm a Supplier/ Service Provider</a> 
      </div>
    </div>
    <div class="text-center mobile_margin">
      <div class="scrollar_btn"><span class="circle"><span class="dot"></span></span>
        <p>Learn More</p>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
</div>
</div>
<div id="owl-demo" class="owl-carousel paddingTop150">
  <div class="item">
    <div class="slider" style="background-image: url({{URL::asset('public/livesite/images/banner_1.jpg')}})">
      <div class="slider_overlay"> </div>
      <div class="line_image"></div>
      <div class="line_image right"></div>
    </div>
  </div>
  <div class="item">
    <div class="slider" style="background-image: url({{URL::asset('public/livesite/images/banner_2.jpg')}})">
      <div class="slider_overlay"> </div>
      <div class="line_image"></div>
      <div class="line_image right"></div>
    </div>
  </div>
</div>
<div class="section fade animatedParent">
  <div class="container  text-center">
    <h1 class="header_middle">Indy John Is The Industrial Pricing Tool You’ve Been Missing.</h1>
    <div class="col-md-4 iconsection  animated bounceInDown "> <i class="icon"><img src="{{URL::asset('public/livesite/images/multiple.png')}}" height="64px"/></i>
      <h3 class="header_18">Quote-Lead System</h3>
      <p>Submit one buy request and have access to the right suppliers.</p>
    </div>
    <div class="col-md-4 iconsection animated bounceInUp "> <i class="icon"><img src="{{URL::asset('public/livesite/images/icons/promotion.png')}}" height="64px"/></i>
      <h3 class="header_18">Indy John Market</h3>
      <p>List or Browse for new and used industrial products and supplies. </p>
    </div>
    <div class="col-md-4 iconsection animated bounceInDown "> <i class="icon"><img src="{{URL::asset('public/livesite/images/safty.png')}}" height="64px"/></i>
      <h3 class="header_18">Buyer Dashboard</h3>
      <p>Organize your quotes and track all purchasing activity.</p>
    </div>

  </div>
</div>

<div class="color_bg feedback animatedParent paddingTop50"> </div>
<div class="container animatedParent">
  <h3 class="header_middle text-center  animated fadeIn nopadding">How does the Quote-Lead system work?</h3>
  <div class="row redprocess section">
    <div class="leftright_section">
      <div class="col-md-9 col-sm-9 wh_border wh_borderright"><i class="lefticon"><img src="{{URL::asset('public/livesite/images/icons/interface-1.png')}}" alt=""/></i>Make Indy John your go-to place for purchasing industrial products and services.</div>
      <div class="number_text left_icon hovicon effect-1 animation-element slide-left">1</div>
    </div>
    <div class="clearfix"></div>
    <div class="leftright_section pull-right border_middle_ver">
      <div class="number_text right_icon hovicon animation-element slide-right">2</div>
      <div class="col-md-9 col-sm-9 wh_border wh_borderleft"><i class="lefticon"><img src="{{URL::asset('public/livesite/images/icons/college-research.png')}}"  alt=""/></i> Start by searching your desired products or services and submit a buy request.</div>
    </div>
    <div class="clearfix"></div>
    <div class="leftright_section">
      <div class="col-md-9 col-sm-9 wh_border wh_borderright"><i class="lefticon"><img src="{{URL::asset('public/livesite/images/icons/folder.png')}}" alt=""/></i>Sit back and allow Indy John suppliers to contact you with quotes.</div>
      <div class="number_text left_icon hovicon animation-element slide-left">3</div>
    </div>
  </div>
</div>
<div class="clearfix"></div>
<div class="color_bg feedback animatedParent padding100">
  <div class="container">
    <button type="button" class="btn_red  hvr-bounce-to-right head_railway  text-center animated shake slower scrolltotop"> Sign up Today for Free</button>
  </div>
</div>
<a href="#job_board" data-toggle="modal" data-target="#job_board" class="job_board">JOB BOARD</a>
@include('home.footerlinks')
@endsection
