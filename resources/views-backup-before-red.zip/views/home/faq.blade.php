@extends('home.app')
@section('content')
@include('home.header')
<link href="{{URL::asset('public/metronic/assets/pages/css/faq.min.css')}}" rel="stylesheet" type="text/css" />
<div class="faq-page">
<!--======================= layout ========================-->

<div class="small-layout" style="background-image: url('{{URL::asset('public/livesite/images/banners/8.jpg')}}') ;">
    <div class="mask"></div>
    <h1 class="header_middle text-center animated bounceInDown slower go">Frequently Asked Questions</h1>
</div>


<!--=======================================================-->



<!--======================= Navbar ========================-->
<div class="simple-navbar text-center relative">
    <ul class="list-inline">
        <li><a href="{{url('about-us')}}">About Us</a></li>
        <li class="active"><a href="{{url('faq')}}">FAQ</a></li>
        <li><a href="{{url('news')}}">Indy John News</a></li>
        <li><a href="{{url('investor-outreach')}}">Investor Outreach</a></li>
        <li><a href="{{url('contact-us')}}">Contact Us</a></li>
    </ul>
     <div class="vertical_lines"></div>
</div>


<!--=======================================================-->



<!--======================= Questions  ========================-->

<section class="container">
<h3>Frequently Asked Questions  <small class="expand-all">(expand all)</small></h3>
<div class="faq-content-container">
                                <div class="col-md-6">
                                    <div class="faq-section ">
                                        <h2 class="faq-title uppercase ">General</h2>
                                        <div class="panel-group accordion faq-content" id="accordion1">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_1"> How do I vote or respond to a poll?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_1" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_2"> Do you accept purchase orders?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_2" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_3"> How many responses per poll (which plan) do I need?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_3" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_4"> What if my audience does not have a phone or a web-enabled device with internet access?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_4" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_6"> How fast do responses show up?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_6" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-section ">
                                        <h2 class="faq-title uppercase ">Technical</h2>
                                        <div class="panel-group accordion faq-content" id="accordion3">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_1"> How do I vote or respond to a poll?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_3_1" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_2"> Do you accept purchase orders?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_3_2" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_3"> How many responses per poll (which plan) do I need?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_3_3" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_4"> What if my audience does not have a phone or a web-enabled device with internet access?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_3_4" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_5"> How can I share my poll with remote participants?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_3_5" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">

                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapse_3_6"> How fast do responses show up?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_3_6" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="faq-section ">
                                        <h2 class="faq-title uppercase ">Pricing</h2>
                                        <div class="panel-group accordion faq-content" id="accordion2">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_2_1"> How much does it cost?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_2_1" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_2_2"> Do you accept purchase orders?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_2_2" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_2_3"> What is the K-12 classroom size promise?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_2_3" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_2_4"> What if my audience does not have a phone or a web-enabled device with internet access?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_2_4" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_2_5"> How can I share my poll with remote participants?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_2_5" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_2_6"> How fast do responses show up?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_2_6" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-section ">
                                        <h2 class="faq-title uppercase ">Admin Management</h2>
                                        <div class="panel-group accordion faq-content" id="accordion4">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion4" href="#collapse_4_1"> How do I vote or respond to a poll?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_4_1" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion4" href="#collapse_4_2"> Do you accept purchase orders?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_4_2" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion4" href="#collapse_4_3"> How many responses per poll (which plan) do I need?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_4_3" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion4" href="#collapse_4_4"> What if my audience does not have a phone or a web-enabled device with internet access?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_4_4" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        
                                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion4" href="#collapse_4_5"> How can I share my poll with remote participants?</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse_4_5" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <p> Duis autem vel eum iriure dolor in hendrerit in vulputate. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut. </p>
                                                        <p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
                                                            eiusmod. </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>
  <!--  <div class="section-content">
        <h3>Frequently Asked Questions  <small class="expand-all">(expand all)</small></h3>
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingOne">
                    <h4 class="panel-title ">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
     <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>What is Indy John ?     </b> </a>
</h4>
                </div>
                <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                    <div class="panel-body">
                        <p>
                           Indy John is the first Industrial marketplace built on a social selling platform, created for the industrial world.  
                        </p>
                    </div>
                </div>
            </div>
			
			
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingTwo">
                    <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="false" aria-controls="collapse1">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>How does Indy John work?     </b>
</a>
</h4>
                </div>
                <div id="collapse1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                    <div class="panel-body">
                        <p>
                           Indy John is easy to use. Whether you're a buyer or supplier, you will be required to create an account and choose how you want to use your account. Once you completed the quick sign up process, you will be given a Buyer dashboard for purchasing and a Supplier CRM for selling. Feel free to use one or both of these features. Please visit our Buyer Features page and Supplier Network page for details.
                        </p>

                    </div>
                </div>
            </div>
		<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading1"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="false" aria-controls="collapse1">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
What Is The Quote-Lead System?
   </b></a></h4></div><div id="collapse1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading1"><div class="panel-body"><p>
The system is a more efficient way for industrial Buyers and Suppliers to perform their jobs.  We’ll match and connect Buyers and Suppliers based on product and service keywords.  This will result in pricing options for Buyers and increased selling opportunities for Suppliers. We’ve also thrown in a Buyer Dashboard and Supplier CRM for users, designed to better manage all quote-lead system activity.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading3"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="false" aria-controls="collapse3">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Does Indy John Work?
   </b></a></h4></div><div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3"><div class="panel-body"><p>
Indy John is easy to use. Whether you’re a buyer or supplier, you will be required to create a free account and choose how you want to use your account. Once you completed the quick sign up process, all users are given a Buyer dashboard for purchasing and a Supplier CRM for selling. Feel free to use one or both of these features. Please visit our Buyer Features page and Supplier Network page for details.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading4"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="false" aria-controls="collapse4">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
   Can I Use Both Buyer Dashboard and Supplier CRM features?
   </b></a></h4></div><div id="collapse4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading4"><div class="panel-body"><p>
Yes, we understand most Indy John users will be Dual Feature users.  Once your signed up, please feel free to jump back and forth between Buying and Supplying.
</p></div></div></div>


<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading5"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="false" aria-controls="collapse5">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Is There A Cost For using Indy John?
   </b></a></h4></div><div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading5"><div class="panel-body"><p>
Our core marketplace is free to use and most features are included in the free account. We do offer a Buyer+ account for more serious buyers and valued accounts for suppliers with higher sales and marketing goals. 
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading6"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse6" aria-expanded="false" aria-controls="collapse6">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Do I Upgrade My User Account?
   </b></a></h4></div><div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading6"><div class="panel-body"><p>
Every Buyer Dashboard and Supplier CRM has an UPGRADE icon, it’s an easy process, simply click and select the account that works best for you.  Provide us some billing details and continue using Indy John with additional advantages.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading6"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse6" aria-expanded="false" aria-controls="collapse6">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
What Is The Indy John Market?
   </b></a></h4></div><div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading6"><div class="panel-body"><p>
Indy John Market is a brand new Industrial-Only market.  All users can Purchase, Sell, or casually shop for products and supplies. 
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading8"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse8" aria-expanded="false" aria-controls="collapse8">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Can Anyone Post Products On The Indy John Market?
   </b></a></h4></div><div id="collapse8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading8"><div class="panel-body"><p>
Yes! Indy John Market is free to use for all users, list up to 30 products with a free account. Looking to do more with our market, see our valued accounts for details.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading9"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse9" aria-expanded="false" aria-controls="collapse9">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
What Can Indy John’s Search Help Me Find?
   </b></a></h4></div><div id="collapse9" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading9"><div class="panel-body"><p>
Our Search Discovery can help you in many ways.  We can help you locate Products, People, Companies, and Service Providers.  
</p></div></div></div>


<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading10"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse10" aria-expanded="false" aria-controls="collapse10">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Does Indy John manage payments between Buyers and Suppliers?
   </b></a></h4></div><div id="collapse10" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading10"><div class="panel-body"><p>
At this time, Indy John does not manage payments for transactions. However, upon completing the transaction, we encourage you to evaluate and leave a user review.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading11"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse11" aria-expanded="false" aria-controls="collapse11">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Do I Gain Trust Of Other Users On Indy John?
   </b></a></h4></div><div id="collapse11" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading11"><div class="panel-body"><p>
We do encourage all of our users to establish their account and become verified in order to make full use of our services. This is one way to ensure you’re doing a trustworthy business deal. Verification is done by email, phone number, or social media profile. Upon completion, a verified seal will be attached to your account and displayed when you connect with other users. There is a fee for this verification as it includes a comprehensive background check. Visit Verification tab in your Dashboard to learn more.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading12"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse12" aria-expanded="false" aria-controls="collapse12">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Is There A Mobile Application For Indy John?
   </b></a></h4></div><div id="collapse12" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading12"><div class="panel-body"><p>
No, our mobile application is coming soon.  However, IndyJohn.com is a mobile compatible website. 
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading13"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse13" aria-expanded="false" aria-controls="collapse13">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Do I Sign Up To Start Referring And Earning?
   </b></a></h4></div><div id="collapse13" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading13"><div class="panel-body"><p>
It’s easy.  Once you’re signed up on Indy John, we’ll generate you a referral code or you can simply share your Indy John profile link with friends and associates.  Each Buyer Dashboard and Supplier CRM has a Referral Center with more instruction and details on how to manage your referrals and payouts.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading14"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse14" aria-expanded="false" aria-controls="collapse14">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Much Can I Earn By Referring Others?
   </b></a></h4></div><div id="collapse14" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading14"><div class="panel-body"><p>
You can earn up to $100 per paid account that you refer. If they sign up, but choose a free account, our system will make a record and your referral bonus will be paid when they become a paying customer.
</p></div></div></div>


<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading15"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse15" aria-expanded="false" aria-controls="collapse15">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Is There A Solution For Sales Teams And Company Administrators?
   </b></a></h4></div><div id="collapse15" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading15"><div class="panel-body"><p>
Indy John is easy to use. Whether you're a buyer or supplier, 
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading16"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse16" aria-expanded="false" aria-controls="collapse16">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
   How does Indy John work?
   </b></a></h4></div><div id="collapse16" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading16"><div class="panel-body"><p>
At this time, we offer corporate accounts for companies with 5 or more paid users. We consider these customized accounts and are built to a company’s specific needs, all designed to help you better manage and organize your data.  Please contact us at sales@indyjohn.com to learn more.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading17"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse17" aria-expanded="false" aria-controls="collapse17">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Can My Company Partner or Advertise With Indy John?
   </b></a></h4></div><div id="collapse17" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading17"><div class="panel-body"><p>
Let’s talk, were currently looking for strategic partnerships and limited advertising is now available.  Please visit our Marketing Solutions page for details.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading18"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse18" aria-expanded="false" aria-controls="collapse18">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Do I Contact Indy John For User Help Or General Questions?
   </b></a></h4></div><div id="collapse18" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading18"><div class="panel-body"><p>
Please visit our Contact Us page and message us, we’ll aim to address all issues in a timely manner. You can also log in and submit a Support ticket from the Main menu.
</p></div></div></div>



			          




        </div>
    </div>-->

</section>

<!--=======================================================-->
</div>
@include('home.footerlinks')
@endsection
