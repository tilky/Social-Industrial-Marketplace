@extends('home.app')
@section('content')
@include('home.header')

<!--======================= layout ========================-->

<div class="small-layout animatedParent" style="background-image: url('{{URL::asset('public/livesite/images/banners/1.jpg')}}') ;">
    <div class="mask"></div>
    <h1 class=" header_middle text-center animated bounceInDown slower go">Terms and Conditions</h1>
</div>


<!--=======================================================-->






<!--======================= Questions  ========================-->

<section class="questions-answers container">
            <div class="section-content">
                <div class="question">


               


<p><strong>Thank you for your interest  in Indy John.</strong></p>
<p>  Indy John is a virtual marketplace located at <a href="http://www.indyjohn.com">www.indyjohn.com</a> (the &ldquo;Site&rdquo;) for sellers and buyers of  industrial equipment, materials and services (the &ldquo;Service&rdquo;).  The Service is owned, and operated by Indy John,  Inc. (&ldquo;Indy John,&rdquo; &ldquo;we,&rdquo; &ldquo;our,&rdquo; or &ldquo;us&rdquo;).   The generic terms &ldquo;you,&rdquo; &ldquo;your,&rdquo; and &ldquo;yours&rdquo; refer to all users of the Service  irrespective of whether offering to sell, selling, browsing or buying industrial  equipment, materials and services (the&nbsp;&ldquo;Merchandise&rdquo;).  The term &ldquo;seller&rdquo; specifically refers to  users offering to sell their Merchandise, and the term &ldquo;buyer&rdquo; specifically  refers to users buying the Merchandise, through the Service.<br>
</p>
<p>IMPORTANT – PLEASE READ CAREFULLY:  THESE INDY JOHN TERMS OF SERVICE CONSISTING  OF THE GENERAL TERMS AND CONDITIONS, SELLING ON INDY JOHN TERMS AND CONDITIONS  AND BUYING ON INDY JOHN TERMS AND CONDITIONS (COLLECTIVELY, THE &ldquo;TERMS&rdquo;) ALONG  WITH ALL THE RULES, POLICIES AND GUIDELINES INCORPORATED IN THESE TERMS BY  REFERENCE CONSTITUTE A LEGALLY BINDING AGREEMENT BETWEEN INDY JOHN AND YOU  (EITHER AN INDIVIDUAL OR A SINGLE ENTITY) AND GOVERN YOUR USE OF THE SERVICE TO  LIST, SELL, OFFER TO SELL OR PURCHASE THE MERCHANDISE.  BY REGISTERING TO OPEN AN ACCOUNT AND/OR USING  THE SERVICE, YOU (ON BEHALF OF YOURSELF OR THE BUSINESS OR ENTITY YOU  REPRESENT) AGREE AND ACKNOWLEDGE TO BE BOUND BY THESE TERMS.  IF YOU DO NOT AGREE TO BE BOUND BY THESE  TERMS, PLEASE DO NOT USE THE SERVICE.<br>
  WE RESERVE THE RIGHT TO MODIFY THESE TERMS AT ANY  TIME, AND EACH SUCH MODIFICATION SHALL BE EFFECTIVE UPON POSTING.  ALL MATERIAL MODIFICATIONS WILL APPLY  PROSPECTIVELY ONLY.  YOU&rsquo;RE CONTINUED USE  OF THE SERVICE FOLLOWING ANY SUCH MODIFICATION CONSTITUTES YOUR AGREEMENT TO BE  BOUND BY THESE TERMS, AS MODIFIED.  IF  ANY MODIFICATION IS NOT ACCEPTABLE TO YOU, YOUR SOLE REMEDY AND RECOURSE IS TO  DISCONTINUE USE OF THE SERVICE.   THEREFORE, IT IS IMPORTANT FOR YOU TO REVIEW THESE TERMS REGULARLY.</p>
<p><strong>I.  GENERAL TERMS AND CONDITIONS:</strong></p>
<p>  These General Terms and Conditions are a part of the Indy John Terms of  Service and apply to all users of the Service, whether offering to sell,  selling, browsing or buying Merchandise through the Service.<strong> </strong><br>
</p>
<p><strong>Eligibility -</strong><br>
</p>
<p>To use the Service, you must be able to enter into a binding contract  under the applicable laws.  If you are an  individual, you represent that you are 18 years of age or over, or of the legal  age to form a binding contract in your jurisdiction if that age is greater than  18 years.  If you are accepting these  Terms on behalf of a company or other legal entity, you represent that you have  the authority to bind such entity to these Terms.<br>
</p>
<p><strong>Registration -</strong><br>
</p>
<p>You are required to register  and create a unique, password-protected account (&ldquo;your account&rdquo;) in order to  access and use the Service to offer, sell or buy Merchandise.  You agree to: (a)&nbsp;provide true,  accurate, current, and complete information as prompted by the registration  form; and (b)&nbsp;maintain and update such information to keep it true,  accurate, current, and complete at all times.   You authorize us to use any information you provide us (including your  SSN, TIN or EIN) to verify your antecedents and obtain your credit reports  before opening your account.  We reserve  the right to reject your application or delete your account without warning if  you are found to have misrepresented your registration information or you fail  to meet our eligibility criteria.<br>
</p>
<p>You are responsible for  maintaining the confidentiality of your account user name and password.  You agree to (a) immediately notify us of any  unauthorized use of your password or account, or any other breach of security,  and (b) ensure that you exit from your account at the end of each session.  You will be solely responsible for  safeguarding your password and also for any actions under your password and  account, whether authorized by you or not.<br>
</p>
<p><strong>Acceptable Use Policy -</strong><br>
</p>
<p>Subject to your acceptance and compliance with  these Terms, we hereby grant you permission to access and use the Service,  provided that you shall not (and not allow third party to): (i)&nbsp;lead off  the Site to complete transactions in any manner including through links in  emails, chat or phone correspondence with users; (ii)&nbsp;modify, adapt,  translate, or reverse engineer any portion of the Service or the Site; (iii)&nbsp;remove  any copyright, trademark or other proprietary rights notices contained in or on  the Site or Service or in or on any content or other material obtained via the Site  or Service; (iv)&nbsp;use any robot, spider, site search/retrieval application,  or other automated device, process or means to access, retrieve or index any  portion of the Service; (v)&nbsp;access, retrieve or index any portion of the Service  for purposes of constructing or populating a searchable database of business  reviews; (vi)&nbsp;collect or harvest any information about other users or  members (including usernames and/or email addresses) for any purpose; (vii)&nbsp;reformat  or frame any portion of the web pages that are part of the Site; (viii)&nbsp;create  user accounts by automated means or under false or fraudulent pretenses; (ix)&nbsp;create  or transmit unwanted electronic communications such as &ldquo;spam&rdquo; to other users or  members of the Service or otherwise interfere with other users&rsquo; or members&rsquo;  enjoyment of the Service; (x)&nbsp;transmit any viruses, worms, defects, Trojan  horses or other items of a destructive nature; (xi)&nbsp;use the Service to  violate the security of any computer network, crack passwords or security  encryption codes, transfer or store illegal material, including any material  that may be deemed threatening or obscene; (xii)&nbsp;copy or store any content  offered on the Site for other than your own personal use; (xiii)&nbsp;use any  device, software or routine that interferes with the proper working of the Service,  or otherwise attempt to interfere with the proper working of the Service; (xiv)&nbsp;take  any action that imposes, or may impose in our sole discretion, an unreasonable  or disproportionately large load on our IT infrastructure; (xv)&nbsp;use the Service  intentionally or unintentionally, to violate any applicable local, state,  national or international law; or (xv)&nbsp;collect or store personal data  about other users in connection with the prohibited activities described in  this paragraph.<br>
</p>
<p><strong>Indy John Role and Release -</strong><br>
</p>
<p>The Service is an online  marketplace for third-party sellers and buyers to locate or advertise  Merchandise and Services subject to these Terms.  We are neither a seller nor a buyer and we do  not manage payments between buyer and seller.   As a seller, you may list any permitted items of Merchandise or Services  on the Site and, as a buyer, you may locate any product or service offered by the  sellers.  Therefore, if you have a  dispute with a seller or a buyer, you release us, our affiliates (and our  respective officers, directors, agents, subsidiaries, joint ventures and  employees) from claims, demands and damages (actual and consequential) of every  kind and nature, known and unknown, suspected and unsuspected, disclosed and  undisclosed, arising out of, or in any way connected with, such disputes.  In  entering into this release you expressly waive any protections (whether  statutory or otherwise) that would otherwise limit the coverage of this release  to include only those claims which you may know or suspect to exist in your  favor at the time of agreeing to this release.  For example, if you are a California resident,  you waive California Civil Code §1542, which says: &ldquo;A general release does not  extend to claims which the creditor does not know or suspect to exist in his  favor at the time of executing the release, which if known by him must have  materially affected his settlement with the debtor.&rdquo;<br>
</p>
<p>We are not responsible in  any way for actual transaction between a seller and a buyer.  Without limiting the generality of the  foregoing, you acknowledge and agree as follows: (i)&nbsp;we do not participate  in any actual transactions, including, without limitation, negotiations, discussions,  or proposals, and you expressly waive any requirement that purports to impose  on us an obligation to perform any services other than those expressly  undertaken by us; (ii)&nbsp;we do not render legal, brokerage, scientific or  other professional advice or services; in the event you desire or need such  services, we strongly advise you to secure the same; (iii)&nbsp;we are not  undertaking any, and have no, duties to you including, without limitation, the  obligation to screen prospective sellers or buyers; and (iv)&nbsp;while we  comply with applicable state and federal laws, we cannot guarantee that our  users so comply.  Accordingly, we assume  no liability for any user&rsquo;s failures to comply with such laws.</p>
<p><strong>Reservation of Rights</strong><strong> -</strong><br>
</p>
<p>You  acknowledge that the Site, the Service and the underlying software and all  intellectual property rights therein, including copyrights, patent rights,  trade secret rights, and trademark rights, are owned by us.  All rights not expressly granted herein are  reserved by us.  Except as expressly and  specifically set forth in the Terms, nothing herein shall be construed as  granting to you any property right, by license, implication, estoppel, or  otherwise, to any of our intellectual property rights.<br>
  Indy John and its associated  logos are either registered trademarks or trademarks of ours.  All other company names, logos and other  identifying marks that may be listed as part of our Service may be trademarks  of their respective owners.  WE DO NOT  CLAIM ANY OWNERSHIP IN ANY THIRD PARTY&rsquo;S TRADEMARKS NOR DO WE CLAIM ANY  SPONSORSHIP, ASSOCIATION WITH OR ENDORSEMENT BY SUCH THIRD PARTIES.</p>
<p><strong>Your Content -</strong><br>
</p>
<p>We may allow you to post  reviews, comments, photos, and other content; send communications; and submit  suggestions, ideas, comments, questions, or other information (&ldquo;your content&rdquo;)  on the Site.  You are solely responsible  for your content.  Subject to the  licenses you are granting hereunder, you retain all right, title and interest,  including without limitation all worldwide intellectual property rights, in and  to your content.  <br>
</p>
<p>By submitting, posting or  displaying your content on or through the Site, you automatically grant to us a  worldwide, perpetual, royalty-free, irrevocable, non-exclusive, sub-licensable  and transferable right and license to use, reproduce, store, host, index,  cache, distribute (through multiple tiers), publicly perform, publicly display,  (each of the foregoing in any form, medium or technology now known or later  developed), modify and adapt including without limitation the right to adapt  for streaming, downloading, broadcasting, distribution, publicly displaying,  publicly performing (each of the foregoing in any form, medium or technology  now known or later developed), create derivative works from, and exercise all  aforesaid rights with respect to such derivative works, and otherwise exploit  in any manner, your content or any part thereof.  You hereby expressly waive any and all  so-called moral rights you may have in your content.<br>
</p>
<p>You hereby represent and  warrant that your content, (i)&nbsp;and our use thereof pursuant to these Terms  does not and will not, directly or indirectly, violate, infringe or breach any  duty toward or rights of any person or entity, including without limitation any  copyright, trademark, service mark, trade secret, other intellectual property,  publicity or privacy right, (ii)&nbsp;does not contain any material that is  sexual, pornographic, erotic, obscene, indecent or profane in its use of sexual  language or description or depictions of sexual acts, (iii)&nbsp;is not  fraudulent, misleading, hateful, tortuous, defamatory, slanderous, libelous,  abusive, violent, threatening, profane, vulgar or obscene, (iv)&nbsp;does not  harass others, promote bigotry, racism, hatred or harm against any individual  or group, promote discrimination based on race, sex, religion, nationality,  sexual orientation or age, or otherwise interfere with another party&rsquo;s use of  the Service, (v)&nbsp;does not promote illegal or harmful activities or  substances or provide instructional information about activities such as making  or buying illegal weapons or substances, (vi)&nbsp;is not illegal, unlawful or  contrary to the laws or regulations in any state or country where, as  applicable, your content are created, displayed or accessed, (vii)&nbsp;does  not contain any adware, malware, spyware, computer programming routines,  software or viruses that are intended to damage, interfere with or in any way  limit the functionality of any computer software or hardware or  telecommunications equipment, intercept or expropriate any system data or personal  information, permit unauthorized access to the Service or any part thereof or  disable, damage or erase any portion of the content or advertisements processed  or stored therein; or (viii) does not constitute unsolicited bulk email, junk  mail, spam or chain letters.<br>
</p>
<p><strong>Merchandise -</strong><br>
</p>
<p>You are only allowed to list, advertise, and  promote Merchandise and Services through our Service.  We reserve the right to determine whether  your products or services qualify for offering through the Service.  Without limiting the foregoing, following  products are expressly prohibited from being listed through the Service: (a)&nbsp;offensive  materials, including material that incites racial hatred or promotes  discrimination based on race, sex, religion, national origin, physical ability,  sexual orientation or age; (b)&nbsp;obscene materials including pornographic  material; (c)&nbsp;live animals; (d)&nbsp;intoxicating liquor and tobacco and  home-made alcoholic beverages; (e)&nbsp;firearms and ammunition; (f)&nbsp;stolen  goods; (g)&nbsp;advertisements; (h)&nbsp;illegal or prescription drugs; (i)&nbsp;items  whose sale, distribution or offering for sale is prohibited by any applicable  law; (j)&nbsp;offensive weapons, poisons and dangerous substances (as defined  by the applicable law or laws).<br>
</p>
<p><strong>Disclaimer of Warranties -</strong><br>
</p>
<p>THE SITE, THE SERVICE  AND ALL  FEATURES AND FUNCTIONALITIES  ASSOCIATED THEREWITH ARE PROVIDED  &ldquo;AS IS&rdquo; AND &ldquo;AS AVAILABLE&rdquo; WITH ALL FAULTS AND  WITHOUT WARRANTY OF ANY KIND.  YOU EXPRESSLY AGREE THAT YOUR USE OF THE SERVICE  IS AT YOUR SOLE DISCRETION AND  RISK.  YOU ACKNOWLEDGE AND AGREE THAT YOU MUST EVALUATE, AND BEAR  ALL RISKS ASSOCIATED WITH THE USE  OF THE SERVICE AND PURCHASE AND SALE OF MERCHANDISE, AND  ANY CONTENT DESCRIBING THE MERCHANDISE, INCLUDING ANY RELIANCE ON THE ACCURACY,  COMPLETENESS, OR USEFULNESS OF SUCH CONTENT.<br>
</p>
<p>TO THE FULLEST  EXTENT PERMITTED BY LAW, WE DISCLAIM ALL WARRANTIES, INCLUDING, BUT NOT LIMITED  TO, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR PARTICULAR PURPOSE,  NON-INFRINGEMENT AND ANY  IMPLIED WARRANTY ARISING FROM COURSE OF DEALING OR USAGE OF TRADE.  WE DO NOT GUARANTEE, REPRESENT, OR WARRANT  THAT YOUR USE OF THE SERVICE WILL BE UNINTERRUPTED OR ERROR-FREE, AND YOU AGREE  THAT WE MAY ELIMINATE OR OTHERWISE MODIFY ANY OR ALL ASPECTS OF THE SERVICE,  INCLUDING ANY FEATURES THEREOF, WITHOUT COMPENSATION OR NOTICE TO YOU.  WE MAKE NO WARRANTIES ABOUT THE ACCURACY,  RELIABILITY, COMPLETENESS, OR TIMELINESS OF THE SERVICE OR THAT YOUR USE OF THE  SERVICE WILL BE FREE FROM INTERRUPTION, LOSS, CORRUPTION, ATTACK, VIRUSES,  INTERFERENCE, HACKING, OR OTHER SECURITY INTRUSION AND WE DISCLAIM ANY  LIABILITY WITH RESPECT THERETO.<br>
</p>
<p><strong>Limitation of Liability -</strong><br>
</p>
<p>You understand and agree that your use of the  Marketplace is at your own discretion and risk and that you will be solely  responsible for any damages that arise from such use including, without  limitation, for loss of data and or any type of malfunction to your  computer.  IN NO EVENT SHALL WE OR ANY OF  OUR SHAREHOLDERS, DIRECTORS, OFFICERS OR EMPLOYEES BE LIABLE (JOINTLY OR  SEVERALLY) TO YOU FOR PERSONAL INJURY OR ANY SPECIAL, INCIDENTAL, INDIRECT OR  CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES WHATSOEVER RESULTING FROM  LOSS OF USE, DATA OR PROFITS, BUSINESS INTERRUPTION OR ANY OTHER COMMERCIAL  DAMAGES OR LOSS, WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON  ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH YOUR USE OR  PERFORMANCE OF THE SERVICE.  IN NO EVENT  SHALL OUR TOTAL LIABILITY TO YOU OR ANY THIRD PARTY IN ANY CIRCUMSTANCE FOR  LOSSES ARISING FROM THE USE OR INABILITY TO USE THE SERVICE (OTHER THAN AS MAY  BE REQUIRED BY APPLICABLE LAW IN CASES INVOLVING PERSONAL INJURY) EXCEED THE COMMISSION  EARNED BY US FROM THE TRANSACTION GIVING RISE TO THE CLAIM.  THE FOREGOING LIMITATIONS WILL APPLY EVEN IF  THE ABOVE STATED REMEDY FAILS OF ITS ESSENTIAL PURPOSE.  SOME JURISDICTIONS DO NOT ALLOW THE  LIMITATION OF LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES SO SOME OF THE  ABOVE LIMITATIONS MAY NOT APPLY TO YOU.<br>
</p>
<p><strong>Indemnification -</strong><br>
</p>
<p>You will defend, indemnify and hold harmless us  and our affiliates (and their respective employees, directors, agents and  representatives) from and against any and all claims, costs, losses, damages,  judgments, penalties, interest and expenses (including reasonable attorneys&rsquo;  fees) arising out of any claim that arises out of or relates to: (i) any actual  or alleged breach of your representations, warranties, or obligations set forth  in these Terms; or (ii) your use of the Service.<br>
</p>
<p><strong>Basis of the Bargain -</strong><br>
</p>
<p>THE PARTIES ACKNOWLEDGE AND  AGREE THAT THE FOREGOING SECTIONS ON INDEMNIFICATION, WARRANTY DISCLAIMER AND  LIMITATION OF LIABILITY FAIRLY ALLOCATE THE RISKS BETWEEN THE PARTIES AND ARE  ESSENTIAL ELEMENTS OF THE BASIS OF THE BARGAIN BETWEEN THE PARTIES.<br>
</p>
<p><strong>Privacy -</strong><br>
</p>
<p>All information we collect on the Site is subject  to our Privacy Policy located in IndyJohn.com privacy policy page.  By using the Service, you consent to all  actions taken by us with respect to your information in compliance with the  Privacy Policy.  We reserve the right to  send notifications and updates about the Service and as a user of the Service,  you can opt out of receiving such messages in accordance with the Privacy  Policy.<br>
</p>
<p>You will not, and will cause your affiliates not  to, directly or indirectly disclose, convey or use any order information or other  data or personal information acquired by you or your affiliates from us as a  result of your use of the Service or the transactions contemplated hereby,  except as necessary for you to perform your obligations, provided that you  ensure that every recipient uses the information only for that purpose and  complies with the restrictions applicable to you related to that information.</p>
<p><strong>Anonymous Data Collection</strong><strong> -</strong><br>
</p>
<p>We shall  have the right to utilize data capture, syndication, analysis tools, and other  similar tools to extract, compile, synthesize, and analyze any non-personally  identifiable data or information resulting from your use of the Service (&ldquo;anonymous  data&rdquo;).  To the extent that any anonymous  data is collected by us, such data shall be solely owned by us and may be used  by us for any lawful business purpose without a duty of accounting to you  therefor; provided, that the anonymous data is used only in an aggregated form,  without specifically identifying the source of the anonymous data.<br>
</p>
<p><strong>General -</strong><br>
</p>
<p>These Terms shall be governed by and construed in  accordance with the laws of the State of California, excluding its conflicts of  laws principles.  The United Nations  Convention on Contracts for the International Sale of Products is excluded and  does not apply to these Terms.  If any  dispute relating in any way to these Terms or the policies or your use of the Service  shall be submitted to confidential arbitration in Los Angeles County,  California, USA, except that, to the extent you have in any manner violated or  threatened to violate our intellectual property rights, we may seek injunctive  or other appropriate relief in any state or federal court in the State of  California, USA and you consent to exclusive jurisdiction and venue in such  courts.  Arbitration under these Terms  shall be administered by JAMS pursuant to its Streamlined Arbitration Rules and  Procedures.  The arbitrator&rsquo;s award shall  be binding and may be entered as a judgment in any court of competent  jurisdiction.  To the fullest extent  permitted by applicable law, no arbitration under these Terms shall be joined  to an arbitration involving any other party subject to these Terms, whether  through class arbitration proceedings or otherwise.  The failure to require performance of any  provision shall not affect our right to require performance at any time  thereafter, nor shall a waiver of any breach or default of these Terms  constitute a waiver of any subsequent breach or default or a waiver of the  provision itself.  If any portion of  these Terms is found to be unenforceable, such portion will be modified to  reflect the parties&rsquo; intention and only to the extent necessary to make it  enforceable, and the remaining provisions of these Terms will remain in full  force and effect.  These Terms constitute  the entire and exclusive understanding and agreement between you and us  regarding this subject matter, and supersedes any and all prior or  contemporaneous agreements or understandings, written and oral.</p>
<p><strong>II.   SELLING ON INDY JOHN TERMS AND  CONDITIONS:</strong></p>
<p>Selling on Indy John Terms and Conditions are a part of the Indy John  Terms of Service and apply to all sellers using the Service in addition to the  General Terms and Conditions.<br>
</p>
<p><strong>Merchandise Listing -</strong><br>
</p>
<p>After you have set up your  account, we will enable you to list your Merchandise or Service on the Site to advertise  and promote through our Service.  We may  enable you to list your Merchandise on a sub-Site that lists solely your  Merchandise, or lists that specific item of Merchandise. As a seller, you will be  responsible for providing accurate and complete information and for promptly  updating that information, as necessary, to ensure it at all times remains  accurate and complete.  Your listing on  the Site constitutes an offer to buy your Merchandise, subject to the terms and  conditions contained herein or such other terms and conditions as you may agree  with a buyer.</p>
<p><strong>Order Processing and Collection of Sales Proceeds -</strong><br>
</p>
<p>We are not currently  managing payments with our service but for each item of your Merchandise sold  through our Service, we will make available to you the Quote Information (as  defined below) received by us.  You agree  that you have exclusive rights to collect all sales proceeds from the buyers including  the applicable shipping, handling and other charges determined by you.  <br>
</p>
<p><strong>Transaction and  Fulfillment -</strong><br>
</p>
<p>We are not currently allowing transaction and fulfillment with our  service but upon using our service you agree to: (a)&nbsp;source, offer,  sell and fulfill each order placed by a buyer for your Merchandise, in each  case in accordance with the terms of the applicable Order Information, these Terms,  and all terms provided by you and displayed on the Site at the time of the  order and be solely responsible for and bear all risk for those activities; (b)&nbsp;package  each item of your Merchandise in a commercially reasonable manner (c)&nbsp;include  an order-specific packing slip, and, if applicable, any tax invoices, within  each shipment of your Merchandise; (d)&nbsp;identify yourself as the seller of your  Merchandise on all packing slips or other information included or provided in  connection with your Merchandise and as the person to which a customer may  return the applicable product<strong></strong><br>
</p>
<p><strong>Cancellations, Returns  and Refunds -</strong><br>
</p>
<p>Indy John is marketplace that matches and connects buyers and suppliers  of merchandise and services.  We do not  manage payments or allow sales to post with our service.  We do not accept returned merchandise.  You agree to post your returns and refunds policy on the Site.  For your Merchandise, you will accept and  process all cancellations, returns, refunds and adjustments in accordance with your  refunds and returns policies displayed on the Site at the time of the order.  You will determine and calculate the amount of  all refunds and adjustments (including any taxes, shipping and handling or  other charges) or other amounts to be paid by you to buyers in connection with  cancelled orders.  You will route all  payments to buyers in connection with cancelled orders through Indy John.  <strong></strong><br>
</p>
<p><strong>Delivery Errors and  Recalls -</strong><br>
</p>
<p>You are solely responsible  for any non-performance, non-delivery, misdelivery, theft or other mistake or  act in connection with the fulfillment of each order for your Merchandise,  except to the extent caused by: our failure to make available to you Order  Information as it was received by us.  You  will notify us promptly as soon as you have knowledge of any public or private  recalls of your Merchandise.<br>
</p>
<p><strong>Parity with Your Other  Sales Channels -</strong><br>
</p>
<p>You are free to determine  which of your Merchandise you wish to offer through the Service.  You will maintain parity between the products  you offer through other sales channels you use and the products you list on the  Site by ensuring that : (a)&nbsp;the purchase price and every other term of  offer or sale of your Merchandise (including associated shipping and handling  charges, shipment information, any &ldquo;low price&rdquo; guarantee, rebate or discount,  any free or discounted products or other benefit available as a result of  purchasing one or more other products, and terms of applicable cancellation,  return and refund policies) is at least as favorable to the Site users as the  most favorable terms upon which a product is offered or sold via other sales  channels; (b)&nbsp;customer service for your Merchandise is at least as  responsive and available and offers at least the same level of support as the  most favorable customer services offered in connection with any of other sales  channels; and (c)&nbsp;your content, product and service information and other  information regarding your Merchandise that you provide on the Site is of at  least the same level of quality as the highest quality information displayed or  used in other sales channels.  If you  become aware of any non-compliance with (a) above, you will promptly compensate  adversely affected customers by making appropriate refunds to them in  accordance with these Terms.<br>
</p>
<p><strong>Seller Taxes -</strong><br>
</p>
<p>We are not currently handling payments so you agree that it is your responsibility  to determine whether Seller Taxes (as defined below) are accurate and apply to  the sales transactions involving your Merchandise and to notify us.  &ldquo;Seller Taxes&rdquo; means any and all sales, goods  and services, use, excise, import, export, value added, consumption and other  taxes and duties assessed, incurred or required to be collected or paid for any  reason in connection with any advertisement, offer or sale of products by you  on or through the Site, or otherwise in connection with any action, inaction or  omission of you or any of affiliate of yours, or any of your or their  respective employees, agents, contractors or representatives.<br>
</p>
<p><strong>Reviews and Endorsements  -</strong><br>
</p>
<p>We may use mechanisms that review and endorse, or allow users to review  and endorse, your Merchandise, Service and your performance as a seller.  We may make these ratings and feedback  publicly available.<br>
</p>
<p><strong>Control of Site -</strong><br>
</p>
<p>We have the right in our  sole discretion to determine the content, appearance, design, functionality and  all other aspects of the Site, including by redesigning, modifying, removing or  restricting access to any of them, and by suspending, prohibiting or removing  any listing.</p>
<p><strong>III.  BUYING ON INDY JOHN TERMS  AND CONDITIONS:</strong><br>
</p>
<p>Buying on Indy John Terms and Conditions are a part of the Indy John  Terms of Service and apply to all buyers using the Service in addition to the  General Terms and Conditions.<br>
</p>
<p><strong>Purchasing  Merchandise -</strong><br>
</p>
<p>Indy John assists buyers with purchasing merchandise by matching and  connecting with third party suppliers. Buyers submit Buy requests and are  matched with third party sellers. Indy John doesn&rsquo;t currently handle order  processing, leaving the order processing exclusively to third party sellers. Sellers&rsquo;  listing on the Site constitutes an offer to you to buy their Merchandise. Please  carefully read these Terms and any special terms and conditions including seller&rsquo;s  returns and refunds policy before placing an order.  We shall not be parties to any contract  between you and the seller and are not responsible for any act or omission by  either party that may be in violation of such a contract.  Without limiting the foregoing, we are not  responsible for timely performance by either party of its obligations or  failure of any representations or warranties made by either party under such a  contract or for any defects in Merchandise supplied by the sellers.  If an item of Merchandise is listed at an  incorrect price or with incorrect information due to a typographical error or  error in pricing or product information received from a seller. We have the  right to refuse or cancel any orders placed for such products or services,  whether or not you have placed the order or have been charged.</p>
<p><strong>Descriptions -</strong><br>
</p>
<p>We require the sellers to be as accurate as possible.  However, we do not warrant that Merchandise  descriptions or other content on the Site is accurate, complete, reliable,  current or error-free.  If an item of  Merchandise offered on the Site is not as described, your sole remedy is to  return it in unused condition. <br>
</p>
<p><strong>Changes to Buy Request -</strong><br>
</p>
<p>Once submitted, any  change(s) to your buy request(s) may be made only by you.  Changes requiring different terms, including  a change in the price and/or time of delivery will be solicited and made by you.   Once buy request is submitted, you may continue,  pause, or delete any request. We reserve the right to cancel any buy request,  in whole or in part, upon your breach of these Terms or your bankruptcy,  insolvency, dissolution, receivership proceedings, or upon the occurrence of  any event leading us to reasonably question your willingness or ability to perform.<br>
</p>
<p><strong>Delivery  Claims and Returns -</strong><br>
</p>
<p>We don&rsquo;t currently handle sale and fulfillment of orders.  We will not be responsible for any disputes  or errors arising during delivery or returning of merchandise.  All orders and details resulting from  buy requests through our service are handled and managed by you and the third  party supplier of merchandise and services. <br>
</p>
<p><strong>Delays  -</strong><br>
</p>
<p>We shall not be liable for  any loss, damage or penalty as a result of any delay in or failure to  manufacture, deliver or otherwise perform hereunder. &nbsp;If, for reasons  other than force majeure, seller should default or delay or not deliver the  ordered Merchandise.<br>
</p>
<p><strong>Use of Merchandise -</strong><br>
</p>
<p>The Merchandise offered  through the Service is intended primarily for industrial purposes and, unless  otherwise stated on product labels or in other literature furnished to you by  seller, is not to be used for any other purposes, including but not limited to,  in-vitro diagnostic purposes, in foods, drugs, medical devices or cosmetics for  humans or animals or for commercial purposes. &nbsp;You acknowledge that the Merchandise  has not been tested by Indy John for safety and efficacy in food, drug, medical  device, cosmetic, commercial or any other use. &nbsp;You expressly represent  and warrant to Indy John that you will properly test, use, manufacture and  market any Merchandise purchased through the Service and/or materials produced  with such Merchandise in accordance with the practices of a reasonable person  who is an expert in the field and in strict compliance with all applicable laws  and regulations, now and hereinafter enacted.<br>
</p>
<p><strong>Reviews and Endorsements -</strong><br>
</p>
<p>We may use mechanisms that  review and endorse, or allow users to review and endorse, your Merchandise,  Service and your performance as a buyer or general user.  We may make these ratings and feedback  publicly available.</p>
<p><strong>Patent Disclaimer -</strong><br>
</p>
<p>We do not warrant that the  use or sale of the Merchandise delivered hereunder will not infringe the claims  of any United States or other patents covering the product itself or the use  thereof in combination with other products or in the operation of any process.</p>
<p><strong>IV. Indy John Account Terms:</strong><br>
</p>
<p><strong>Indy John Account  Prices - </strong><br>
</p>
<p>Prices of Indy John accounts are subject to change at any  time. Prices of committed membership accounts are not subject to change during  the initial commitment period.<br>
</p>
<p><strong>Upgrading or  Downgrading an Account -</strong><br>
</p>
<p>You may upgrade your  Indy John account on the Indy John Service. You may also, subject to any  minimum term commitment that may apply, downgrade your Indy John account online  or by contacting Indy John customer service. Such Indy John account changes  will be effective as of the date of your request and your membership will  become subject to the new account you selected. Indy John accounts may be  upgraded or downgraded as follows:<br>
</p>
<p><strong>Buyer+ Account - </strong><br>
</p>
<p>Free Members can upgrade to Buyer+ Membership account. Upon  any upgrade, Indy John will charge your default payment the fee for the Buyer+  Plan. If your default payment is declined for any reason, Indy John may charge  any credit card on file with your profile. Buyer+ Members cannot upgrade to  another Indy John Buyer Plan.<br>
</p>
<p><strong>Gold and Silver  Membership Accounts -</strong><br>
</p>
<p>Silver Members can upgrade to Gold Membership account. Any  available Credits, that a Silver Member has accumulated will be transferred to  the new upgraded plan in accordance with the rules for the new membership plan.  Upon any upgrade, Indy John will charge your default payment the pro-rated  additional fee for the Gold Membership Plan. If your default payment is  declined for any reason, Indy John may charge any credit card on file with your  profile. Gold Members cannot upgrade to another Indy John Plan.<br>
</p>
<p><strong>Downgrades -</strong><br>
</p>
<p>Buyer+, Gold, and Silver Account users can downgrade to a  free account and any available Credits will be paid to user. Any complimentary  subscription that you receive as part your Buyer+, Gold, or Silver Membership  accounts will expire upon any downgrade to the free account.<br>
</p>
<p><strong>Cancellation of Indy  John Accounts -</strong><br>
</p>
<p>You may cancel your Indy John account online, by contacting  Indy John customer service, or by simply not using the Indy John service. Upon  cancellation of any membership, all available credits will expire, and all  complimentary Subscriptions will expire. Members will not receive a full or  partial refund of any monthly or annual fee already paid.</p>
<p><strong>V.   INDY JOHN REFERRAL PROGRAM:</strong><br>
</p>
<p><strong>General -</strong><br>
</p>
<p>These terms and conditions  apply to Indy John&rsquo;s Referral Program (&ldquo;Program&rdquo;). By referring a friend,  purchasing valued accounts, or otherwise participating in the Program, the  referring customer and referred friend agree to be bound by these terms and  conditions, Indy John&rsquo;s General Terms and Conditions, and the Indy John&rsquo;s  Privacy Policy.  You agree to a mandatory  arbitration provision that provides that (except for matters properly brought  to small claims court) any claim, controversy, or dispute of any kind between  you and Indy John must be resolved by final and binding arbitration on an  individual and not a class-wide or consolidated basis.<br>
</p>
<p><strong>Program  Participation and Eligibility -</strong><br>
</p>
<p>The Program is available  only to Indy John users signed up to use Indy John services. Referral payout  will be paid to any user that refers another user signed up for a valued  account. Please allow up to four (4) weeks after referral validation for  referral reward to be applied. Indy John reserves the right to modify, extend  or cancel this Program at any time. The Program is only available online  through the Indy John website. Internet access is required for participation in  the Program. Current Indy John customers, who initiate a referral, are defined  as &ldquo;Referrers.&rdquo; Non-customers who sign up for Indy John service upon a referral  are defined as &ldquo;Referees.&rdquo;<br>
</p>
<p><strong>Eligible Referrals - </strong><br>
</p>
<p>The Program is only  available for active Indy John users in good standing. To make referrals, you  must have signed up for Indy John services and be an individual person of the  age of majority in the state/province or jurisdiction where you are resident at  the time of participation.<br>
</p>
<p>Participation in the Program  is prohibited where void by applicable law or regulation. The Program is only  available through IndyJohn.com. If your account is &ldquo;interrupted&rdquo;, &ldquo;suspended&rdquo;  or you cancel your account with Indy John, you are no longer eligible to  participate in the Program. Upon cancellation with Indy John, your account will  be inactive and you may not make referrals or earn Program payouts, including  any referral credits that may be pending. You cannot redeem a referral credit  for referring yourself. You may only participate in the program online at IndyJohn.com,  not at any retail outlet. You may only participate in the Program with one  account. People you invite (&ldquo;Referees&rdquo;) have to activate a new valued monthly  account for you to receive a referral payout. To participate and earn a payout,  Referees must register on the Indy John website, sign up for a valued account  and generate a service activation date.<br>
</p>
<p><strong>Ineligible Referrals - </strong><br>
</p>
<p>Unless otherwise noted, this  program applies only to Buyer+ and Silver and Gold accounts.  The Program may not be available for other Indy  John accounts or services, and other plans deemed ineligible (collectively,  &ldquo;Ineligible Referrals&rdquo;). In addition, Referrals made through non-authorized Indy  John referral channels are not eligible for the program. Indy John reserves the  right to void any Referral credit based on the following: (1) ineligibility of  any Program participant, (2) fraudulent activation or, (3) if Indy John, in its  sole discretion, finds that you have violated any of the Program Terms and  Conditions.<br>
</p>
<p><strong>Eligible Referees -</strong><br>
</p>
<p>Each Referee must activate a  new Indy John valued monthly account for referral payout to take place.  You cannot receive credits for referring  yourself or by renewing your monthly plan with Indy John. There is no maximum  on how much Indy John users can earn in a calendar year. If you are a new Indy  John customer who was referred by an existing Indy John customer, you are  eligible to earn referral rewards, including your initial referral reward. You  must disclose the fact that you are an Indy John customer when you make  referrals. You agree to let your Referees know that you are the Referrer and  that you may receive a referral reward if your Referee signs up for Indy John  service. You will not receive any referral reward if your referrals are  rejected or are not received for any reason, or if you fail to comply with any  of the terms of the Program.<br>
</p>
<p><strong>Reward Redemption -</strong><br>
</p>
<p>Referral rewards are  non-transferable, non-assignable, and cannot be redeemed or exchanged for cash,  credit, or other merchandise.<br>
</p>
<p><strong>Reward Issuance Expiration -</strong><br>
</p>
<p>If further action is  required for reward issuance, members successfully complete the additional  action within 30 days from initial notification of the request for further action;  otherwise the member will forfeit the pending reward.<br>
</p>
<p><strong>Referral Program Tax and  Liability -</strong><br>
</p>
<p>You are responsible for any  and all tax liabilities associated with the Program.<br>
</p>
<p><strong>Void Where Prohibited -</strong><br>
</p>
<p>This Program is void where  prohibited by law.<br>
</p>
<p><strong>Changes to the Program -</strong><br>
</p>
<p>We reserve the right to  change the terms and conditions of the Indy John Referral Program at any time,  without notice, at our sole discretion. We reserve the right to not award a  credit or disqualify someone from the Program if we feel, in our sole  discretion, that fraudulent behavior or other unethical conduct has occurred in  any way that compromises the fairness the Program in any way. Credits cannot be  combined with other promotions and are not valid for previous offers or orders.  Spam, unsolicited commercial email, or any form of illegal means of  communication is illegal, prohibited, and will be grounds for termination of  your account and participation in this Program. Fraudulent or unethical means  of communication such as using bots, fictitious identities, fake emails, or  scripts is also prohibited and will result in similar actions by us with  respect to terminating your account and participation in the Program. <br>
  By participating in this  Program, you agree to release and hold us harmless from any and all claims or  damages arising out of, or in connection with the Program. You further agree  that the Program and credits are provided &quot;as is where is&quot;. THERE ARE  NO REPRESENTATIONS OR WARRANTIES INCLUDING BUT NOT LIMITED TO STATUTORY  WARRANTIES AND CONDITIONS, WARRANTIES AND CONDITIONS OF MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE, THIRD PARTIES RIGHTS, AND NON-INFRINGEMENT OF  PROPRIETARY RIGHTS. IN NO EVENT WILL EITHER PARTY BE LIABLE TO THE OTHER FOR  ANY CONSEQUENTIAL, INCIDENTAL, OR SPECIAL DAMAGES, INCLUDING ANY LOST PROFITS  OR LOST SAVINGS, EVEN IF ONE PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH  DAMAGES, OR FOR ANY CLAIM BY ANY THIRD PARTY. </p>






                </div>

            </div>

        </section>

<!--=======================================================-->

@include('home.footerlinks')
@endsection
