@extends('home.app')
@section('content')
@include('home.header')
<!-- maybe later - 
	  
      <div class="section fade">
          <div class="container  text-center">
              <h3 class="header_middle">Make Indy John the QuarterBack of your Sales Team!</h3>
              
              <div class="col-md-4 iconsection">
                  <i class="icon"><img src="{{URL::asset('public/livesite/images/multiple.png')}}"/></i>
                  <h3 class="header_18">Quote-Lead System</h3>
                  <p>Create product lead request and we’ll bring the leads to you.</p>
              </div>
              
            <div class="col-md-4 iconsection">
                  <i class="icon"><img src="{{URL::asset('public/livesite/images/cost.png')}}"/></i>
                  <h3 class="header_18">Indy John Market</h3>
                  <p>List or shop for new and used industrial products and supplies.</p>
              </div>
              
              
              <div class="col-md-4 iconsection">  
                  <i class="icon"><img src="{{URL::asset('public/livesite/images/safty.png')}}"/></i>
                  <h3 class="header_18">Supplier CRM</h3>
                  <p>Organize your leads and manage all sales activity.</p>
              </div>
              
          </div>
      </div>
      
      -->

<div class=" padding100">
  <div class="helpsection fade margintop20">
    <div class="col-md-6 wow slideInLeft"> <img src="{{URL::asset('public/livesite/images/banners/supplier-quote-lead.jpg')}}" class="img_full" alt="" /> </div>
    <div class="col-md-6 wow slideInRight border_bottom">
      <div class="section  ">
        <h3 class="header_36">Quote-Lead System</h3>
        <p class="font28"> Let us bring the leads to you.</p>
        <p>We know requesting network invitations and cold calling doesn't always result in a sale.  Our system can help you meet new buyers and procurement departments, we'll match you with new buyer requests; you then contact the buyer directly and begin your pitch.
        <h3 class="header_24_red">Let's make Indy John the quarterback of your sales team.</h3>
        <p><a href="{{url('supplier-home')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
  <div class="helpsection fade margintop20">
    <div class="col-md-6 wow slideInLeft hidden-sm hidden-xs">
      <div class="section ">
        <h3 class="header_36">Indy John Market</h3>
        <p class="font28"> Save time and reach new buyers.</p>
        <p>We realize your customer reach is probably limited to existing customers and an outdated emailing list. In addition to our quote-lead system, we're opening a brand new industrial only market designed to help you meet new buyers and advertise your offering.
        <h3 class="header_24_red">Increase your selling opportunities, expand your reach.</h3>
        <p><a href="{{url('supplier-home')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="col-md-6 wow slideInRight "> <img src="{{URL::asset('public/livesite/images/banners/supplier-market.jpg')}}" class="img_full" alt="" /> </div>
    <div class="col-md-6 wow slideInLeft visible-sm visible-xs border_bottom">
      <div class="section ">
        <h3 class="header_36">Indy John Market</h3>
        <p class="font28"> Save time and reach new buyers.</p>
        <p>We realize your customer reach is probably limited to existing customers and an outdated emailing list. In addition to our quote-lead system, we're opening a brand new industrial only market designed to help you meet new buyers and advertise your offering.
        <h3 class="header_24_red">Increase your selling opportunities, expand your reach.</h3>
        <p><a href="{{url('supplier-home')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
  <div class="helpsection fade margintop20">
    <div class="col-md-6 wow slideInLeft "> <img src="{{URL::asset('public/livesite/images/banners/supplier-crm.jpg')}}" class="img_full" alt="" /> </div>
    <div class="col-md-6 wow slideInRight border_bottom">
      <div class="section ">
        <h3 class="header_36">Supplier CRM</h3>
        <p class="font28"> The smart way to manage and organize.</p>
        <p>Stop depending on expensive CRM's and let us bring some clarity to your sales process.  We expect Indy John's features and tools to increase your sales and outreach, so we designed a CRM to assist you in organizing and managing this new data.
        <h3 class="header_24_red">Organize better, network smarter, one CRM.</h3>
        <p><a href="{{url('supplier-home')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
  <div class="helpsection fade margintop20">
    <div class="col-md-6 wow slideInLeft hidden-sm hidden-xs">
      <div class="section ">
        <h3 class="header_36">Industrial Service Locator</h3>
        <p class="font28"> Searching for industrial services just got easier.</p>
        <p>Finding specific or niche industrial services can be frustrating.  Indy John want's to help, like other companies we'll match you with several professionals based on your service needs but we'll also give you a few social tools designed to make the experience more productive.
        <h3 class="header_24_red">Start finding the right professional, save a little time.</h3>
        <p><a href="{{url('supplier-home')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="col-md-6 wow slideInRight "> <img src="{{URL::asset('public/livesite/images/banners/supplier-service.jpg')}}" class="img_full" alt="" /> </div>
    <div class="col-md-6 wow slideInLeft visible-sm visible-xs">
      <div class="section ">
        <h3 class="header_36">Industrial Service Locator</h3>
        <p class="font28"> Searching for industrial services just got easier.</p>
        <p>Finding specific or niche industrial services can be frustrating.  Indy John want's to help, like other companies we'll match you with several professionals based on your service needs but we'll also give you a few social tools designed to make the experience more productive.
        <h3 class="header_24_red">Start finding the right professional, save a little time.</h3>
        <p><a href="{{url('supplier-home')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
<div class="clearfix"></div>
<div class="color_bg margintop80 feedback">
  <div class="container">
    <div class="col-md-10"> <i class="pull-left testimonial_ico"><img src="{{URL::asset('public/livesite/images/testimonial.png')}}" alt=""/></i>
      <div class="col-md-9">
        <h3 class="header_24">Start Today for Free</h3>
        <p>Sign up for a Free Account.</p>
      </div>
    </div>
    <div class="col-md-2"><a href="{{url('supplier-home')}}" class="btn btn-circle btn_wh">Sign up</a></div>
  </div>
</div>
@include('home.footerlinks')
@endsection
