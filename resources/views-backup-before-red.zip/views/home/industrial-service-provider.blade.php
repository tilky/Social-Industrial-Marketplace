@extends('home.app')
@section('content')
@include('home.header')

<!-- maybe later - 
	  
<div class="section fade">
  <div class="container  text-center">
      <h3 class="header_middle">Make Indy John the QuarterBack of your Sales Team!</h3>
      
      <div class="col-md-4 iconsection">
          <i class="icon"><img src="{{URL::asset('public/livesite/images/multiple.png')}}"/></i>
          <h3 class="header_18">Multiple Options</h3>
          <p>Never overpay again. Complete One order form and have access to all our Suppliers.</p>
      </div>
      
    <div class="col-md-4 iconsection">
          <i class="icon"><img src="{{URL::asset('public/livesite/images/cost.png')}}"/></i>
          <h3 class="header_18">Multiple Options</h3>
          <p>Never overpay again. Complete One order form and have access to all our Suppliers.</p>
      </div>
      
      
      <div class="col-md-4 iconsection">  
          <i class="icon"><img src="{{URL::asset('public/livesite/images/safty.png')}}"/></i>
          <h3 class="header_18">Multiple Options</h3>
          <p>Never overpay again. Complete One order form and have access to all our Suppliers.</p>
      </div>
      
  </div>
</div>

-->

<div class=" padding100">


    <div class="helpsection fade margintop20">
        <div class="col-md-6 wow slideInLeft nopadding">
            <img src="{{URL::asset('public/livesite/images/banners/service-provider-search-discovery.jpg')}}" class="img_full" alt="" />

        </div>

        <div class="col-md-6 wow slideInRight border_bottom">
            <div class="section  ">
                <h3 class="header_36">Search Discovery</h3>
                  <p class="font28"> Start connecting with new customers.
                    <p>Competing for business is a hard task, being found in search engines can also be difficult.  We want to help, tell us about your service offering and we'll introduce you to the industrial world. Simply create a free company profile and start meeting potential customers. 


                        <h3 class="header_24_red">Being discovered just got easy.</h3>

                        <p><a href="{{url('')}}" class="btn btn-circle btn_new">Sign up Now</a></p>

            </div>
        </div>
        <div class="clearfix"></div>

    </div>


<div class="helpsection fade margintop20">



        <div class="col-md-6 wow slideInLeft hidden-sm hidden-xs">
            <div class="section ">
                <h3 class="header_36">Advertise Your Service </h3>
                <p class="font28"> We can help you promote and advertise.

                    <p>Many listing and social networking websites will charge huge sums to advertise and promote your service.  Not us - create your free company profile and begin promoting your business across a new industrial marketplace. 


                        <h3 class="header_24_red">Your customer list is about to grow!</h3>

                        <p><a href="{{url('')}}" class="btn btn-circle btn_new">Sign up Now</a></p>

            </div>
        </div>


        <div class="col-md-6 wow slideInRight nopadding">
            <img src="{{URL::asset('public/livesite/images/banners/service-provider-advertise.jpg')}}" class="img_full" alt="" style="display:block !important;"/>
        </div>
        
        <div class="col-md-6 wow slideInLeft border_bottom visible-sm visible-xs">
            <div class="section ">
                <h3 class="header_36">Advertise Your Service </h3>
                <p class="font28"> We can help you promote and advertise.

                    <p>Many listing and social networking websites will charge huge sums to advertise and promote your service.  Not us - create your free company profile and begin promoting your business across a new industrial marketplace. 


                        <h3 class="header_24_red">Your customer list is about to grow!</h3>

                        <p><a href="{{url('')}}" class="btn btn-circle btn_new">Sign up Now</a></p>

            </div>
        </div>
        <div class="clearfix"></div>
    </div>
    



    <div class="helpsection fade margintop20">
        <div class="col-md-6 wow slideInLeft nopadding">
            <img src="{{URL::asset('public/livesite/images/banners/service-provider-buy.jpg')}}" class="img_full" alt="" />

        </div>

        <div class="col-md-6 wow slideInRight border_bottom">
            <div class="section ">
                <h3 class="header_36">Buy Industrial Products</h3>
                 <p class="font28">  Purchase your products on Indy John.
                    <p>Our technology is changing the way people buy industrial products and services.  Try our Quote-Lead system or Indy John market next time you're shopping for products and supplies, and take advantage of our Buyer Dashboard to organize your new purchases.
                        <h3 class="header_24_red">We're dedicated to your success.</h3>

                        <p><a href="index.html" class="btn btn-circle btn_new">Sign up Now</a></p>

            </div>
        </div>
        <div class="clearfix"></div>
    </div>



<div class="helpsection fade margintop20">



        <div class="col-md-6 wow slideInLeft hidden-sm hidden-xs">
            <div class="section ">
                <h3 class="header_36">Start selling on Indy John.</h3>
                 <p class="font28">  We can help you promote and advertise.

                    <p>We know some service providers also supply products and consumables.  Begin meeting new buyers with our Quote-Lead system, or showcase your offering on the Indy John market. We'll make it easy to manage, promote, and grow your business by providing you a supplier CRM.


                        <h3 class="header_24_red">Grow your brand, increase your sales.</h3>

                        <p><a href="{{url('')}}" class="btn btn-circle btn_new">Sign up Now</a></p>

            </div>
        </div>


        <div class="col-md-6 wow slideInRight nopadding">
            <img src="{{URL::asset('public/livesite/images/banners/service-provider-start-selling.jpg')}}" class="img_full" alt="" />
        </div>
        
        <div class="col-md-6 wow slideInLeft visible-sm visible-xs">
            <div class="section ">
                <h3 class="header_36">Start selling on Indy John.</h3>
                 <p class="font28">  We can help you promote and advertise.

                    <p>We know some service providers also supply products and consumables.  Begin meeting new buyers with our Quote-Lead system, or showcase your offering on the Indy John market. We'll make it easy to manage, promote, and grow your business by providing you a supplier CRM.


                        <h3 class="header_24_red">Grow your brand, increase your sales.</h3>

                        <p><a href="{{url('')}}" class="btn btn-circle btn_new">Sign up Now</a></p>

            </div>
        </div>
        <div class="clearfix"></div>
    </div>



</div>



<div class="color_bg margintop20 feedback">
    <div class="container">
        <div class="col-md-10">
        
            <div class="col-md-9">
                <h3 class="header_24">Start Today for Free</h3>
                <p>Sign up for a Free Account.</p>
            </div>
        </div>

        <div class="col-md-2"><a href="{{url('')}}" class="btn btn-circle btn_wh">Sign up</a></div>

    </div>

</div>

@include('home.footerlinks')
@endsection
