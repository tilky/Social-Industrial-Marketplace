@extends('home.app')
@section('content')
@include('home.header')
<!-- maybe later - 
	  
      <div class="section fade">
          <div class="container  text-center">
              <h3 class="header_middle">Make Indy John the QuarterBack of your Sales Team!</h3>
              
              <div class="col-md-4 iconsection">
                  <i class="icon"><img src="{{URL::asset('public/livesite/images/multiple.png')}}"/></i>
                  <h3 class="header_18">Multiple Options</h3>
                  <p>Never overpay again. Complete One order form and have access to all our Suppliers.</p>
              </div>
              
            <div class="col-md-4 iconsection">
                  <i class="icon"><img src="{{URL::asset('public/livesite/images/cost.png')}}"/></i>
                  <h3 class="header_18">Multiple Options</h3>
                  <p>Never overpay again. Complete One order form and have access to all our Suppliers.</p>
              </div>
              
              
              <div class="col-md-4 iconsection">  
                  <i class="icon"><img src="{{URL::asset('public/livesite/images/safty.png')}}"/></i>
                  <h3 class="header_18">Multiple Options</h3>
                  <p>Never overpay again. Complete One order form and have access to all our Suppliers.</p>
              </div>
              
          </div>
      </div>
      
      -->

<div class=" padding100">
  <div class="helpsection fade margintop20">
    <div class="col-md-6 wow slideInLeft "> <img src="{{URL::asset('public/livesite/images/banners/buyer-quote-lead.jpg')}}" class="img_full" alt="" /> </div>
    <div class="col-md-6 wow slideInRight border_bottom">
      <div class="section  ">
        <h3 class="header_36">Quote-Lead System</h3>
        <p class="font28"> Let us help you find the best quote.</p>
        <p>We understand shopping for industrial products and services can be time consuming for any Buyer or Procurement Department. Submit one buy request and allow our system to match and connect you with suppliers.
        <h3 class="header_24_red">Find new suppliers, save time, and never overpay.</h3>
        <p><a href="{{url('/')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
  <div class="helpsection fade margintop20">
    <div class="col-md-6 wow slideInLeft hidden-sm hidden-xs">
      <div class="section ">
        <h3 class="header_36">Indy John Market</h3>
        <p class="font28"> Shopping for industrial items will never be the same.</p>
        <p>Other companies have expanded their offering into a wide range of products, making shopping for quality or specific industrial products more difficult. We want to help; we're unveiling a brand new market concentrated on industrial products and supplies.
        <h3 class="header_24_red">Sign up now to begin exploring.</h3>
        <p><a href="{{url('/')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="col-md-6 wow slideInRight "> <img src="{{URL::asset('public/livesite/images/banners/buyer-market.jpg')}}" class="img_full" alt="" /> 

</div>
    <div class="col-md-6 wow slideInLeft visible-sm visible-xs border_bottom">
      <div class="section ">
        <h3 class="header_36">Indy John Market</h3>
        <p class="font28"> Shopping for industrial items will never be the same.</p>
        <p>Other companies have expanded their offering into a wide range of products, which makes shopping for quality or specific industrial products more difficult. We want to help; we're unveiling a brand new market concentrated on industrial products and supplies.
        <h3 class="header_24_red">Sign up now to begin exploring.</h3>
        <p><a href="{{url('/')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
  <div class="helpsection fade margintop20">
    <div class="col-md-6 wow slideInLeft "> <img src="{{URL::asset('public/livesite/images/banners/buyer-dashboard.jpg')}}" class="img_full" alt="" /> </div>
    <div class="col-md-6 wow slideInRight border_bottom">
      <div class="section ">
        <h3 class="header_36">Buyer Dashboard</h3>
        <p class="font28"> We can help you purchase more efficiently.</p>
        <p>Upon signing up, all Indy John users will receive a Buyer dashboard designed to help you organize your purchases and increase your productivity. All supplier information, quotes, purchases, and activity inside one dashboard? <b>Yes, it's possible.</b>
        <h3 class="header_24_red">Purchasing should always be this simple.</h3>
        <p><a href="{{url('/')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
  <div class="helpsection fade margintop20">
    <div class="col-md-6 wow slideInLeft hidden-sm hidden-xs">
      <div class="section ">
        <h3 class="header_36">Industrial Service Locator</h3>
        <p class="font28">A better way to find industrial services.</p>
        <p>Looking for specific or niche industrial services is a challenging task. Let us help, we'll match you with several professionals based on your service needs. We know connecting is not enough, so we'll throw in a few tools designed to make the experience more productive and social.
        <h3 class="header_24_red">Take a look and begin discovering.</h3>
        <p><a href="{{url('/')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="col-md-6 wow slideInRight "> <img src="{{URL::asset('public/livesite/images/banners/buyer-service-locator.jpg')}}" class="img_full" alt="" /> </div>
    <div class="col-md-6 wow slideInLeft visible-sm visible-xs">
      <div class="section ">
        <h3 class="header_36">Industrial Service Locator</h3>
        <p class="font28">A better way to find industrial services.</p>
        <p>Looking for specific or niche industrial services is a challenging task. Let us help, we'll match you with several professionals based on your service needs. We know connecting is not enough, so we'll throw in a few tools designed to make the experience more productive and social.
        <h3 class="header_24_red">Take a look and begin discovering.</h3>
        <p><a href="{{url('/')}}" class="btn btn-circle btn_new">Sign up Now</a></p>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
<div class="clearfix"></div>
<div class="color_bg margintop80 feedback">
  <div class="container">
    <div class="col-md-10"> <i class="pull-left testimonial_ico"><img src="{{URL::asset('public/livesite/images/testimonial.png')}}" alt=""/></i>
      <div class="col-md-9">
        <h3 class="header_24">Start Today for Free</h3>
        <p>Sign up for a Free Account.</p>
      </div>
    </div>
    <div class="col-md-2"><a href="{{url('/')}}" class="btn btn-circle btn_wh">Sign up</a></div>
  </div>
</div>
@include('home.footerlinks')
@endsection
