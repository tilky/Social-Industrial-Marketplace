<script src="{{URL::asset('public/metronic/plugins/jquery.min.js')}}" type="text/javascript"></script>
<link href="{{URL::asset('public/metronic/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/select2/css/select2-bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
<!-- BEGIN THEME GLOBAL SCRIPTS -->
    <script src="{{URL::asset('public/metronic/scripts/app.min.js')}}" type="text/javascript"></script>
    <!-- END THEME GLOBAL SCRIPTS -->
    
   <script src="{{URL::asset('public/metronic/plugins/bootstrap-select/js/bootstrap-select.min.js')}}" type="text/javascript"></script>
    <script src="{{URL::asset('public/metronic/plugins/jquery-multi-select/js/jquery.multi-select.js')}}" type="text/javascript"></script>
    <script src="{{URL::asset('public/metronic/plugins/select2/js/select2.full.min.js')}}" type="text/javascript"></script>
    <style>
.select2-results{color: #383333!important;}
.select2-dropdown {}
.select2-container{display: block!important;}
.select2-container .select2-selection--single{width:100%!important;height: 40px!important;line-height: 40px!important;color: #383333!important;text-align: left!important;border-radius: 22px;}
.select2-search__field{color: #383333!important;}
.select2-container--default .select2-selection--single .select2-selection__rendered{color: #383333!important;font-size: 13px!important;}
.select2-selection__rendered{height: 35px!important;line-height: 35px!important;}
.select2-selection__arrow{top: 5px!important;}
.select2-container--default .select2-selection--single .select2-selection__arrow{right: 30px!important;}
.modal-backdrop.fade.in {
opacity: 0.5!important;
filter: alpha(opacity=50);
}
</style>
<div class="homepage">
        
        <nav class="navbar custom_nav " id="nav">
            <div class="container-fluid">


                <div class="navbar-header">
                    <div class="logo">
                        <a href="{{url('/')}}"><img src="{{URL::asset('public/livesite/images/indy-john/Logo.png')}}" alt="" /></a>
                    </div>
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div id="navbar" class="navbar-collapse collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="{{url('buyer-features')}}">Buyer Features</a></li>
                        <li><a href="{{url('supplier-network')}}">Supplier Network</a> </li>
                        <li><a href="{{url('referral-program')}}">Referral Program</a></li>
                        <li><a href="{{url('faq')}}">FAQ's</a></li>
                        <li class="dropdown">
                            <a href="about-us.php" class="dropdown-toggle" data-toggle="dropdown" role="button">About Us <i class="glyphicon glyphicon-menu-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="{{url('about-us')}}">About Us</a></li>
                                <li><a href="{{url('faq')}}">FAQs </a></li>
                                <li><a href="{{url('news')}}">Indy John News</a></li>
                                <li><a href="{{url('investor-outreach')}}">Investor Outreach </a></li>
                                <li><a href="{{url('contact-us')}}"> Contact Us</a></li>
                            </ul>
                        </li>
                        @if(Auth::check())
                            @if(Auth::user()->access_level == 1)
                                <li><a href="{{url('sa')}}" ><i class="lock"> </i></a></li>
                            @else
                                <li><a href="{{url('user-dashboard')}}"><i class="lock"> </i></a></li>
                            @endif
                        @else
                            <li><a href="#login" data-toggle="modal" data-target="#login"><i class="lock"> </i></a></li>
                        @endif
                        <li class="hidden-xs"><a href="#searchModal" data-toggle="modal" data-target="#searchModal"><i class="search"> </i></a></li>
                        @if(Auth::check())
                            @if(Auth::user()->access_level == 1)
                                <li class="signup-btn"><a class="btn" href="{{url('sa')}}" >Sign Up</a></li>
                            @else
                                <li class="signup-btn"><a class="btn" href="{{url('user-dashboard')}}">Sign Up</a></li>
                            @endif
                        @else
                            <li class="signup-btn"><a href="{{url('/')}}#signup" class="btn">Sign Up</a></li>
                        @endif
                   
                    </ul>
                    <div class="close_menu"><button type="btn btn-default btn-warning" style="float:none;" class="btn navbar-toggle" data-toggle="collapse" data-target="#navbar" aria-expanded="true">
                        Close
                    </button></div>
                    
                </div>
                <!--/.nav-collapse -->
            </div>
        </nav>
        <!--===================  Models ===================-->
        <!--Search Modal -->
        <div class="modal fade searchModal" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="fa fa-close"></i></span></button>

                    </div>
                    <div class="modal-body vericle_table">
                        <div class="verticle_mddle">
                            <div class="">
                                <div class="searcform">
                                    <input type="search" placeholder="Search Products, People, Companies, Service providers and more">
                                    <button type="submit" class="searchweb"><i class="fa fa-search"></i></button>
                                </div>


                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- login-model --->
        <div class="modal fade login-model" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">

            <div class="modal-dialog" role="document">
                <div class="modal-content container login-content">

                    <div class="modal-body vericle_table">
                        <div class="verticle_mddle">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="fa fa-close"></i></span></button>
                            <h3 class=" text-left animated bounceInDown slower go nopadding font28">Please Login</h3>

                            <div class="col-md-6  animated fadeIn loginform go">
                                <h3 class="font18 animated go header_18 text-bold">Login to Indy John</h3>

                                <form action="{{url('auth/login')}}" method="post">
                                    <input type="hidden" name="_token" value="{{csrf_token()}}">
                                    <input type="email" name="email" placeholder="Enter Your E-mail Id">
                                    <input type="password" name="password" placeholder="Enter Your Password">
                                    <p class=""><a href="{{url('password/email')}}">Forgot Password? </a></p>

                                    <div class="paddingtop20 row">
                                        <div class="col-md-12">
                                            <button type="submit" class="btn_red  hvr-bounce-to-right"> Login </button>
                                        </div>

                                    </div>

                                </form>

                            </div>

                            <div class="col-md-6 logininfo">
                                <h3 class="font18 animated go header_18 text-bold">Welcome to Indy John.</h3>
                                <p>You can use an Indy John account to:</p>
                                <ul>
                                    <li>
                                        <p><i class="fa fa-check-circle" aria-hidden="true"></i> Get Product and Service Quotes </p>
                                    </li>
                                    <li>
                                        <p><i class="fa fa-check-circle" aria-hidden="true"></i> Sell your Products and Services. </p>
                                    </li>
                                    <li>
                                        <p><i class="fa fa-check-circle" aria-hidden="true"></i> Explore Market Listings. </p>
                                    </li>
                                    <li>
                                        <p><i class="fa fa-check-circle" aria-hidden="true"></i> Be Discovered. </p>
                                    </li>
                                    <li>
                                        <p><i class="fa fa-check-circle" aria-hidden="true"></i> Post and Search Jobs. </p>
                                    </li>
                                </ul>
                                <div class="paddingtop20 row">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn_red  hvr-bounce-to-right"> SIGN UP FOR A FREE ACCOUNT </button>
                                    </div>

                                </div>
                            </div>
                             <div class="clearfix"></div>
        <h6 class="text-center margin-top-30">By Logging in, you Agree to our <a href="terms" target="_blank">Terms & Conditions</a> & <a href="privacy-policy" target="_blank">Privacy Policy</a>.</h6>

                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- signup-model --->
        <div class="modal fade signup-model" id="signup" aria-hidden="true" role="dialog" aria-labelledby="myModalLabel">
        
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class=" text-uppercase text-center">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="fa fa-close"></i></span></button>
                        <h3>tell us about yourself</h3>
                        <!--                        <h5>so that we can prepare your account</h5>-->
                        <form role="form" method="POST" action="{{url('auth/register')}}" enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="{{csrf_token()}}">
                            <input type="hidden" name="email" value="" id="register-email" />
                            <input type="hidden" name="user_type" value="" id="register-user-type" />
                            <div class="form-inline ">
                                <h4>TELL US YOUR SNAME</h4>
                                <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                <div class="row">
                                    <input type="text" class="form-control" name="firstname" id="first-name" value="{{Request::old('firstname')}}" placeholder="FIRST NAME" required="">
                                    </div>
                                </div>
                                <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                <div class="row">
                                    <input type="text" class="form-control" id="last-name" name="lastname" value="{{Request::old('lastname')}}" placeholder="LAST NAME" required="">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="form-inline ">
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                <div class="row">
                                    <h4>YOUR MAIN INDUSTRY</h4>
                                    </div>
                                    <select name="main_industry" class="form-control selectIndustry" id="indutries-dropdown">
                                        <option value="">Please Select Industry</option>
                                        @foreach($industries as $industry)
                                            @if(Request::old('main_industry') == $industry->id)
                                                <option value="{{$industry->id}}" selected="">{{$industry->name}}</option>
                                            @else
                                                <option value="{{$industry->id}}">{{$industry->name}}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                    
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="form-inline ">
                                <h4>SET YOUR ACCOUNT PASSWORD</h4>
                                <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                <div class="row">
                                    <input type="password" class="form-control" id="password" name="password" placeholder="ENTER PASSWORD" required=""></div>
                                </div>
                                <div class="form-group col-md-6 col-sm-12 col-xs-12">
                                <div class="row">
                                    <input type="password" class="form-control" id="repeat-password" name="password_confirmation" placeholder="REPEAT PASSWORD" required=""></div>
                                </div>
                                <div class="clearfix"></div>
                                <h4>Enter a Referral Code. (Optional)</h4>
                                <div align="center" class="form-group col-md-12 col-sm-12 col-xs-12">
                                   
                                    @if(isset($_GET['referral']))
                                    <input type="text" class="form-control referral_code" name="referral_code" value="{{$_GET['referral']}}" placeholder="ENTER REFERRAL CODE" />
                                    @else
                                    <input type="text" class="form-control referral_code" name="referral_code"  placeholder="ENTER REFERRAL CODE" />
                                    @endif
                                
                                </div>
                                <div class="clearfix"></div>
                                <h4 style="padding:0px !important">&nbsp;</h4>
                                <div align="center" class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <button class="btn_red  hvr-bounce-to-right" type="submit" >Sign Up</button>
                                    <h6>By Signing Up, You Agree To Our <a href="terms" target="_blank">Terms & Conditions</a> & <a href="privacy-policy" target="_blank">Privacy Policy</a>.</h6>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </form>
                    </div>
                
                </div>
            </div>
        
        
        </div>

        <!-- =================== End  Models =================== -->

    </div>
    <div class="clearfix"></div>
<script>
var placeholder = "Select an Industry";
$(".selectIndustry").select2({
    placeholder: placeholder,
    width: null
});
</script>
<script src="{{URL::asset('public/metronic/plugins/select2/js/select2.full.min.js')}}" type="text/javascript"></script>
