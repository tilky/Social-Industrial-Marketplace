@extends('home.app')
@section('content')
@include('home.header')
<!--======================= layout ========================-->

<div class="small-layout animatedParent" style="background-image: url('{{URL::asset('public/livesite/images/banners/1.jpg')}}') ;">
<div class="mask"></div>
<h1 class=" header_middle text-center animated bounceInDown slower go">Privacy Policy</h1>
</div>


<!--=======================================================-->






<!--======================= Questions  ========================-->

<section class="questions-answers container">
<div class="section-content">
    <div class="question">


        <p>  Thank you for your interest in IndyJohn!<p>
Privacy Policy coming soon.






    </div>

</div>

</section>

<!--=======================================================-->

@include('home.footerlinks')
@endsection
