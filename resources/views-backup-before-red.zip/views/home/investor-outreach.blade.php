@extends('home.app')
@section('content')
@include('home.header')
<!--======================= layout ========================-->

<div class="small-layout animatedParent" style="background-image: url('{{URL::asset('public/livesite/images/banners/4.jpg')}}') ;">
    <div class="mask"></div>
    <h1 class=" header_middle text-center animated bounceInDown slower go">Investor Outreach</h1>
</div>


<!--=======================================================-->




<!--======================= Navbar ========================-->
<div class="simple-navbar text-center relative">
    <ul class="list-inline">
        <li><a href="{{url('about-us')}}">About Us</a></li>
        <li><a href="{{url('faq')}}">FAQ</a></li>
        <li><a href="{{url('news')}}">Indy John News</a></li>
        <li class="active"><a href="{{url('investor-outreach')}}">Investor Outreach</a></li>
        <li><a href="{{url('contact-us')}}">Contact Us</a></li>
    </ul>
    <div class="vertical_lines"></div>
</div>

<!--=======================================================-->

<!--======================= Questions  ========================-->

<section class="questions-answers container">
    <div class="section-content">
        <div class="question">


            <p>Today many startup companies aim to solve many of the same problems and please many of the same communities. We've decided to focus on the industrial marketplace in hopes of bringing it to modernization. We don't have to tell you big the Industrial world is, we all inherently live in an industrial world, from the cranes raised above our city to the solar panels being installed across the world. This is a marketplace made of hard working people who spend on equipment, tools, and services and a network of suppliers who aim to satisfy these same people.

<p> Our goal is simple - We're going to simplify the experience and consolidate the processes for all industrial Buyers and Suppliers by unveiling the first Industrial Marketplace built on a Social Selling platform designed to ensure user success. Our platform has been constructed with features and tools intended to help people be more efficient and increase productivity.

                <p>Currently we're focused on a product-market fit, including building a large user base with quality contributors. We have fresh ideas and built-in revenue streams, some hitting the market now, some currently being constructed. Most importantly, we have a strong vision supported by confident projections and execution will be key to our success. While it's crucial we think about the future, we also know change will remain a constant and adaptation will be another key. We have no doubt, we will fulfill our mission.
                    <p>Indy John is in expansion mode, now is the ideal time to look for strategic partners to help us realize a market opportunity. If you're interested in assisting or playing a role in our growth as a company?
                        <p>Please contact us at <a href="mailto:partners@indyjohn.com">partners@indyjohn.com</a>
                            <p>Matters unrelated to partnerships should refer to support@indyjohn.com in order to reach the appropriate department and to insure a faster response.




        </div>

    </div>

</section>

<!--=======================================================-->
@include('home.footerlinks')
@endsection
