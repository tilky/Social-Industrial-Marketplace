@extends('buyer.app')

@section('content')

<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url()}}/user-dashboard">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="{{url()}}/supporttickets">Support Tickets</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>View</span>
        </li>
    </ul>
</div>
<div class="row">
    <div class="col-md-12">
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
        <div class="portlet box yellow-crusta">
            <div class="portlet-title">
                <div class="caption color-black">
                    <i class="fa fa-server color-black"></i> {{$ticket->title}} 
                </div>
                @if($user_access_level == 1)
                <div class="actions">
                    <div class="btn-group">
                        <input name="status" id="ticket-status" onchange="TicketStatus(id)" type="checkbox" @if($ticket->status == 0) checked @endif class="make-switch form-control" data-size="small" data-on-text="Open" data-off-text="Closed" >
                    </div>
                </div>
                @endif
            </div>
            <div class="portlet-body form">
                @if (Session::has('message'))
                    <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
                @endif
                <form method="post" action="{{url()}}/supporttickets/comment/save/{{$ticket->id}}" class="form-horizontal">
                    <input type="hidden" name="_token" value="{{csrf_token()}}">
                    <input id="ticket_id" type="hidden" name="ticket_id" value="{{$ticket->id}}" />
                    <input type="hidden" name="user_id" value="{{$userData->user_id}}" />
                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-12">
                                <h1 style="margin-top: 0px;">{{$ticket->title}}</h1>
                                <p>{{$ticket->description}}</p>
                            </div>
                            <div class="col-md-12">
                                @if(count($ticket->comments) == 0)
                                    <p>No comment Avilable</p>
                                @else
                                    @foreach($ticket->comments as $comment)
                                        <div class="row" style="padding-bottom: 10px;">
                                            <div class="col-md-12">
                                                @foreach($allUsers as $user)
                                                    @if($user->id == $comment->user_id)
                                                        <b>{{$user->name}} say:</b>
                                                    @endif
                                                @endforeach
                                            </div>
                                            <div class="col-md-12" style="padding-left: 30px;">{{$comment->comment}}</div>
                                        </div>
                                    @endforeach
                                @endif
                            </div>
                        </div>
                        @if($ticket->status == 0)
                        <div class="row">
                            <div class="col-md-12">
                                <div class="">
                                    <label class="control-label">Comment:</label>
                                    <textarea name="comment" class="form-control" placeholder="Add New Comment" required=""></textarea>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                    @if($ticket->status == 0)
                    <div class="form-actions right">
                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-circle green">
                                    <i class="fa fa-check"></i> Post</button>
                            </div>
                        </div>
                    </div>
                    @endif
                </form>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>
<script>
/* for show menu active */
$("#support-tickets-main-menu").addClass("active");
$('#support-tickets-main-menu' ).click();
$('#support-tickets-menu-arrow').addClass('open')
$('#support-ticket-view-menu').addClass('active');
/* end menu active */
function TicketStatus(id)
{
    var baseUrl = '{{url()}}';
    var status = $('#'+id).bootstrapSwitch('state');
    if(status == true)
    {
        var st_val = 0;
    }
    else{
        var st_val = 1;
    }
    var ticket_id = $('#ticket_id').val();
    //console.log(baseUrl+'/supporttickets/ticket/status/'+ticket_id+'/'+st_val);
    
    window.location.href = baseUrl+'/supporttickets/ticket/status/'+ticket_id+'/'+st_val;
}
</script>
@endsection
