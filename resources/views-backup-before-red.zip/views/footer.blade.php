<!-- BEGIN FOOTER -->
<div class="page-footer">
    <div class="page-footer-inner"> © QuoteTek Solutions, LLC. All Rights Reserved.
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<!-- END FOOTER -->
