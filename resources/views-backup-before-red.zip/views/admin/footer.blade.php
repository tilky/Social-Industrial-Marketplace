<!-- BEGIN FOOTER -->
<!-- /.modal -->
<div class="modal fade footer-modal" id="basic1" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h3 class="modal-title" style="text-transform: uppercase;">Help us Improve</h3>
                <p class="caption-helper" style="margin: 5px 0px!important;">Your feedback helps us understand what we do well and where we can improve.</p>
            </div>
            <form action="{{url('feedback/message')}}" method="post" class="horizontal-form">
                <input type="hidden" name="_token" value="{{csrf_token()}}" />
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 form-group">
                            <label class="control-label">Subject:</label>
                            <div class="">
                                <input type="text" name="subject" class="form-control" placeholder="Add a subject to your feedback" />
                            </div>
                        </div>
                        <div class="col-md-12 form-group">
                            <label class="control-label">Summary:</label>
                            <div class="">
                                <textarea name="message" class="form-control" rows="4" placeholder="Please describe your comments and feedback."></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-circle default" data-dismiss="modal">Close</button>
                    <button type="submite" class="btn btn-circle blue">Send</button>
                </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<!-- /.modal -->
<div class="modal fade footer-modal" id="basic" tabindex="-1" role="basic" aria-hidden="true" data-width="760">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">Invite Users</h4>
            </div>
            <div class="modal-body"> 
                <div class="title align-center">
                        <h2>Find your Collegues Aready on IndyJohn </h2>
                        <p>Find and Invite your collegues and friends to grow your network.</p>
                    </div>
                    <div class="form align-center paddin-bottom" style="width: 70%;margin: 0 auto;">
                        <!--  form-body  -->
            
                        <div class="align-center" >
                            <div class="row">
                                <div class="col-md-6 ">
                                    <a href="{{Session::get('google_invite_url')}}" target="_blank"><img src="{{url('public/images/Indy-John/gmail-icon.png')}}" class="img-circle center-block modal-invite-img"></a>
                                </div>
                                <div class="col-md-6 ">
                                    <a href="javascript:void(0)" onclick="GetYahooHeaderContact();"><img src="{{url('public/images/Indy-John/yahoo-icon.png')}}" class="img-circle modal-invite-img center-block"></a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 ">
                                    <a href="{{Session::get('msn_invite_url')}}" target="_blank"><img src="{{url('public/images/Indy-John/outlook-icon.png')}}" class="img-circle modal-invite-img center-block"></a>
                                </div>
                                <div class="col-md-6 ">
                                    <a href="{{url('invite/email')}}" target="_blank"><img src="{{url('public/images/Indy-John/mail-icon.png')}}" class="img-circle modal-invite-img center-block"></a>
                                </div>
                            </div>
                        </div>
                        <!--  /form-body  -->
            
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-circle dark btn-outline" data-dismiss="modal">Close</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<!-- Upgrade account modal -->
    <div class="modal fade general-pricing" id="upgrade-buyer-acount-modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <form method="post" action="{{url('user/packages/save')}}" role="form" id="payment-form-pop"  class="form-horizontal form-row-seperated">
            <input type="hidden" name="_token" value="{{csrf_token()}}">
            <input type="hidden" name="card_token" value="" id="card_token_pop" />
            <input type="hidden" name="card_last_4" value="" id="card_last_4_pop" />
            <input type="hidden" name="card_type" id="card_type_pop" value="" />
            <input type="hidden" name="cardNumber" id="cardNumber_pop" value="" />
            <input type="hidden" name="cardExpiry" id="cardExpiry_pop" value="" />
            <input type="hidden" name="cardCVC" id="cardCVC_pop" value="" />
            <input type="hidden" name="billing_plan" id="billing_plan_pop" />
            <input type="hidden" id="modal-type" />
        </form>
        <div class="modal-dialog">
            <div class="modal-content" id="payment-plan-buyer-div">
                <div class="modal-header">
                 
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    
                    </button>
                    <h4 class="modal-title" id="myModalLabel">
                    	Gain an Edge, Upgrade Your Buyer Dashboard.
                    </h4>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <h5>Gain pricing options by becoming a Buyer+</h5>
                        <p>Being a consumer in today’s industrial marketplace is difficult and desperately needs to be overhauled.  
                        We’ve developed features and tools to help buyers get the price they want. Upgrade to our Buyer+ account 
                        to gain benefits and simplify your purchasing process.  </p>
                    </div>
                    <br>
                    <br>
                    <div class="clearfix"></div>
                    
                    <div class="col-md-4">
                        <div class="thumbnail">
                        
                            <div class="caption">
                                <h1 class="box-title">
                                	FREE
                                </h1>
                                <h6>ACCOUNT</h6>
                                <h1><span>$</span>0</h1>
                                <h6>PER MONTH</h6>
                                <hr>
                                <ul class="free-list">
                                    <li>REQUESTS LIMITED TO 5/ DAY</li>
                                    <li>QUOTES DELAYED UP TO 1 DAY</li>
                                    <li>LIMITED TO 5 INDUSTRIAL MARKETS</li>
                                    <li>POST UP TO 30 MARKET LISTINGS</li>
                                    <li>MARKET LISTINGS EXPIRE MONTHLY</li>
                                    <li><span>VERIFICATION NOT INCLUDED</span></li>
                                </ul>
                                <button id="plan_FREE_2_0" onclick="updatePlan(id,'buyer');">Current Plan</button>
                            
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="thumbnail gray_color">
                        
                            <div class="caption">
                                <h1 class="box-title">
                                	BUYER+
                                </h1>
                                <h6>ACCOUNT</h6>
                                <h1><span>$</span>199</h1>
                                <h6>PER MONTH</h6>
                                <hr>
                                <ul class="free-list">
                                    <li><span>UNLIMITED</span> BUY REQUESTS</li>
                                    <li>QUOTES DELIVERED <span>INSTANTLY</span></li>
                                    <li><span>UNLIMITED</span> INDUSTRIAL MARKETS</li>
                                    <li><span>UNLIMITED</span> MARKET LISTINGS</li>
                                    <li>MARKET LISTINGS DO NOT EXPIRE</li>
                                    <li><span>VERIFICATION INCLUDED</span></li>
                                </ul>
                                <button class="upgrade" id="plan_BUYER+_1_19900" onclick="updatePlan(id,'buyer');">UPGRADE</button>
                            
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="thumbnail">
                        
                            <div class="caption">
                                <h1 class="box-title">
                                	ADVANCED
                                </h1>
                                <h6>ACCOUNT</h6>
                                <h2>COMING<br/> SOON</h2>                            
                                <div class="current-plan">
                                    <p><span>EXPANDED</span> FEATURES<br/> AND TOOLS</p>
                                </div>
                                <button class="upgrade">COMING SOON</button>
                            
                            </div>
                        </div>
                    </div>
                    
                    <div class="clearfix"></div>
                    <div class="footer-pricing">
                        <h4>Industrial Purchasing made Easy, Upgrade Now.</h4>
                        <h5>* These rates are set for 2016.</h5>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
        </div>
    
    </div>
    
    <div class="modal fade general-pricing" id="upgrade-supplier-acount-modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" >
                <div class="modal-header">
                 
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    	×
                    </button>
                    <h4 class="modal-title" id="myModalLabel">
                    	Gain an Edge, Upgrade Your Supplier CRM.
                    </h4>
                </div>
                <div class="modal-body" id="payment-plan-seller-div">
                    <div class="col-md-12">
                        <h5>Increase selling opportunities for the price of a cell phone bill.</h5>
                        <p>
                        We know sales environments can be very competitive, and prospecting for serious buyers can be very time
                        consuming.  Our technologies are designed to produce serious leads, gain advantages now by upgrading 
                        to one of our valued accounts designed to help you reach your sales goals.  
                        </p>
                    </div>
                    <br>
                    <br>
                    <div class="clearfix"></div>
                    
                    <div class="col-md-4">
                        <div class="thumbnail">
                        
                            <div class="caption">
                                <h1 class="box-title">
                                	FREE
                                </h1>
                                <h6>ACCOUNT</h6>
                                <h1><span>$</span>0</h1>
                                <h6>PER MONTH</h6>
                                <ul class="free-list">
                                    <li>REQUESTS LIMITED TO 5/ DAY</li>
                                    <li>QUOTES DELAYED UP TO 1 DAY</li>
                                    <li>LIMITED TO 5 INDUSTRIAL MARKETS</li>
                                    <li>POST UP TO 30 MARKET LISTINGS</li>
                                    <li>MARKET LISTINGS EXPIRE MONTHLY</li>
                                    <li><span>VERIFICATION NOT INCLUDED</span></li>
                                </ul>
                                <button id="plan_FREE_5_0" onclick="updatePlan(id,'seller');">Current Plan</button>
                            
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="thumbnail">
                        
                            <div class="caption">
                                <h1 class="box-title">
                                	SILVER
                                </h1>
                                <h6>ACCOUNT</h6>
                                <h1><span>$</span>149</h1>
                                <h6>PER MONTH</h6>
                                <ul class="free-list">
                                    <li>LEADS LIMITED TO 100 CATEGORIES</li>
                                    <li>LEADS DELAYEDUP TO 12 HOURS</li>
                                    <li>LIMITED TO 3 INDUSTRIAL MARKETS</li>
                                    <li>POST UP TO 100 MARKET LISTINGS</li>
                                    <li>LEADS LIMITED TO 150 PER MONTH</li>
                                    <li><span>VERIFICATION INCLUDED</span></li>
                                </ul>
                                <button class="upgrade-btn"  id="plan_SILVER_4_14900" onclick="updatePlan(id,'seller');">UPGRADE</button>
                            
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="thumbnail gray_color">
                            <div class="most-popular">
                            MOST POPULAR +<br/>
                            UNLIMITED ACCESS
                            </div>
                            <div class="caption">
                                <h1 class="box-title">
                                	GOLD
                                </h1>
                                <h6>ACCOUNT</h6>
                                <h1><span>$</span>199</h1>
                                <h6>PER MONTH</h6>
                                <ul class="free-list">
                                    <li><span>UNLIMITED</span> CATEGORIES</li>
                                    <li>LEADS DELIVERED <span> INSTANTLY</span></li>
                                    <li><span>UNLIMITED</span> INDUSTRIAL MARKETS</li>
                                    <li><span>UNLIMITED</span> MARKET LISTINGS</li>
                                    <li>RECIEVE <span>UNLIMITED</span>LEADS</li>
                                    <li><span>VERIFICATION INCLUDED</span></li>
                                </ul>
                                <button class="upgrade" id="plan_GOLD_3_19900" onclick="updatePlan(id,'seller');">UPGRADE</button>
                            
                            </div>
                        </div>
                    </div>
                    
                    <div class="clearfix"></div>
                    <div class="footer-pricing">
                    <h4>Don’t Limit Your Opportunities, Upgrade Now. </h4>
                    <h5>* These rates are set for 2016.</h5>
                    </div>
                </div>
            
            </div>
        
        </div>
    
    </div>
    
    <script src="https://checkout.stripe.com/checkout.js"></script>
    <script>
      var handler = StripeCheckout.configure({
        key: "{{env('STRIPE_PUBLIC_KEY', '')}}",
        image: "{{url('public/images/indy_john_crm_logo.png')}}",
        locale: 'auto',
        token: function(token) {
            
            var user_type = $('#modal-type').val();
            if(user_type == 'seller')
            {
                App.blockUI({
                    target: '#payment-plan-seller-div',
                    animate: true
                });
            }
            else
            {
                App.blockUI({
                    target: '#payment-plan-buyer-div',
                    animate: true
                });
            }
            $('#card_token_pop').val(token.id);
            $('#card_last_4_pop').val(token.card.last4);
            $('#cardNumber_pop').val('');
            $('#cardExpiry_pop').val(token.card.exp_month+' / '+token.card.exp_year);
            $('#cardCVC_pop').val('');
            $('#card_type_pop').val(token.card.brand+' '+token.type);
            $('#payment-form-pop').submit();
          // You can access the token ID with `token.id`.
          // Get the token ID to your server-side code for use.
        }
      });
      
      function updatePlan(id,user_type)
      {
        if(user_type == 'seller')
        {
            $('#modal-type').val('seller');
        }
        else
        {
            $('#modal-type').val('buyer');
        }
        
        var values = id.split('_');
        $('#billing_plan_pop').val(values[2]);
        
        // Open Checkout with further options:
        handler.open({
          name: "{{url('/')}}",
          description: values[1]+' ACCOUNT',
          email:"{{Auth::user()->email}}",
          amount: values[3]
        });
        
      }
      
      // Close Checkout on page navigation:
      $(window).on('popstate', function() {
        handler.close();
      });
    </script>

<!-- /.modal -->
<!-- dashboar select modal -->
<!-- /.modal -->
<div class="modal fade footer-modal" id="dashboard-select-modal" tabindex="-1" role="basic" aria-hidden="true" data-width="760">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">HOW DO YOU WANT TO START USING INDY JOHN?</h4>
            </div>
            <form class="" role="form" method="POST" action="{{url('profile/select-dashboard/save')}}">
            <input type="hidden" name="_token" value="{{csrf_token()}}">
            <div class="modal-body"> 
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="align-center"></h3>
                        
                        <div class="col-md-12 align-center">
                        
                            <div class="btn-group profile" data-toggle="buttons">
                                <label class="btn btn-circle btn-outline btn-primary btn-group invite-contact-sec-div active" id="pulsate-one">
                                    <input type="radio" name="user_type" value="2" autocomplete="off" checked=""> I'M A BUYER LOOKING TO FIND NEW SUPPLIERS
                                </label>
                                <label class="btn btn-circle btn-outline btn-primary" id="pulsate-two">
                                    <input type="radio" name="user_type" value="2" autocomplete="off"> I'M LOOKING FOR A SERVICE PROVIDER
                                </label>
                                <label class="btn btn-circle btn-outline btn-primary" id="pulsate-three">
                                    <input type="radio" name="user_type" value="3" autocomplete="off"> I'M LOOKING TO LIST PRODUCTS ON THE MARKET
                                </label>
                                <label class="btn btn-circle btn-outline btn-primary" id="pulsate-four">
                                    <input type="radio" name="user_type" value="3" autocomplete="off"> I'M A SUPPLIER LOOKING TO GET MORE LEADS
                                </label>
                                <label class="btn btn-circle btn-outline btn-primary" id="pulsate-five">
                                    <input type="radio" name="user_type" value="3" autocomplete="off"> I'M A SERVICE PROVIDER LOOKING FOR CUSTOMERS
                                </label>
                                <label class="btn btn-circle btn-outline btn-primary" id="pulsate-six">
                                    <input type="radio" name="user_type" value="2" autocomplete="off"> I'M A STUDENT LOOKING TO NETWORK
                                </label>
                                <label class="btn btn-circle btn-outline btn-primary" id="pulsate-seven">
                                    <input type="radio" name="user_type" value="2" autocomplete="off"> I'M LOOKING TO EARN MONEY USING REFERRALS
                                </label>
                                <label class="btn btn-circle btn-outline btn-primary" id="pulsate-eight">
                                    <input type="radio" name="user_type" value="2" autocomplete="off"> I'M A NOT SURE, LOOKING TO EXPLORE
                                </label>
                                <label class="btn btn-circle btn-outline btn-primary" id="pulsate-nine">
                                    <input type="radio" name="user_type" value="2" autocomplete="off"> I'M HERE TO POST OR LOOK FOR JOBS.
                                </label>
                            </div>
                            
                            
                        </div>
                       
                    </div>
                </div>
            </div>
           <!-- <div class="modal-footer">
                <button type="button" class="btn btn-circle dark btn-outline" data-dismiss="modal">Close</button>
                <button class="btn btn-circle yellow-crusta color-black bold" type="submit"> Finish </button>
            </div>-->
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<div class="page-footer">
    <div class="page-footer-inner"> © Indy John Inc. All Rights Reserved. <a href="javascript:void(0);" id="footer-feedback"><b>Feedback</b></a>
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<script>
$('#footer-feedback').click(function(){
    jQuery('#basic1').modal('show');    
});
$('#invite-user-header').click(function(){
    jQuery('#basic').modal('show');    
});
$('#upgrade-buyer-modal').click(function(){
    jQuery('#upgrade-buyer-acount-modal').modal('show');    
});
$('#upgrade-supplier-modal').click(function(){
    jQuery('#upgrade-supplier-acount-modal').modal('show');    
});
$('#show-dashboad-select').click(function(){
    jQuery('#dashboard-select-modal').modal('show');    
});
function GetYahooHeaderContact()
{
    App.blockUI({
        target: '#blockui_sample_1_portlet_body',
        animate: true
    });
    
    jQuery.ajax({
        url: '{{url("invite/yahoo/url")}}',
        type: 'get',
        success: function(data) {
                    //window.location.href = data.url;
                    window.open(data.url,'_blank');
                    App.unblockUI('#blockui_sample_1_portlet_body');
                 },
        done: function() {
            //console.log('error');
        },
        error: function() {
            //console.log('error');
        }
        
    }); 
}
</script>
<script>

$(document).ready(function() {

    $("#pulsate-one").click(function(){
       $(".pulsate-one-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-two").click(function(){
       $(".pulsate-two-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    
    $("#pulsate-three").click(function(){
       $(".pulsate-three-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-four").click(function(){
       $(".pulsate-four-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-five").click(function(){
       $(".pulsate-five-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-six").click(function(){
       $(".pulsate-six-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-seven").click(function(){
       $(".pulsate-seven-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
    
    $("#pulsate-eight").click(function(){
       $(".pulsate-eight-target").pulsate({
          color: '#1BBC9B', // set the color of the pulse
          reach: 20,                              // how far the pulse goes in px
          speed: 1000,                            // how long one pulse takes in ms
          pause: 0,                               // how long the pause between pulses is in ms
          glow: true,                             // if the glow should be shown too
          repeat: 5,                           // will repeat forever if true, if given a number will repeat for that many times
          onHover: false                          // if true only pulsate if user hovers over the element
        });
    });
		
 });


</script>
<script src="{{URL::asset('public/metronic/plugins/jquery.pulsate.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-bootpag/jquery.bootpag.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/holder.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/pages/scripts/ui-general.min.js')}}" type="text/javascript"></script>
<!-- END FOOTER -->
