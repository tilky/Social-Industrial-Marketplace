@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}}</h3>



<p style="float:left; text-align:left;">


Thank you for choosing to become a Verified user. 

Allow 7-10 days for application process. We will contact you shortly if any additional information is needed.

 <br /><br />Payment Details:
                            <br /><br />Account Name: {{$account_name}}
                            <br /><br />Transaction ID: {{$transaction_id}}
                            <br /><br />Date: {{$date}}
                            <br /><br />Invoice ID: {{$invoice_id}}
                            <br /><br /><a href="{{$invoicr_url}}" target="_blank">Click here to Print Invoice</a>

</p>
@include('admin.Emailtemplates.footer')
