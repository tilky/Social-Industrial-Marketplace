@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}},</h3>



<p style="float:left; text-align:left;">



  <br /><br />We have found a buyer Lead that are interested in your offering. 
                            <br /><br />Product Type: {{$product_type}}
                            <br /><br />Industry: {{$industries}}
                            <br /><br />Buyer Name: {{$buyer_name}}
                            <br /><br />Buyer E-mail: {{$buyer_email}}
                            <br /><br />Buyer Indy John profile page: {{$buyer_profile_link}}
                            <br /><br />Sign in to your Indy John account to view more requirements and details about this lead. 



</p>

@include('admin.Emailtemplates.footer')

                
