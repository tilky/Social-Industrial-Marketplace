@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello Indy John Admin,</h3>


<p style="float:left; text-align:left;">

Someone has contacted you from Indy John.com 
<br />



                            <h3>Contact From {{$name}},</h3>
                            </br>Name: {{$name}}
                            </br>Email: {{$email}}
                            </br>Phone: {{$phone}}
                            </br>Department: {{$department}}
                            </br>Message: {{$description}}




</p>
@include('admin.Emailtemplates.footer')
