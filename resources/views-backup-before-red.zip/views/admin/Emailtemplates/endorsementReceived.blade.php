
@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},,</h3>

<p style="float:left; text-align:left;">You have received an endorsement from {{$sender_first_name}} {{$sender_last_name}} on <a href="http://indyjohn.com"> Indy John</a>. Log in to accept their Endorsement. 
                           <br /><br /> <b>Remember to network more efficiently by sharing your Indy John profile with your co-workers and business associates.</b>





</p>

@include('admin.Emailtemplates.footer')



                        
