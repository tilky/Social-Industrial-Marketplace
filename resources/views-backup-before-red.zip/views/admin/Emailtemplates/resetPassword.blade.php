
@include('admin.Emailtemplates.header')

<div style="width: 100%;">
<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>
</div>
<div style="width: 100%;">
<br />

Your New Password is: {{$password}}

<br />
<br />
If you have any query regarding log in, please <a href="mailto:support@indyjohn.com">Indy John Support Team</a>.
</div>

@include('admin.Emailtemplates.footer')
