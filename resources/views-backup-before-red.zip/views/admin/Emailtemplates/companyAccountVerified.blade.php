@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}}</h3>



<p style="float:left; text-align:left;">

                            Thank you for your patience. Indy John team has completed our verification process. Your company account is now verified. 
	<br /><br />						
					<br />		Payment Details:
<br /><br />Account Name: {{$account_name}}
                     <br />       Transaction ID: {{$transaction_id}}
                      <br />      Date: {{$date}}
                     <br />       Invoice ID: {{$invoice_id}}
                     <br /><br />      
    
</p>
@include('admin.Emailtemplates.footer')                   
