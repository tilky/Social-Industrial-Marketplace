
@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello  Admin,</h3>

<p style="float:left; text-align:left;"> Someone left us feedback: 

  Feedback from {{$sender_name}}<br />
                          Subject: {{$subject}}<br />
                          Summary: {{$custome_message}}<br />



</p>

@include('admin.Emailtemplates.footer')

