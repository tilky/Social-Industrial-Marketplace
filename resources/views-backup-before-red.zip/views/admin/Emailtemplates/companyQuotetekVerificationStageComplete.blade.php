@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}}</h3>



<p style="float:left; text-align:left;">

Thank you for your patience. Indy John team has completed our verification process and has approved Verification Status for your account.
		<br /> <br /> Please login to <a href="http://indyjohn.com">Indy John</a> and start exploring. 					
<br />
      






</p>
@include('admin.Emailtemplates.footer')

                            
