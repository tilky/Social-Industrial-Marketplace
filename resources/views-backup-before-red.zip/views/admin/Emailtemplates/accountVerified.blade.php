@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}}</h3>



<p style="float:left; text-align:left;">


                        
                            <br />Thank you for your patience. Indy John team has completed our verification process.
                            Your account is now active with Indy John verified seal.
                            <br />Payment Details:
                            <br />Account Name: {{$account_name}}
                            <br />Transaction ID: {{$transaction_id}}
                     
		Log in to <a href="http://indyjohn.com">Indy John</a> to view invoice and transaction details. 			 
</p>
@include('admin.Emailtemplates.footer')
