
@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">




                          
                            <BR />This is to confirm that your product titled <b>{{$product_title}} </b>is now listed in the Indy John Market.
                            <BR /><BR />Here's the direct link to access it online: {{$link}}
                           <BR />
						   
                           <BR />If you didn’t post the product listed above?  Please let us know by contacting <a href="mailto:support@indyjohn.com"> Indy John Support Team</a>/
						   </p>
						   
@include('admin.Emailtemplates.footer')
						   
