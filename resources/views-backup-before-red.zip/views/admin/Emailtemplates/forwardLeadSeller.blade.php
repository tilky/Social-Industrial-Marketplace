@include('admin.Emailtemplates.header')

<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$forward_to_name}},</h3>

<p style="float:left; text-align:left;">
{{$sender_name}} finds you as a good fit for a Buy Request, and has forwarded you a lead for  {{$product_category}}.</p><br />

                            <b><BR />Lead details :
							
                       <BR />      <BR />Product/Category: {{$product_category}}
                            <BR />Date Submitted: {{$date_submitted}}
                           <BR />Submitted by: {{$person_name}}
                            <BR />Category selected: {{$categories}}
                           <BR />Industry Selected: {{$indutries}}
							
                         <BR /><BR />If you are new to Indy John, please visit and Sign up for <a href="http://indyjohn.com"> Indy John</a>. It's free to receive new leads!

						 </p>
						 
@include('admin.Emailtemplates.footer')
