@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},,</h3>

<p style="float:left; text-align:left;">
Thank you for choosing to become an Indy John Verified User. <br />
Indy John team has completed our verification process and has approved your account for the Indy John User Verification program.  <br />

<br /><br />
Transaction Details: <br /><br />

<br />Transaction ID: 
<br />Date: 
<br />Invoice ID:
<br /><br />
Login to Indy John and visit <a href=http://app.indyjohn.com/user/payment-history> Account Transaction History.</a>



</p>

@include('admin.Emailtemplates.footer')

