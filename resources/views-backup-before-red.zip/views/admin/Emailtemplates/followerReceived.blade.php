
@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">

   {{$sender_first_name}} {{$sender_last_name}} has started following you this week. View them on your profile at : {{$sender_profile_link}}.
            
</p>

@include('admin.Emailtemplates.footer')





                   
