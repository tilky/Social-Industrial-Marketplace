@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$company_name}} Administrator,</h3>

<p style="float:left; text-align:left;">


Thank you for your interest in getting Company page Verified on Indy John.
 <br /> <br />
Please allow 7-10 days for application process. We will contact you if any more information is needed. 
 <br /> <br />
                           <br /> Transaction Details:
                         <br />    Account Name: {{$account_name}}
                         <br />    Transaction ID: {{$transaction_id}}
                         <br />    Date: {{$date}}
                         <br />    Invoice ID: {{$invoice_id}}
                            </p>
@include('admin.Emailtemplates.footer')
