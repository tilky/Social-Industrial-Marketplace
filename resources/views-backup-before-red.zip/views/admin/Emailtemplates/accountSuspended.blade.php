
@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">Your account has been suspended. Please contact<a href="mailto:support@indyjohn.com">Indy John Support Team</a> team at the earliest to learn more and fix the situation.





</p>

@include('admin.Emailtemplates.footer')
