@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">

                            <h3>Hi {{$name}},</h3>

							<br /> A Supplier has submitted a quote for your Buy Request with the following details:
                        
                          <br /><br />
                           Interested Supplier Name: {{$supplier_name}}
                           <br />Supplier E-mail: {{$supplier_email}}
                            <br />Supplier QuoteTek profile page: {{$profile_link}}
							
							 <br /><br /><a href="{{$quote_url}}">View this Quote on Indy John </a>
                            
                  </p>
				  
@include('admin.Emailtemplates.footer')
