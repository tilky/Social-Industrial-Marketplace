@include('admin.Emailtemplates.header')

                           <h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$company_name}} Admin,</h3>
		<p style="float:left; text-align:left;">
				   
                          <br />    <br />A new user has selected your company account, {{$company_name}} to be added. Would you like to add them to your account?
                            <br />  <br />Please note: once added, they will be billed with your company account.
                           <br />   <br />New Account Details:
                              <br /><br />Name: {{$first_name}} {{$last_name}}
                            <br />Date Joined: {{$date_joined}}
                            <br />E-mail Address: {{$user_email}}
                            <br />Phone number: {{$user_phone}}
                            <br />Industry Selected: {{$user_industry}}
                            <br /><a href="{{$approve_link}}" target="_blank">Approve this User</a>  |   <a href="{{$deny_link}}" target="_blank">Deny this User</a>
</p>
@include('admin.Emailtemplates.footer')
