@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

             Hi {{$name}},</h3>



<p style="float:left; text-align:left;">

Thank you for your patience. Indy John team has completed our verification process and has approved your Verification Status. 





</p>
@include('admin.Emailtemplates.footer')
 
