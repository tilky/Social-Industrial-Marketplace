
@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">

                     Welcome and Thank you for signing up with <a href="http://indyjohn.com">Indy John</a>. You are now a member of the first social marketplace dedicated to the Industrial workforce. We hope you enjoy our service !
                        
                          <br /><br />
                           <p>Thank you for signing up for a Buyer Account at QuoteTek: An industrial Marketplace. QuoteTek is the new way to connect Buyers with Suppliers of Industrial Products and Services.</p>
                            <p>
                                Please verify your e-mail by clicking the following link: <br />
                                {{url('quotetekverification')}}
                            </p>
                            <p>The following features are included: </p>
                            <p><b>QuoteTek Platform:</b> You can contact sellers on the marketplace, build your network, receive and send reviews, endorsements and manage your professional profile.</p>
                            <p><b>Quote System:</b> Your account includes requesting 10 product quote requests daily. Our suppliers will contact you through the platform with quotations per your specifications. You can then Choose a Supplier that best fits your needs.</p>
                            <p>If you would like to submit another quote request for product or service, simply login and add them from your profile.</p>
                            <p><b>MarketPlace:</b> You can list up to 30 products for Free at our marketplace each month. You can also contact sellers on the marketplace.</p>
                            <p>An upgraded Buyer Plus account is also available if you are looking to surpass daily limits. {{$learn_more}}</p>		
								
							
							 <br /><br />Begin Exploring at <a href="http://indyjohn.com">Indy John</a> Now.
                            
                  </p>
				  
@include('admin.Emailtemplates.footer')
