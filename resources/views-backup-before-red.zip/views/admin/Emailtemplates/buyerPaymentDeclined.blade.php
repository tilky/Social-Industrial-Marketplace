@include('admin.Emailtemplates.header')



<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">

Hello {{$name}}</h3>



<p style="float:left; text-align:left;">

                            Unfortunately, we were unable to process your payment. Kindly log in to <a href="http://indyjohn.com">Indy John</a> and update your payment settings at the earliest so that we can try again. <br /><br />You are subscribed for :
                       <br />     <br />
                        <br />    Account Package: {{$plan}}
                        <br />    Amount Due: {{$fees}}
<br />
           </p>
@include('admin.Emailtemplates.footer')        
