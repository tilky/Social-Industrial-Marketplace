@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},</h3>

<p style="float:left; text-align:left;">
Thank you for choosing to become an Indy John Verified User. <br />
We have received your application fee and will contact you shortly if additional information is needed. <br />
<br />Please allow 7-10 days for application process. 
<br /><br />
Transaction Details: <br /><br />

<br />Transaction ID: {{$transaction_id}} 
<br />Date: {{$date}}
<br />Invoice ID: {{$invoice_id}}
<br /><br />
Login to Indy John and visit <a href=http://app.indyjohn.com/user/payment-history> Account Transaction History.</a>



</p>

@include('admin.Emailtemplates.footer')



