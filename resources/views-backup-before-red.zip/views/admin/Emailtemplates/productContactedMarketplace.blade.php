

@include('admin.Emailtemplates.header')


<h3 style="float:left; margin:40px 0px 10px; font-weight: 500;">Hello {{$name}},,</h3>

<p style="float:left; text-align:left;">

                            <br />The your Product listing,{{$title}} is getting noticed and has received the following enquiry:
                            <br />
                            <br />Buyer Name: {{$buyer_name}}
                            <br />Buyer Phone Number: {{$buyer_phone}}
                     
                            <br />Sign in to your Indy John account to Read the Full message and view more information about this lead. 
							
   
</p>

@include('admin.Emailtemplates.footer')
