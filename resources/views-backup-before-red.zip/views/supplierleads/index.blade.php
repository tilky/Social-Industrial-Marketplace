@extends('buyer.app')

@section('content')
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url()}}">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>Supplier Leads</span>
        </li>
    </ul>
</div>
<div class="col-md-12 main_box">
<div class="row">
<div class="col-md-12 border2x_bottom">
<div class="col-md-9 col-sm-9">
<div class="row">
<h3 class="page-title uppercase"> 
<i class="fa fa-server"></i> Lead Request Manager
</h3>
</div>
</div>
<div class="col-md-3 col-sm-3 text-right">
<div class="row">
  @if($user_access_level == 3)
                <div class="actions margin-top-10">
                    <a href="{{ URL::to('supplier-leads/create') }}" class="btn btn-circle btn-danger btn-sm">
                        <i class="fa fa-plus"></i> Create a New Lead Request</a>
                </div>
                @endif
                </div>
                </div>
</div>
</div>
<div class="row">
    <div class="col-md-12">
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
            <div class="portlet-body">
                @if (Session::has('message'))
                    <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
                @endif
                <div class="col-md-12 paddin-npt">
                    <div class="col-md-9 paddin-npt">
                        <p class="caption-helper">Easily administer your product and category lead request here. </p>
                    </div>
                    <div class="col-md-3 margin-top-20" style="text-align: right;padding-bottom: 10px;">
                        Sort by: 
                        @if($lead_hidden_val == 'desc')
                        <a href="{{url('supplier-leads')}}?lead_order_name=expiry_date&lead_order_by=asc">@if($lead_hidden_name == 'expiry_date')<b>Expiry Date <i class="fa fa-long-arrow-down"></i></b> @else Expiry Date @endif </a> | 
                        <a href="{{url('supplier-leads')}}?lead_order_name=created_at&lead_order_by=asc">@if($lead_hidden_name == 'created_at')<b>Submitted Date <i class="fa fa-long-arrow-down"></i></b> @else Submitted Date @endif </a>
                        @else
                        <a href="{{url('supplier-leads')}}?lead_order_name=expiry_date&lead_order_by=desc">@if($lead_hidden_name == 'expiry_date')<b>Expiry Date <i class="fa fa-long-arrow-up"></i></b> @else Expiry Date @endif </a> | 
                        <a href="{{url('supplier-leads')}}?lead_order_name=created_at&lead_order_by=desc">@if($lead_hidden_name == 'created_at')<b>Submitted Date <i class="fa fa-long-arrow-up"></b> @else Submitted Date @endif </i></a>
                        @endif
                    </div>
                </div>
                
                
                <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                    <thead>
                    <tr>
                        <th> Category Requested </th>
                        <th style="width: 450px;"> Industries </th>
                        <th> Date Submitted </th>
                        <th> Expiry Date </th>
                        <th>Lead matched</th>
                        <th> Action </th>
                    </tr>
                    </thead>
                    <tbody>
                        @foreach($supplierLeads as $index=>$lead)
                        <tr>
                            <td style="max-width: 200px;">
                                @foreach($lead->categories as $cat_index=>$category)
                                    @if($cat_index == 0)
                                    {{$category->category->name}}
                                    @else
                                    , {{$category->category->name}}
                                    @endif
                                @endforeach
                            </td>
                            <td>
                                @foreach($lead->industries as $ind_index=>$industry)
                                    @if($ind_index == 0)
                                    {{$industry->industry->name}}
                                    @else
                                    , {{$industry->industry->name}}
                                    @endif
                                @endforeach
                            </td>
                            <td>
                                {{date('M d, Y',strtotime($lead->created_at))}}
                            </td>
                            <td>
                                @if(strtotime($lead->expiry_date) > 0)
                                {{date('M d, Y',strtotime($lead->expiry_date))}}
                                @else
                                N/A
                                @endif
                            </td>
                            <td></td>
                            <td>
                                <!--<a href="{{ route('supplier-leads.show', $lead->id) }}" class="btn btn-circle btn-success btn-sm">
                                <i class="fa fa-eye"></i> View </a>-->
                                <a href="{{ route('supplier-leads.edit', $lead->id) }}" class="btn btn-circle btn-success btn-sm">
                                    <i class="fa fa-edit"></i> Edit </a>
                                @if($lead->status == 0)
                                <a href="{{url('supplierlead/status/update')}}/{{$lead->id}}/1" class="btn btn-circle btn-danger btn-sm">
                                <i class="fa fa-pause"></i> Inactive </a>
                                @else
                                <a href="{{url('supplierlead/status/update')}}/{{$lead->id}}/0" class="btn btn-circle btn-info btn-sm">
                                <i class="fa fa-play"></i> Active </a>
                                @endif
                                <a id="deleteButton" data-id="{{$lead->id}}" data-toggle="modal" href="#deleteConfirmation" class="btn btn-circle btn-danger btn-sm">
    
                                {!! Form::open([
                                'method' => 'DELETE',
                                'id' => 'DELETE_FORM_'.$lead->id,
                                'route' => ['supplier-leads.destroy', $lead->id]
                                ]) !!}
                                {!! Form::close() !!}
                                    <i class="fa fa-remove"></i> Delete </a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                <ul class="pager">
                    @if($previousPageUrl != '')
                    <li class="previous">
                        <a href="{{$previousPageUrl}}"> <i class="fa fa-long-arrow-left"></i> Prev </a>
                    </li>
                    @endif
                    @if($nextPageUrl != '')
                    <li class="next">
                        <a href="{{$nextPageUrl}}"> Next <i class="fa fa-long-arrow-right"></i> </a>
                    </li>
                    @endif
                </ul>
            </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>
</div>
<script>
    /* for show menu active */
    $("#quote-main-menu").addClass("active");
	$('#quote-main-menu' ).click();
	$('#quote-menu-arrow').addClass('open')
	$('#leads-view-menu').addClass('active');
    /* end menu active */
    
    $(document).on("click", "#deleteButton", function () {
        var id = $(this).data('id');
        jQuery('#deleteConfirmation .modal-body #objectId').val( id );
    });

    jQuery('#deleteConfirmation .modal-footer button').on('click', function (e) {
        var $target = $(e.target); // Clicked button element
        $(this).closest('.modal').on('hidden.bs.modal', function () {
            if($target[0].id == 'confirmDelete'){
                $( "#DELETE_FORM_" + jQuery('#deleteConfirmation .modal-body #objectId').val() ).submit();
            }
        });
    });
</script>
@endsection
