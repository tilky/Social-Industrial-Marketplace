@extends('buyer.app')

@section('content')
<style>
.media, .media-body{overflow: visible!important;}
.quotes-cat{margin: 0px 0px 5px 0px;}
</style>
<link href="{{URL::asset('public/css/style-additions.css')}}" rel="stylesheet" />
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url('user-dashboard')}}">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>Manage Applicants</span>
        </li>
    </ul>
</div>


<div class="col-md-12 main_box">
<div class="row">

<div class="col-md-12 border2x_bottom">
<h3 class="page-title uppercase"> 
<i class="fa fa-users color-black"> </i> Manage Applicants for {{$job->title}}
</h3>

</div>
</div>
            

                

            <div class="portlet-body form" id="blockui_sample_1_portlet_body" style="float: left;width: 100%;padding: 10px!important;">
                @if (Session::has('message'))
                    <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
                @endif
                <div class="col-md-12 paddin-npt">
                    <div class="mt-element-step">
                    <div class="row step-line">
                        <div id="company-first" class="col-md-4 mt-step-col first done">
                            <div class="mt-step-number bg-white">1</div>
                            <div class="mt-step-title uppercase font-grey-cascade">Enter Listing Details</div>
                        </div>
                        <div id="company-second" class="col-md-4 mt-step-col done">
                            <div class="mt-step-number bg-white">2</div>
                            <div class="mt-step-title uppercase font-grey-cascade">Job Listing Payment</div>
                        </div>
                        <div id="company-third" class="col-md-4 mt-step-col last active">
                            <div class="mt-step-number bg-white">3</div>
                            <div class="mt-step-title uppercase font-grey-cascade">Manage Applicants</div>
                        </div>
                    </div>
                </div>
                    
                </div>
                
                @if($total > 0)
                @foreach ($applicants as $index=>$applicant)
                <div class="tablebg">
                    <div class="colmd12 lead-active ">
                        <div class="row">
                          <div class="col-md-3 text-center"> 
                            @if($applicant->user->userdetail->profile_picture != '')
                            <img src="{{url('')}}/{{$applicant->user->userdetail->profile_picture}}" alt="sell" class="img-circle" >
                            @else
                            <img src="{{url('public/images/default-user.png')}}" alt="sell" class="img-circle" width="80px">
                            @endif
                            <h5>{{$applicant->user->userdetail->first_name}} {{$applicant->user->userdetail->last_name}} @if($applicant->userCompany != '') | {{$applicant->userCompany->name}} @endif</h5>
                            <h5> @if($applicant->user->quotetek_verify == 1) VERIFIED MEMBER @else NOT VERIFIED @endif </h5> 
                            
                            @if($applicant->user->account_member == 'gold')
                            <button type="button" class="btn btn-circle btn-gold btn-block">GOLD MEMBER</button>
                            @elseif($applicant->user->account_member == 'silver')
                            <button type="button" class="btn btn-circle btn-silver btn-block">SILVER MEMBER</button>
                            @else
                            <button type="button" class="btn btn-circle btn-free btn-block">FREE MEMBER</button>
                            @endif                                                                                                 
                            
                            <ul class="list-inline profile_num">
                              <li> <img alt="" src="{{url('public/images/cmnt_icon.png')}}"> {{count($applicant->user->messages)}}</li>
                              <li> <img alt="" src="{{url('public/images/hrt_icon.png')}}"> {{count($applicant->user->endorsements)}}</li>
                              <li> <img alt="" src="{{url('public/images/star_icon.png')}}"> {{count($applicant->user->reviews)}}</li>
                            </ul>
                          </div>
                          <div class="col-md-7 received-lead-con">
                            <h4>{{$applicant->user->userdetail->first_name}} {{$applicant->user->userdetail->last_name}}</h4>
                            <h5> Applied on: <strong>{{date('M d, Y',strtotime($applicant->created_at))}}</strong> </h5>
                            
                          </div>
                          <div class="col-md-2 text-center">
                            <!--<div class="price-text">$2500</div>-->
                            <!--<div class="price-text">N/A</div>-->
                            <div class="btn-group pull-right" style="width: 60%;">
                              <div class="actions" style="width: 100%;">
                                <div class="btn-group" style="width: 100%;padding: 10px;">
                                    <a class="btn btn-circle btn_yellow hvr-bounce-to-right" style="padding: 10px 21px;" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> Actions
                                        <i class="fa fa-angle-down"></i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                       
                                        <li>
                                            <a href="{{url('job/application/view')}}/{{$applicant->id}}" >
                                            <i class="icon-eye"></i> View Application</a>
                                        </li> 
                                        <li class="divider"> </li>
                                        <li>
                                            <a href="{{url('home/user/profile')}}/{{$applicant->user_id}}" target="_blank">
                                            <i class="fa fa-user"></i> View Applicant Profile</a>
                                        </li>
                                        <li class="divider"> </li>
                                        <li>
                                            <!--<a href="{{url('messages/create')}}?buyer={{$applicant->user_id}}" target="_blank">
                                            <i class="fa fa-envelope-o"></i> Message</a>-->
                                            <a href="#message_modal" data-toggle="modal" data-target="#message_modal" onclick="messageUser({{$applicant->user_id}})">
                                            <i class="fa fa-envelope-o"></i> Message</a>
                                        </li>
                                        <li class="divider"> </li>
                                        <li>
                                            <a href="javascript:;" onclick="addNote({{$applicant->id}})">
                                            <i class="fa fa-user"></i> Add Notes</a>
                                        </li>
                                        <li class="divider"> </li>
                                        <li>
                                            <a id="deleteButton" data-id="{{url('applicant/reject')}}/{{$applicant->id}}" data-toggle="modal" href="#deleteConfirmation">
                                            <i class="fa fa-user"></i> Ignore Applicant</a>
                                        </li> 
                                    </ul>
                                </div>
                            </div>
                            </div>
                          </div>
                            
                        </div>
                        
                    </div>
                </div>
                
                @endforeach
                @else
                <div class="col-md-12 padding-top paddin-bottom" style="background: #fff;margin: 10px 0px;">
                    <p>You have not received applicant yet.</p>
                </div>
                @endif
                
                <ul class="pager">
                    @if($previousPageUrl != '')
                    <li class="previous">
                        <a href="{{$previousPageUrl}}"> <i class="fa fa-long-arrow-left"></i> Prev </a>
                    </li>
                    @endif
                    @if($nextPageUrl != '')
                    <li class="next">
                        <a href="{{$nextPageUrl}}"> Next <i class="fa fa-long-arrow-right"></i> </a>
                    </li>
                    @endif
                </ul>
        
      </div>
      
    </div>
<!-- Add note modal -->
<div class="modal fade" id="new_apply_job_notes" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">Add A New Note</h4>
            </div>
            <form action="{{url('applicant/note/save')}}" class="form-horizontal" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="{{csrf_token()}}" />
                <input type="hidden" name="job_apply_id" value="" id="apply-job-id" />
                <input type="hidden" name="user_id" value="{{Auth::user()->id}}" />
                <div class="modal-body">
                <!-- BEGIN FORM-->
                    <div class="form-body">
                        <div class="form-group">
                            <label class="col-md-3 control-label">Note</label>
                            <div class="col-md-9">
                                <textarea class="form-control" rows="6" placeholder="Enter Note Description" name="note" required=""></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger  btn-circle " data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-circle yellow-crusta color-black  btn-circle ">Save</button>
                </div>
                <!-- END FORM-->
                </form>
            </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- end -->
      

<script>
    /* for show menu active */
    $("#quote-main-menu").addClass("active");
	$('#quote-main-menu' ).click();
	$('#quote-menu-arrow').addClass('open')
	$('#quote-view-menu').addClass('active');
    /* end menu active */
    
    $(document).on("click", "#deleteButton", function () {
        var id = $(this).data('id');
        jQuery('#deleteConfirmation .modal-body #objectId').val( id );
    });

    jQuery('#deleteConfirmation .modal-footer button').on('click', function (e) {
        var $target = $(e.target); // Clicked button element
        $(this).closest('.modal').on('hidden.bs.modal', function () {
            if($target[0].id == 'confirmDelete'){
                window.location.href = jQuery('#deleteConfirmation .modal-body #objectId').val();
            }
        });
    });
function addNote(id)
{
    $('#apply-job-id').val(id);
    $('#new_apply_job_notes').modal('show');
}
    
</script>
<script src="{{URL::asset('public/js/starrr.js')}}" type="text/javascript"></script>
@endsection
