@extends('buyer.app')

@section('content')
<link href="{{URL::asset('public/css/style-additions.css')}}" rel="stylesheet">

<link href="{{URL::asset('public/metronic/plugins/socicon/socicon.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/datatables/datatables.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css')}}" rel="stylesheet" type="text/css" />
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url()}}/user-dashboard">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="{{url()}}/contactusers">Contact List</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>Add Contact</span>
        </li>
    </ul>
</div>
<!--<h3 class="page-title"> Result for Search: "{{$search}}" </h3>-->
<div class="col-md-12 main_box">
<div class="row">
    <div class="col-md-12 col-sm-12">
        <div class="portlet light ">
            @if (Session::has('message'))
                <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
            @endif
            @if($search != '')
            <div class="portlet-title tabbable-line text-center ">
                <ul class="nav nav-tabs center-nav">
                    <li class="active all_result_tab">
                        <a href="{{url('general/search')}}?query={{$_REQUEST['query']}}" >All Results</a>
                    </li>
                    <li class="people_tab">
                        <a href="{{url('people/search')}}?query={{$_REQUEST['query']}}">People</a>
                    </li>
                    <li class="company_tab">
                        <a href="{{url('company/search')}}?query={{$_REQUEST['query']}}" >Companies</a>
                    </li>
                    
                    <li class="product_tab">
                        <a href="{{url('product/search')}}?query={{$_REQUEST['query']}}">Products</a>
                    </li>
                    <li class="job_tab">
                        <a href="{{url('jobs/search/result')}}?query={{$_REQUEST['query']}}">Jobs</a>
                    </li>
                </ul> 
            </div>
                        <div class="portlet-body all_result_tab_body">
                <div class="tab-content">
                    <div class="tab-pane active" id="portlet_comments_1"> 
                        <!-- BEGIN: Comments -->
                        @if(count($results) > 0)
                            <div class="mt-comments col-md-9 col-sm-12 center-block margin-bottom-20 float_none">
                            <div class="row">
                                <p class="text-right res_found">@if($total == 1){{$total}} Result Found @else {{$total}} Results Found for {{$search}} @endif</p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            @foreach ($results as $result)
                                
                                    
                                    @if($result->search_type == 'user')
                                    <div class="mt-comments col-md-9 col-sm-12 center-block no_filter all_people">
                                    <div class="mt-comment result">
                                        <div class="mt-comment-img"> 
                                            <a href="{{url('home/user/profile')}}/{{$result->id}}" target="_blank">
                                            @if($result->userdetail->profile_picture != '')
                                            <img src="{{url('')}}/{{$result->userdetail->profile_picture}}" alt="{{$result->userdetail->first_name}} {{$result->userdetail->last_name}}" class="img-circle">
                                            @else
                                            <img src="{{url('public/images/default-user.png')}}" alt="{{$result->userdetail->first_name}} {{$result->userdetail->last_name}}" class="img-circle" width="80px">
                                            @endif
                                            </a>
                                        </div>
                                        <div class="mt-comment-body">
                                            <div class="mt-comment-info"> 
                                                <a href="{{url('home/user/profile')}}/{{$result->id}}" target="_blank">
                                                <span class="mt-comment-author font-20">
                                                    {{$result->userdetail->first_name}} {{$result->userdetail->last_name}}
                                                </span>
                                                </a>
                                                @if($result->star == 'gold')
                                                <span class="label label-sm label-warning gold-member caps-on"> Gold Member </span> 
                                                @elseif($result->star == 'silver')
                                                <span class="label label-sm label-default silver-member caps-on"> Silver Member </span> 
                                                @else
                                                <span class="label label-sm label-default free-member caps-on"> Free Member </span> 
                                                @endif
                                                @if($result->quotetek_verify == 1)
                                                <span class="label label-sm label-default verify-member caps-on"> Verified Member</span>
                                                @else
                                                <span class="label label-sm label-default verify-member caps-on"> Not Verified</span>
                                                @endif
                                                <div class="actions pull-right">
                                                    <div class="btn-group"> 
                                                        <a class="btn btn-circle  btn_yellow hvr-bounce-to-right" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> Actions <i class="fa fa-angle-down"></i> </a>
                                                        <ul class="dropdown-menu pull-right">
                                                            <li>
                                                                <a href="{{url('home/user/profile')}}/{{$result->id}}" target="_blank">
                                                                    <i class="icon-docs"></i> View Profile </a>
                                                            </li>
                                                            <li class="divider"> </li>
                                                            <li>
                                                                <a href="{{url('messages/create')}}?buyer={{$result->id}}" target="_blank">
                                                                    <i class="fa fa-envelope-o"></i> Message </a>
                                                            </li>
                                                            <li class="divider"> </li>
                                                            <li>
                                                                <a href="{{url('contactusers/contact/send/')}}/{{Auth::user()->id}}/{{$result->id}}" target="_blank">
                                                                    <i class="fa fa-send-o"></i> Connect </a>
                                                            </li>
                                                            <li>
                                                                <a href="{{url('endorse-user')}}/{{Auth::user()->id}}/{{$result->id}}">
                                                                    <i class="fa fa-thumbs-up"></i> Endorse </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mt-comment-author">
                                                @if($result->userdetail->current_position != '')
                                                {{$result->userdetail->current_position}}
                                                @endif
                                                @if($result->company_name != '')
                                                    , {{$result->company_name}}
                                                @endif
                                            </span>
                                            <div class="mt-comment-text">{{substr($result->userdetail->about,0,90)}}</div>
                                            <span class="mt-comment-status">@if($result->userdetail->city != ''){{$result->userdetail->city}},{{$result->userdetail->state}},{{$result->userdetail->country}} @endif @if($result->userdetail->getUserIndustry)| {{$result->userdetail->getUserIndustry->name}}@endif</span> 
                                        </div>
                                    </div>
                                    </div>
                                    @elseif($result->search_type == 'company')
                                    <div class="mt-comments col-md-9 col-sm-12 center-block no_filter all_company">
                                    <div class="mt-comment result">
                                        <div class="mt-comment-img"> 
                                            <a href="{{url('company/profile')}}/{{$result->id}}" target="_blank">
                                            @if($result->logo != '')
                                            <img src="{{url('')}}/{{$result->logo}}" alt="{{$result->name}}" class="img-circle" />
                                            @else
                                            <img src="{{url('public/images/default-user.png')}}" alt="{{$result->name}}" class="img-circle" width="80px">
                                            @endif 
                                            </a>
                                        </div>
                                        <div class="mt-comment-body">
                                            <div class="mt-comment-info"> 
                                                <a href="{{url('company/profile')}}/{{$result->id}}" target="_blank">
                                                <span class="mt-comment-author font-20">{{$result->name}}</span>
                                                </a>
                                                <div class="actions pull-right">
                                                    <div class="btn-group"> <a class="btn btn-circle btn_yellow hvr-bounce-to-right" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> Actions <i class="fa fa-angle-down"></i> </a>
                                                        <ul class="dropdown-menu pull-right">
                                                            <li>
                                                                <a href="{{url('company/profile')}}/{{$result->id}}" target="_blank">
                                                                    <i class="icon-docs"></i> View Profile </a>
                                                            </li>
                                                            <li>
                                                                <a href="{{url('messages/create')}}?buyer={{$result->user_id}}" target="_blank">
                                                                    <i class="fa fa-envelope-o"></i> Message Admin </a>
                                                            </li>
                                                            <li>
                                                                <a href="{{url('endorse-user')}}/{{Auth::user()->id}}/{{$result->user_id}}">
                                                                    <i class="fa fa-thumbs-up"></i> Endorse </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mt-comment-author">
                                                 @if($result->industries)
                                                    @foreach($result->industries as $index=>$indurty)
                                                        @if($index == 0)
                                                        {{$indurty->Industry->name}}
                                                        @else
                                                        ,{{$indurty->Industry->name}}
                                                        @endif
                                                    @endforeach
                                                @endif
                                            </span>
                                            <div class="mt-comment-text"> {{substr($result->description,0,90)}} </div>
                                            <span class="mt-comment-status">@if($result->city != ''){{$result->city}},{{$result->state}},{{$result->country}} @endif</span> 
                                        </div>
                                    </div>
                                    </div>
                                    @elseif($result->search_type == 'product')
                                    <div class="mt-comments col-md-9 col-sm-12 center-block no_filter all_product">
                                    <div class="mt-comment result">
                                        <div class="mt-comment-img"> 
                                            <a href="{{url('marketplaceproducts')}}/{{$result->id}}" target="_blank">
                                            @if($result->image != '')
                                            <img src="{{url('public/marketplace/product/images')}}/{{$result->image}}" alt="{{$result->name}}" class="img-circle" >
                                            @else
                                            <img src="//www.gravatar.com/avatar/18051c749493cc76ad88dd94789cc74e?s=64" alt="{{$result->name}}" class="img-circle" >
                                            @endif 
                                            </a>
                                        </div>
                                        <div class="mt-comment-body">
                                            <div class="mt-comment-info"> 
                                                <a href="{{url('marketplaceproducts')}}/{{$result->id}}" target="_blank">
                                                <span class="mt-comment-author font-20">{{$result->name}}</span>
                                                </a>
                                                <div class="actions pull-right">
                                                    <div class="btn-group"> <a class="btn btn-circle btn_yellow hvr-bounce-to-right" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> Actions <i class="fa fa-angle-down"></i> </a>
                                                        <ul class="dropdown-menu pull-right">
                                                            <li>
                                                                <a href="{{url('marketplaceproducts')}}/{{$result->id}}" target="_blank">
                                                                    <i class="icon-docs"></i> View Listing </a>
                                                            </li>
                                                            <li>
                                                                <a href="{{url('home/user/profile')}}/{{$result->seller->id}}" target="_blank">
                                                                    <i class="icon-docs"></i> View Seller Profile </a>
                                                            </li>
                                                            <li>
                                                                <a href="{{url('messages/create')}}?buyer={{$result->seller->id}}&product={{$result->id}}" target="_blank">
                                                                    <i class="icon-docs"></i> Enquire </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mt-comment-author"><a href="#">${{$result->price}}</a> {{$result->brand_name}} | {{$result->model_number}}  | 
                                                @foreach($result->categories as $index=>$category)
                                                    @if($index < 3)
                                                        @if($index == 0)
                                                        {{$category->category->name}}
                                                        @else
                                                        ,{{$category->category->name}}
                                                        @endif
                                                    @endif
                                                @endforeach
                                             </span>
                                            <div class="mt-comment-text"> Listed by : <a href="{{url('home/user/profile')}}/{{$result->seller->id}}" class="font18" target="_blank">{{$result->seller->userdetail->first_name}} {{$result->seller->userdetail->last_name}}</a> 
                                                @if($result->star == 'gold')
                                                <span class="label label-sm label-warning gold-member caps-on"> Gold Member </span> 
                                                @elseif($result->star == 'silver')
                                                <span class="label label-sm label-default silver-member caps-on"> Silver Member </span> 
                                                @else
                                                <span class="label label-sm label-default free-member caps-on"> Free Member </span>
                                                @endif
                                                @if($result->seller->quotetek_verify == 1)
                                                <span class="label label-sm label-default verify-member caps-on"> Verified </span>
                                                @else
                                                <span class="label label-sm label-default verify-member caps-on"> Not Verified </span>
                                                @endif
                                            </div>
                                            <span class="mt-comment-status">@if($result->seller->userdetail->city != ''){{$result->seller->userdetail->city}}, {{$result->seller->userdetail->state}}, {{$result->seller->userdetail->country}} @endif  @if($result->seller->userdetail->getUserIndustry)| {{$result->seller->userdetail->getUserIndustry->name}}@endif</span> 
                                        </div>
                                    </div>
                                    </div>
                                    @elseif($result->search_type == 'job')
                                    <div class="mt-comments col-md-9 col-sm-12 center-block no_filter all_job">
                                        <div class="mt-comment result">
                                            <div class="mt-comment-img"> 
                                                <a href="{{url('home/user/profile')}}/{{$result->user->id}}" target="_blank">
                                                @if($result->user->userdetail->profile_picture != '')
                                                <img src="{{url('')}}/{{$result->user->userdetail->profile_picture}}" alt="{{$result->user->userdetail->first_name}} {{$result->user->userdetail->last_name}}" class="img-circle">
                                                @else
                                                <img src="{{url('public/images/default-user.png')}}" alt="{{$result->user->userdetail->first_name}} {{$result->user->userdetail->last_name}}" class="img-circle" width="80px">
                                                @endif
                                                </a>
                                            </div>
                                            <div class="mt-comment-body">
                                                <div class="mt-comment-info"> 
                                                    <a href="{{url('job/view')}}/{{$result->id}}" target="_blank">
                                                    <span class="mt-comment-author font-20">{{$result->title}}</span>
                                                    </a>
                                                    <div class="actions pull-right">
                                                        <div class="btn-group"> <a class="btn btn-circle btn_yellow hvr-bounce-to-right" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> Actions <i class="fa fa-angle-down"></i> </a>
                                                            <ul class="dropdown-menu pull-right">
                                                                <li>
                                                                    <a href="{{url('job/view')}}/{{$result->id}}" target="_blank">
                                                                        <i class="icon-docs"></i> View Listing </a>
                                                                </li>
                                                                @if($result->user_id != Auth::user()->id)
                                                                <li>
                                                                    <a href="{{url('job/user/save')}}/{{$result->id}}/{{Auth::user()->id}}">
                                                                        <i class="icon-check"></i> Save </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#job_apply" data-toggle="modal" data-target="#job_apply" onclick="ApplyJobModal({{$result->id}})">
                                                                        <i class="icon-check"></i> Apply
                                                                    </a>
                                                                    <!--<a href="{{url('job/user/apply')}}/{{$result->id}}/{{Auth::user()->id}}">
                                                                        <i class="icon-check"></i> Apply </a>-->
                                                                </li>
                                                                @endif
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mt-comment-author">
                                                    {{$result->job_type_function}} | {{$result->job_position_title}}  | {{$result->job_type}}
                                                </div>
                                                <div class="mt-comment-status">@if($result->city != ''){{$result->city}}, {{$result->state}}, {{$result->country}} @endif  </div>
                                            </div>
                                        </div>
                                        </div>
                                    @endif
                                
                            @endforeach
                        @else
                            <div class="mt-comments col-md-9 col-sm-12 center-block float_none">
                            <div class="row">
                                <p class="text-right res_found">No Results found for your search.</p>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
            <div class="col-md-12 align-center">
                {!! $results->render() !!}
            </div>
            @else
                <p>Nothing to search</p>
            @endif
        </div>
        
              
    </div>
</div>
</div>
<script>
    /* for show menu active */
    $("#dashboard-menu").addClass("active");
	/* end menu active */
    
</script>
@endsection
