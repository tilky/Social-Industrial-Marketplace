@extends('buyer.app')

@section('content')
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url('user-dashboard')}}">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>Feedbacks Received</span>
        </li>
    </ul>
</div>

<div class="row">
    <div class="col-md-12">
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
        <div class="portlet box yellow-crusta">
            <div class="portlet-title">
                <div class="caption color-black">
                    <i class="fa fa-server color-black"></i>Manage Received Feedbacks </div>
            </div>
            <div class="portlet-body">
            
                @if (Session::has('message'))
                    <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
                @endif
                <div class="row">
                    <div class="col-md-12">
                        @if(count($feedbacks) > 0)
                            @foreach($feedbacks as $feedback)
                            <div class="media">
                                <a class="pull-left" href="#">
                                    <img src="{{url('public/images/default-user.png')}}" alt="sell" class="img-circle" width="80px">
                                </a>
                                <div class="media-body">
                                    <div class="col-md-12 paddin-npt">
                                        <div class="col-md-8 paddin-npt">
                                            <h3 class="media-heading">{{$feedback->sendername}}</h3>
                                            @if($feedback->companyname != '')<span>Position at {{$feedback->companyname}}</span>@endif
                                            <p>{{$feedback->comment}}</p>
                                        </div>
                                        <div class="text-muted col-md-4 align-right paddin-npt"><small>Feedback received {!! $feedback->created_at->diffForHumans() !!}</small></div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        @else
                        <p>No Feedback available</p>
                        @endif
                    </div>
                </div>
                <ul class="pager">
                    @if($previousPageUrl != '')
                    <li class="previous">
                        <a href="{{$previousPageUrl}}"> ? Prev </a>
                    </li>
                    @endif
                    @if($nextPageUrl != '')
                    <li class="next">
                        <a href="{{$nextPageUrl}}"> Next ? </a>
                    </li>
                    @endif
                </ul>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>

@endsection
