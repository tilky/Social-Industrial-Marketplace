@extends('home.app')
@section('content')
@include('home.header')

<div class=" padding75">


    <div class="helpsection fade margintop20">
        <h1>404 Page not found</h1>
        <div class="clearfix"></div>

    </div>
</div>


@include('home.footerlinks')
@endsection
