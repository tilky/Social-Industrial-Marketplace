@extends('home.app')
@section('content')
@include('home.header')
<div class="banner_content animatedParent ">
  <div class="container">
    <h1 class="banner_header animated bounceInDown slower">Welcome TO <span>Indy John</span></h1>
      <h2 class="h5_head  animated bounceInUp slower">A Social Marketplace for the <span>Industrial World</span>.</h2>

    <h3 class="h3_head  animated bounceInUp slower text-uppercase nomargin-bottom margintop60"><b>As a Supplier, you can : </b></h3>
    <div class="button_section">
      <ul class="clearfix animated bounceInUp findMe">
        <li><a href="" class="btn btn-circle " data-toggle="popover" data-placement="top" data-trigger="focus" data-content="We'll get you the leads, so you can focus on closing the sales.">Receive Product Leads</a></li>
        <li><a href="" class="btn" data-toggle="popover" data-placement="top" data-trigger="focus" data-content="We can help you meet and quote new buyers, sign up to learn more.">Meet New Buyers</a></li>
        <li><a href="" class="btn" data-toggle="popover" data-placement="top" data-trigger="focus" data-content="Indy John Market was built for Industrial products and supplies, start showcasing now.">List Your Products</a></li>
        <li><a href="" class="btn" data-toggle="popover" data-placement="top" data-trigger="focus" data-content=" Be discovered by potential customers, start by claiming your Indy John profile.">Claim Your Profile</a></li>
      </ul>
      <div class="clearfix"></div>
      <!-- signup- form -->
      <div class="signup-form">
        <h3 class="h3_head  animated bounceInUp slower nomargin-bottom margintop60"><b> SIGN UP FOR FREE </b></h3>
        @if(count($errors) > 0)
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                &times;
            </button>
            @foreach ($errors->all() as $error)
            {{ $error }}
            @endforeach
        </div>
        @endif
        <div class="form_div">
        <form method="post" action="{{url('signup/email/verification')}}">
            <input type="hidden" name="_token" value="{{csrf_token()}}" />
            @if(isset($_GET['referral']))
            <input type="hidden" name="referral_singup" value="{{$_GET['referral']}}" />
            @endif
          <div class="form">
            <div class="form-inline ">
              <div class="form-group col-md-12 col-sm-12 col-xs-12">
              <div class="row">
                    <input type="hidden" name="user_type" id="home-user-type" value="3" />
                    <input type="email" class="form-control" id="home-email" name="email" value="{{Request::old('email')}}" placeholder="Enter your E-mail address" required>
                </div>
              </div>
              <div class="form-group btn_signup text-center col-md-2 col-sm-2 col-xs-12">
              <div class="row">
                @if(Auth::check())
                    @if(Auth::user()->access_level == 1)
                        <a href="{{url('sa')}}" class="btn">Sign Up</a>
                    @else
                        <a href="{{url('user-dashboard')}}" class="btn">Sign Up</a>
                    @endif
                @else
                    <!--<button type="button" onclick="ShowRegisterModal()" data-toggle="modal" data-target="#signup" class="btn">Sign Up</button>-->
                    <button type="submit"  class="btn">Sign Up</button>
                @endif
                
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
          </div>
        </form>
        </div>
        <h6>By Signing Up, You Agree To Our <a href="terms">Terms & Conditions</a> & <a href="privacy-policy">Privacy Policy</a>.</h6>
      </div>
      <div class="text-center clearfix margintop60 service_provider  animated growIn slowest"> <a href="{{url('/')}}@if(isset($_GET['referral']))?referral={{$_GET['referral']}}@endif" class="btn_blue">I'm a Buyer</a> </div>
    </div>
    <div class="text-center mobile_margin">
      <div class="scrollar_btn"><span class="circle"><span class="dot"></span></span>
        <p>Learn More</p>
      </div>
    </div>
  </div>
</div>
<div id="owl-demo" class="owl-carousel paddingTop150">
  <div class="item">
    <div class="slider" style="background-image: url({{URL::asset('public/livesite/images/banner_5.jpg')}})">
      <div class="slider_overlay"> </div>
      <div class="line_image"></div>
      <div class="line_image right"></div>
    </div>
  </div>
  <!--
  <div class="item">
    <div class="slider" style="background-image: url({{URL::asset('public/livesite/images/banner_4.jpg')}})">
      <div class="slider_overlay"> </div>
      <div class="line_image"></div>
      <div class="line_image right"></div>
    </div>
  </div>
  -->
</div>
<div class="section fade animatedParent">
  <div class="container  text-center">
    <h1 class="header_middle">Make Indy John the quarterback of your Sales team.</h1>
    <div class="col-md-4 iconsection  animated bounceInDown "> <i class="icon"><img src="{{URL::asset('public/livesite/images/icons/interface-1.png')}}"/></i>
      <h3 class="header_18">Quote-Lead System</h3>
      <p>Create product lead request and we'll bring the leads to you.</p>
    </div>
    <div class="col-md-4 iconsection animated bounceInUp "> <i class="icon"><img src="{{URL::asset('public/livesite/images/icons/interface.png')}}"/></i>
      <h3 class="header_18">Indy John Market</h3>
      <p>List or shop for new and used industrial products and supplies.</p>
    </div>
    <div class="col-md-4 iconsection animated bounceInDown "> <i class="icon"><img src="{{URL::asset('public/livesite/images/safty.png')}}"/></i>
      <h3 class="header_18">Supplier CRM</h3>
      <p>Organize your leads and manage all sales activity in one dashboard.</p>
    </div>
 
  </div>
</div>


<div class="color_bg feedback animatedParent paddingTop50"> </div>
<div class="container animatedParent">
  <h3 class="header_middle text-center  animated fadeIn nopadding">How does the Quote-Lead System work?</h3>
  <div class="row redprocess section">
    <div class="leftright_section">
      <div class="col-md-9 col-sm-9 wh_border wh_borderright"><i class="lefticon"><img src="{{URL::asset('public/livesite/images/icons/promotion.png')}}" alt=""/></i>Allow Indy John to help you sell, promote, and advertise your products and services.</div>
      <div class="number_text left_icon hovicon effect-1 animation-element slide-left">1</div>
    </div>
    <div class="clearfix"></div>
    <div class="leftright_section pull-right border_middle_ver">
      <div class="number_text right_icon hovicon animation-element slide-right">2</div>
      <div class="col-md-9 col-sm-9 wh_border wh_borderleft"><i class="lefticon"><img src="{{URL::asset('public/livesite/images/icons/magnifying-glass.png')}}"  alt=""/></i> Begin by searching your product offering and creating Product Lead requests.</div>
    </div>
    <div class="clearfix"></div>
    <div class="leftright_section">
      <div class="col-md-9 col-sm-9 wh_border wh_borderright"><i class="lefticon"><img src="{{URL::asset('public/livesite/images/icons/handshake.png')}}" alt=""/></i>We'll match and introduce you to new industrial buyers and procurement departments.</div>
      <div class="number_text left_icon hovicon animation-element slide-left">3</div>
    </div>
  </div>
</div>
<div class="clearfix"></div>
<div class="color_bg feedback animatedParent padding100">
  <div class="container">
    <button type="button" class="btn_red  hvr-bounce-to-right head_railway  text-center animated shake slower scrolltotop">Network smarter, earn more, one CRM.</button>
  </div>
</div>
<a href="#job_board" data-toggle="modal" data-target="#job_board" class="job_board">JOB BOARD</a>
<a href="{{url('quick-demo')}}?setup=tutorial" class="quick_demo">QUICK DEMO</a>
@include('home.footerlinks')
@endsection
