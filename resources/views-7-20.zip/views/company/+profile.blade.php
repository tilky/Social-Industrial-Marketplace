@extends('buyer.app')

@section('content')
    <style>
        .content-img{width: 97%!important;}
        .owl-item{padding: 0px 10px!important;}
        .test_descri{font-size: 18px;}
        .thumbnail{position: relative;}
        .white_carasoul .owl-pagination{margin-top: 20px!important;}
        .section {padding: 0px !important;}
    </style>
    <link href="{{URL::asset('public/metronic/pages/css/profile.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{URL::asset('public/metronic/pages/css/invoice-2.min.css')}}" rel="stylesheet" type="text/css" />

    <link href="{{URL::asset('public/css/style_custom.css')}}" rel="stylesheet">
    <link href="{{URL::asset('public/js/owl-carousel/owl.carousel.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{URL::asset('public/css/animations.css')}}" type="text/css">
    <link rel="stylesheet" href="{{URL::asset('public/css/prettyPhoto.css')}}">

    <link rel="stylesheet" href="{{URL::asset('public/css/owl.theme.css')}}">
    <link rel="stylesheet" type="text/css" href="{{URL::asset('public/css/ng_responsive_tables.css')}}">
    <style>
        .invoice-content-2 {
            border-radius: 5px;
            margin: 10px;
            padding: 0 !important;
        }
        .list-inline>li{padding: 0px!important;}
        .padding-right-20{padding-right: 20px!important;}
        .btn_org-silver {
            background: #c0c0c0 none repeat scroll 0 0;
            border: 2px solid transparent;
            border-radius: 10px;
            box-shadow: 0 0 1px rgba(0, 0, 0, 0);
            display: inline-block;
            font-family: "Raleway",sans-serif;
            font-size: 20px;
            font-weight: 500;
            overflow: hidden;
            padding: 5px 30px;
            position: relative;
            text-transform: uppercase;
            transform: translateZ(0px);
            transition: all 0.3s ease-in 0s;
            width: 100%;
            margin-top: 5px;
            color: #000!important;
        }
    </style>
    <div class="page-bar">
        <ul class="page-breadcrumb">
            <li>
                <a href="{{url('user-dashboard')}}">Home</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <span>User</span>
            </li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12 paddin-npt">
            @if (Session::has('message'))
                <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
                @endif
                        <!-- BEGIN PROFILE CONTENT -->
                <div class="invoice-content-2 bordered">
                    <div class="section fade">
                        <div class="profile-inner-section">
                            <div class="col-md-3 text-center profile_info">

                                <div class="stopMenu" id="stopMenu">
                                    <div class="relative">
                            <span class="verified-text pull-left"><a class="btn btn-circle btn-icon-only light-green" href="javascript:;">
                                    <i class="fa fa fa-check"></i>
                                </a>
                            Verified
                            </span>


                                        <a class="btn btn-circle btn-icon-only bordered pull-right" href="javascript:;">
                                            <i class="fa fa-save"></i>
                                        </a>
                                        <div class="profile" style="margin-top: 0px!important;">

                                           {{-- @if($user->userdetail->profile_picture != '')
                                                <img src="{{url('')}}/{{$user->userdetail->profile_picture}}">
                                            @else--}}
                                                <img src="//www.gravatar.com/avatar/18051c749493cc76ad88dd94789cc74e?s=64">
                                           {{-- @endif
                                            @if($user->quotetek_verify == 1)<div class="check"><img src="{{URL::asset('public/images/check.png')}}"/></div>@endif
                                        --}}</div>
                                        <div class="profile_name">Markus Lane Thomas</div>
                                        <div class="position">Position</div>
                                        <div class="company_name">Company Name</div>
                                        <div class="membership">
                                            <a class="btn yellow-crusta color-black btn-circle font-yellow-crusta" href="#">Gold Member</a>
                                        </div>

                                    </div>
                                    <div class="todo-tasklist">
                                        <div class="todo-tasklist-item todo-tasklist-item-border-green">
                                            <a href="#"><i class="fa fa-home pull-left"></i>
                                                <div class="todo-tasklist-item-title"> CONNECT </div></a>
                                        </div>

                                        <div class="todo-tasklist-item todo-tasklist-item-border-green">
                                            <a href="#"> <i class="fa fa-cog  pull-left"></i>
                                                <div class="todo-tasklist-item-title"> Message </div></a>
                                        </div>

                                        <div class="todo-tasklist-item todo-tasklist-item-border-green">
                                            <a href="#"> <i class="fa fa-info-circle pull-left"></i>
                                                <div class="todo-tasklist-item-title"> Share Profile </div></a>
                                        </div>

                                        <div class="todo-tasklist-item todo-tasklist-item-border-green">
                                            <a href="#"> <i class="fa fa-info-circle pull-left"></i>
                                                <div class="todo-tasklist-item-title"> Endorse </div></a>
                                        </div>

                                        <div class="todo-tasklist-item todo-tasklist-item-border-green">
                                            <a href="#"><i class="fa fa-skype pull-left"></i>
                                                <div class="todo-tasklist-item-title"> Video Call </div></a>
                                        </div>
                                    </div>
                                    <div class="profile_social_link">
                                        <div class="btn-group btn-group-solid">
                                            <button class="btn blue" type="button">
                                                <i class="fa fa-facebook"></i></button>
                                            <button class="btn navy-blue" type="button">
                                                <i class="fa fa-twitter"></i></button>
                                            <button class="btn light-grey" type="button">
                                                <i class="fa fa-linkedin "></i></button>
                                            <button class="btn orange" type="button">
                                                <i class="fa fa-youtube"></i></button>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-9 profile_details">
                                <div class="profile_details_inner">
                                    <!-- Nav tabs -->

                                    <div class="profile-details-block aboutme">

                                        <h3>About Markus<span class="pull-right">User ID: IJU-135253</span></h3>
                                        <div class="profile-block col-md-12">
                                            <h4>This is my Profile Slogan. This is my Profile Slogan. I am the best.</h4>
                                            <p>I am a hard working person who works hard and will be successful. Connect with me and
                                                we will do business together. And get to great new heights. I am a hard working person
                                                who works hard and will be successful. Connect with me and we will do business together.
                                                Connect with me and we will do business together. </p>

                                            <div class="mt-element-list">

                                                <div class="mt-list-container list-simple">
                                                    <ul>
                                                        <li class="mt-list-item">
                                                            <i class="fa fa-circle"></i>
                                                            <span class="list-content">Los Angeles,CA,United States</span>
                                                        </li>

                                                        <li class="mt-list-item">
                                                            <i class="fa fa-circle"></i>
                                                            <span class="list-content">Bachelors In Business administration,IIT Mumbai (2016)</span>
                                                        </li>

                                                        <li class="mt-list-item">
                                                            <i class="fa fa-circle"></i>
                                                    <span class="list-content">
                                                        <strong>Markus has Expertise in:</strong>

                                                    </span>
                                                            <div class="expertise">
                                                                <a class="btn dark btn-outline btn-circle btn-sm" href="javascript:;"><span class="badge badge-default">  </span> Testing Multimeters</a>
                                                                <a class="btn btn-circle dark btn-outline btn-sm" href="javascript:;"><span class="badge badge-default">  </span> Testing Multimeters</a>
                                                                <a class="btn btn-circle dark btn-outline btn-sm" href="javascript:;"><span class="badge badge-default">  </span> Testing Multimeters</a>
                                                                <a class="btn btn-circle dark btn-outline btn-sm" href="javascript:;"><span class="badge badge-default">  </span> Testing Multimeters</a>
                                                                <a class="btn btn-circle dark btn-outline btn-sm" href="javascript:;"><span class="badge badge-default">  </span> Testing Multimeters</a>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="btn-group btn-group btn-group-justified statistics-button">
                                                <a class="btn dark" href="javascript:;"> 445 Connections </a>
                                                <a class="btn dark" href="javascript:;"> 45 reviews </a>
                                                <a class="btn dark" href="javascript:;"> 44 Endorsements </a>
                                            </div>
                                            {{--<div class="statistics-bar">
                                                <ul>
                                                    <li>445 Connections</li>
                                                    <li>45 reviews</li>
                                                    <li>44 Endorsements</li>
                                                </ul>
                                            </div>--}}
                                        </div>

                                    </div>


                                    <div class="profile-details-block photo-showcase">
                                        <div class="cd-horizontal-timeline mt-timeline-horizontal loaded">
                                            <div class="timeline">
                                                <div class="events-wrapper">
                                                    <div class="events" style="width: 1800px; transform: translateX(-942px);">
                                                        <ol>
                                                            <li>
                                                                <a class="border-after-red bg-after-red selected" data-date="16/01/2014" href="#0" style="left: 120px;">16 Jan</a>
                                                            </li>
                                                            <li>
                                                                <a class="border-after-red bg-after-red" data-date="28/02/2014" href="#0" style="left: 300px;">28 Feb</a>
                                                            </li>
                                                            <li>
                                                                <a class="border-after-red bg-after-red" data-date="20/04/2014" href="#0" style="left: 480px;">20 Mar</a>
                                                            </li>
                                                            <li>
                                                                <a class="border-after-red bg-after-red" data-date="20/05/2014" href="#0" style="left: 600px;">20 May</a>
                                                            </li>
                                                            <li>
                                                                <a class="border-after-red bg-after-red" data-date="09/07/2014" href="#0" style="left: 780px;">09 Jul</a>
                                                            </li>
                                                            <li>
                                                                <a class="border-after-red bg-after-red" data-date="30/08/2014" href="#0" style="left: 960px;">30 Aug</a>
                                                            </li>
                                                            <li>
                                                                <a class="border-after-red bg-after-red" data-date="15/09/2014" href="#0" style="left: 1020px;">15 Sep</a>
                                                            </li>
                                                            <li>
                                                                <a class="border-after-red bg-after-red" data-date="01/11/2014" href="#0" style="left: 1200px;">01 Nov</a>
                                                            </li>
                                                            <li>
                                                                <a class="border-after-red bg-after-red" data-date="10/12/2014" href="#0" style="left: 1380px;">10 Dec</a>
                                                            </li>
                                                            <li>
                                                                <a class="border-after-red bg-after-red" data-date="19/01/2015" href="#0" style="left: 1500px;">29 Jan</a>
                                                            </li>
                                                            <li>
                                                                <a class="border-after-red bg-after-red" data-date="03/03/2015" href="#0" style="left: 1680px;">3 Mar</a>
                                                            </li>
                                                        </ol>
                                                        <span aria-hidden="true" class="filling-line bg-red" style="transform: scaleX(0.0769259);"></span>
                                                    </div>
                                                    <!-- .events -->
                                                </div>
                                                <!-- .events-wrapper -->
                                                <ul class="cd-timeline-navigation mt-ht-nav-icon">
                                                    <li>
                                                        <a class="prev btn btn-outline red md-skip" href="#0">
                                                            <i class="fa fa-chevron-left"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="next btn btn-outline red md-skip" href="#0">
                                                            <i class="fa fa-chevron-right"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                                <!-- .cd-timeline-navigation -->
                                            </div>
                                            <!-- .timeline -->

                                        </div>
                                    </div>

                                    <div class="profile-details-block products">

                                        <h3>PRODUCTS & CATEGORIES ASSOCIATION</h3>

                                        <div class="col-md-6 products-left">
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                        </div>
                                        <div class="col-md-6 products-right">
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                            APPLICABLE PRODUCTS & CATEGORIES<br/>
                                        </div>

                                    </div>

                                    <div class="profile-details-block employment-history">

                                        <h3>EMPLOYMENT HISTORY</h3>

                                        <div class="single-employment first">
                                            <div class="col-md-6 employment-left"><span>POSITION, <strong>COMPANY NAME</strong></span><br/><span>Location</span></div>
                                            <div class="col-md-6 employment-right">DATE FROM - DATE TO</div>
                                        </div>

                                        <div class="single-employment">
                                            <div class="col-md-6 employment-left"><span>POSITION, <strong>COMPANY NAME</strong></span><br/><span>Location</span></div>
                                            <div class="col-md-6 employment-right">DATE FROM - DATE TO</div>
                                        </div>

                                        <div class="single-employment">
                                            <div class="col-md-6 employment-left"><span>POSITION, <strong>COMPANY NAME</strong></span><br/><span>Location</span></div>
                                            <div class="col-md-6 employment-right">DATE FROM - DATE TO</div>
                                        </div>

                                    </div>

                                    <div class="profile-details-block connection">

                                        <h3>MARCUS’ CONNECTIONS</h3>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="portlet light portlet-fit">

                                                    <div class="connection-body">
                                                        <div class="mt-element-card mt-card-round mt-element-overlay">
                                                            <div class="row">
                                                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                                    <div class="mt-card-item">
                                                                        <div class="mt-card-avatar mt-overlay-1">
                                                                            <img src="http://cryptdata.com/qt/public/profile/picture/Rajesh_46246.png">
                                                                            <div class="mt-overlay">
                                                                                <ul class="mt-info">
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-magnifier"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-link"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mt-card-content">
                                                                            <h3 class="mt-card-name">Jennifer Lawrence</h3>
                                                                            <span class="mt-card-desc font-grey-mint">Creative Director</span>
                                                                            <span class="mt-card-desc company-title">Company Name</span>
                                                                            {{--<div class="mt-card-social">
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-facebook"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-twitter"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-dribbble"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>--}}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                                    <div class="mt-card-item">
                                                                        <div class="mt-card-avatar mt-overlay-1 mt-scroll-down">
                                                                            <img src="http://cryptdata.com/qt/public/profile/picture/Rajesh_46246.png">
                                                                            <div class="mt-overlay mt-top">
                                                                                <ul class="mt-info">
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-magnifier"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-link"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mt-card-content">
                                                                            <h3 class="mt-card-name">Kate Beck</h3>
                                                                            <span class="mt-card-desc font-grey-mint">Creative Director</span>
                                                                            <span class="mt-card-desc company-title">Company Name</span>
                                                                            {{--<div class="mt-card-social">
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-facebook"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-twitter"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-dribbble"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>--}}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                                    <div class="mt-card-item">
                                                                        <div class="mt-card-avatar mt-overlay-1 mt-scroll-up">
                                                                            <img src="http://cryptdata.com/qt/public/profile/picture/Rajesh_46246.png">
                                                                            <div class="mt-overlay">
                                                                                <ul class="mt-info">
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-magnifier"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-link"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mt-card-content">
                                                                            <h3 class="mt-card-name">Hugh Jackman</h3>
                                                                            <span class="mt-card-desc font-grey-mint">Creative Director</span>
                                                                            <span class="mt-card-desc company-title">Company Name</span>
                                                                            {{--<div class="mt-card-social">
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-facebook"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-twitter"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-dribbble"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>--}}
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <div class="row">
                                                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                                    <div class="mt-card-item">
                                                                        <div class="mt-card-avatar mt-overlay-1">
                                                                            <img src="http://cryptdata.com/qt/public/profile/picture/Rajesh_46246.png">
                                                                            <div class="mt-overlay">
                                                                                <ul class="mt-info">
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-magnifier"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-link"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mt-card-content">
                                                                            <h3 class="mt-card-name">Jennifer Lawrence</h3>
                                                                            <span class="mt-card-desc font-grey-mint">Creative Director</span>
                                                                            <span class="mt-card-desc company-title">Company Name</span>
                                                                            {{--<div class="mt-card-social">
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-facebook"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-twitter"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-dribbble"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>--}}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                                    <div class="mt-card-item">
                                                                        <div class="mt-card-avatar mt-overlay-1 mt-scroll-down">
                                                                            <img src="http://cryptdata.com/qt/public/profile/picture/Rajesh_46246.png">
                                                                            <div class="mt-overlay mt-top">
                                                                                <ul class="mt-info">
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-magnifier"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-link"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mt-card-content">
                                                                            <h3 class="mt-card-name">Kate Beck</h3>
                                                                            <span class="mt-card-desc font-grey-mint">Creative Director</span>
                                                                            <span class="mt-card-desc company-title">Company Name</span>
                                                                            {{--<div class="mt-card-social">
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-facebook"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-twitter"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-dribbble"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>--}}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                                    <div class="mt-card-item">
                                                                        <div class="mt-card-avatar mt-overlay-1 mt-scroll-up">
                                                                            <img src="http://cryptdata.com/qt/public/profile/picture/Rajesh_46246.png">
                                                                            <div class="mt-overlay">
                                                                                <ul class="mt-info">
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-magnifier"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;" class="btn default btn-outline">
                                                                                            <i class="icon-link"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mt-card-content">
                                                                            <h3 class="mt-card-name">Hugh Jackman</h3>
                                                                            <span class="mt-card-desc font-grey-mint">Creative Director</span>
                                                                            <span class="mt-card-desc company-title">Company Name</span>
                                                                            {{--<div class="mt-card-social">
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-facebook"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-twitter"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="javascript:;">
                                                                                            <i class="icon-social-dribbble"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>--}}
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="pagination-block">
                                                        <ul>
                                                            <li> < </li>
                                                            <li>6 of 235</li>
                                                            <li> > </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>


                </div>
                <!-- END PROFILE CONTENT -->
        </div>
    </div>
    <script>
        $('#user-profile-view').addClass('active');
    </script>
    <!-- Bootstrap core JavaScript
        ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->


    <script src="{{URL::asset('public/js/bootstrap.min.js')}}"></script>

    <script type="text/javascript" src="{{URL::asset('public/js/owl-carousel/owl.carousel.js')}}"></script>
    <script type="text/javascript" src="{{URL::asset('public/js/animate.js')}}"></script>
    <script type="text/javascript" src="{{URL::asset('public/js/ng_responsive_tables.js')}}"></script>

    <script>
        $(document).ready(function() {
            $("#owl-demo").owlCarousel({
                items : 3,
                navigation : false,
                slideSpeed : 300,
                paginationSpeed : 500,
                singleItem : true,
                autoPlay : true,
                pagination : false,
            });


            $("#testimonial").owlCarousel({
                navigation : true, // Show next and prev buttons
                pagination : false,
                slideSpeed : 300,
                paginationSpeed : 400,
                singleItem:true,
                navigationText : ["<img src='{{URL::asset('public/images/left_wh.png')}}' alt='' />", "<img src='{{URL::asset('public/images/rt_wh.png')}}' alt='' />"],

            });

            $(".product_demo").owlCarousel({
                navigation : true,
                slideSpeed : 300,
                paginationSpeed : 400,
                singleItem : false,
                pagination : false,
                items : 3,
                itemsDesktop : [1199, 4],
                itemsDesktopSmall : [991, 3],
                itemsTablet : [768, 2],
                itemsMobile : [479, 1],
                navigationText : ["<img src='{{URL::asset('public/images/left_arrow.png')}}' alt='' />", "<img src='{{URL::asset('public/images/right_arrow.png')}}' alt='' />"],

            });

            $(".profileslider").owlCarousel({
                navigation : false,
                pagination : true,
                slideSpeed : 300,
                paginationSpeed : 400,
                singleItem : false,
                items : 4,
                itemsDesktop : [1199, 4],
                itemsDesktopSmall : [991, 3],
                itemsTablet : [768, 2],
                itemsMobile : [479, 1],


            });


            $(".scrollar_btn").click(function(){
                $('html,body').animate({scrollTop: 630 }, 1000);
            });

            $('.scrolltotop').hide();

            $(".scrolltotop").click(function(){
                $('html,body').animate({scrollTop: 0 }, 1000);
            });



            $(window).scroll(function() {
                if ($(window).scrollTop() >= 500 ) {
                    $('.scrolltotop').show('2000');
                } else {
                    $('.scrolltotop').hide('2000');
                }
            });



            $(function loop_charch() {
                $(" .scrollar_btn btn-circle .circle").animate({height:50}, 1000)
                $(" .scrollar_btn btn-circle .circle").animate({height:40}, 1000,loop_charch);

            }); //loop_charch();


        });

        $(window).on("load",function() {
            function fade() {
                var animation_height = $(window).innerHeight() * 0.25;
                var ratio = Math.round( (1 / animation_height) * 10000 ) / 10000;

                $('.fade').each(function() {
                    var objectTop = $(this).offset().top;
                    var windowBottom = $(window).scrollTop() + $(window).innerHeight();

                    if ( objectTop < windowBottom ) {
                        if ( objectTop < windowBottom - animation_height ) {

                            $(this).css( {
                                transition: 'opacity 0.1s linear',
                                opacity: 1
                            } );

                        } else {

                            $(this).css( {
                                transition: 'opacity 0.25s linear',
                                opacity: (windowBottom - objectTop) * ratio
                            } );
                        }
                    }
                });

            }
            $('.fade').css( 'opacity', 0 );
            fade();
            $(window).scroll(function() {fade();});
        });



        $(window).load(function(){
            if($(window).width() < 1600){
                $('.custom_nav').css({"padding-left":"20px",  "padding-right":"20px"});
            }
        });

    </script>

    <script type="text/javascript">
        $(function(){
            $('table.responsive').ngResponsiveTables({
                smallPaddingCharNo: 13,
                mediumPaddingCharNo: 18,
                largePaddingCharNo: 30
            });
        });
    </script>







    <script>



        $(function(){

            var $quote = $(".profile_name");

            var $numWords = $quote.text().split("").length;

            if ($numWords > 15) {
                $quote.css("font-size", "25px");
            }


        });

        $(document).ready(function() {




            $('li.dropdown').hover(function() {
                $('ul.dropdown-menu', this).stop(true, true). fadeIn('fast', 'easeOutElastic');
                $(this).addClass('open');
                $(this).addClass('radius');
            }, function() {
                $('ul.dropdown-menu', this).stop(true, true).fadeOut('fast', 'easeInElastic');
                $(this).removeClass('open');
                $(this).removeClass('radius');
            });

            $('.dropdown-menu').hover(function() {
                $(this).parent('li').stop(true, true).addClass('selectli');

            },function() {
                $(this).parent('li').stop(true, true).removeClass('selectli');
            });
        });



    </script>

    <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script>
        $("#industry").autocomplete({
            source: ["Industry", "Boy", "Cat"],
            minLength: 0,
        }).focus(function () {
            $(this).autocomplete("search");
        });

        $("#catagory").autocomplete({
            source: ["Catgory", "Boy", "Cat"],
            minLength: 0,
        }).focus(function () {
            $(this).autocomplete("search");
        });

        $('.infoeabout').click(function() {
            $('#autocomplete').trigger("focus"); //or "click", at least one should work
        });

        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })

        $(window).scroll(function(){
            if ( $(window).width() > 980 && $(window).scrollTop() > 385 ) {
                extraPadding = $(window).scrollTop() - 65;
                $('#stopMenu').css( "padding-top", extraPadding );
            } else {
                $('#stopMenu').css( "padding-top", "0" );
            }
        });
    </script>
    <script src="{{URL::asset('public/js/jquery.prettyPhoto.js')}}"></script>
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function(){


            $(".gallery:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal', social_tools: false});



        });
    </script>


    <script type="text/javascript">


        $('input').bind('copy paste', function (e) {
            e.preventDefault();
        });

    </script>
@endsection
