@extends('buyer.app')

@section('content')
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url()}}/user-dashboard">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span>Marketplace Products</span>
        </li>
    </ul>
</div>
<div class="col-md-12 main_box">
<div class="row">

<div class="col-md-12 border2x_bottom hide_print">
<div class="col-md-6 col-sm-6">
                <div class="row">
<h3 class="page-title uppercase"> 
 <i class="fa fa-server color-black"></i> Manage Listed Products
</h3>
</div>
</div>
<div class="col-md-6 col-sm-6 text-right">
                <div class="row">
                <div class="actions margin-top-15">
                    <a href="{{ URL::to('marketplaceproducts/create') }}" class="btn btn-circle btn-danger btn-sm">
                        <i class="fa fa-plus"></i> Add a new Product </a>
                </div>
                </div>
                </div>
</div>
</div>

    
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
       
            
            <div class="portlet-body">
                @if (Session::has('message'))
                    <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
                @endif
                <div class="col-md-8 padding-top">
                    <p class="caption-helper">Manage the products that you have listed in the marketplace.</p>
                </div>
                
                <div class="col-md-4 padding-top margin-top-20" style="text-align: right;padding-bottom: 10px;">
                    Sort by: 
                    @if($mp_hidden_val == 'desc')
                    <a href="{{url('marketplaceproducts')}}?mp_order_name=created_at&mp_order_by=asc">@if($mp_hidden_name == 'created_at')<b>Posted Date <i class="fa fa-long-arrow-down"></i></b> @else Posted Date @endif </a> | 
                    <a href="{{url('marketplaceproducts')}}?mp_order_name=condition&mp_order_by=asc">@if($mp_hidden_name == 'condition')<b>Condition <i class="fa fa-long-arrow-down"></i></b> @else Condition @endif </a> | 
                    <a href="{{url('marketplaceproducts')}}?mp_order_name=name&mp_order_by=asc">@if($mp_hidden_name == 'name')<b>Name <i class="fa fa-long-arrow-down"></i></b> @else Name @endif </a>                 
                    @else
                    <a href="{{url('marketplaceproducts')}}?mp_order_name=created_at&mp_order_by=desc">@if($mp_hidden_name == 'created_at')<b>Posted Date <i class="fa fa-long-arrow-up"></i></b> @else Posted Date @endif </a> | 
                    <a href="{{url('marketplaceproducts')}}?mp_order_name=condition&mp_order_by=desc">@if($mp_hidden_name == 'condition')<b>Condition <i class="fa fa-long-arrow-up"></i></b> @else Condition @endif </a> | 
                    <a href="{{url('marketplaceproducts')}}?mp_order_name=name&mp_order_by=desc">@if($mp_hidden_name == 'name')<b>Name <i class="fa fa-long-arrow-up"></i></b> @else Name @endif </a>
                    @endif
                    <!--<div class="col-md-2 font-wh">
                        Sort By: 
                        <select id="received-quote-filter" onchange="ApplyFilter();" class="form-control" style="width: 90%;float: left;">
                            <option value="created_at" selected="selected">Submited Date</option>
                            <option value="expiry_date">Expiry Date</option>
                            <option value="title">Name</option>
                        </select>
                                                    <a href="javascript:void(0)" onclick="ApplyFilter();"><i class="fa fa-long-arrow-down padding-top" style="float: left;padding-left: 5px;"></i></a>
                                            </div>-->
                </div>
                <div class="row">
                    <div class="col-md-12">
                    @foreach ($products as $product)
                    <div class="col-md-12 padding-top paddin-bottom grid-show">
                        <div class="media">
                            <a class="pull-left" href="{{ route('marketplaceproducts.show', $product->id) }}">
                                <img src="{{url('public/marketplace/product/images')}}/{{$product->image}}" alt="{{ $product->name }}" title="{{ $product->name }}" width="80px" />
                            </a>
                            <div class="media-body">
                                <div class="col-md-12 paddin-npt">
                                    <div class="col-md-5">
                                        <h4 style="margin: 0px;">
                                            @if($product->brand_name != ''){{$product->brand_name}} - @endif {{ $product->name }} @if($product->model_number)({{$product->model_number}})@endif</h4>
                                        <br />
                                        <div class="col-md-2 paddin-npt">Categories:</div>
                                        <div class="col-md-10 paddin-npt">
                                        @foreach($product->categories as $index=>$category)
                                            @if($index < 5)
                                                @if($index == 0)
                                                {{$category->category->name}}
                                                @else
                                                ,{{$category->category->name}}
                                                @endif
                                            @endif
                                        @endforeach
                                        </div>
                                        <br />
                                        <span><b>Status: </b>@if($product->is_active == 1)Active @else Inactive @endif</span>
                                    </div>
                                    <div class="col-md-5">
                                        Condition: {{$product->condition}}
                                        <br />
                                        <div class="col-md-2 paddin-npt">industries:</div>
                                        <div class="col-md-10 paddin-npt">
                                        @foreach($product->industries as $index=>$industry)
                                            @if($index < 5)
                                                @if($index == 0)
                                                {{$industry->industry->name}}
                                                @else
                                                ,{{$industry->industry->name}}
                                                @endif
                                            @endif
                                        @endforeach
                                        </div>
                                    </div>
                                    <div class="text-muted col-md-2 align-right paddin-npt"><small>Posted {!! $product->created_at->diffForHumans() !!}</small></div>
                                </div>
                                <div class="col-md-12 align-right paddin-npt padding-top">
                                    <a href="{{ route('marketplaceproducts.show', $product->id) }}" class="btn btn-circle btn-sm red">View</a>
                                    <!--<a href="{{ route('marketplaceproducts.edit', $product->id) }}" class="btn btn-circle btn-sm red">Edit</a>-->
                                    
                                    <!--<a href="" class="btn btn-circle btn-sm red">Share</a>-->
                                    @if($product->is_active == 1)
                                    <a href="{{url('marketplaceproducts/product/inactive')}}/{{$product->id}}" class="btn btn-circle btn-sm red">Inactive</a>
                                    @else
                                    <a href="{{url('marketplaceproducts/product/active')}}/{{$product->id}}" class="btn btn-circle btn-sm red">Active</a>
                                    @endif
                                    <a id="deleteButton" data-id="{{$product->id}}" data-toggle="modal" href="#deleteConfirmation" class="btn btn-circle btn-sm red"> 
                                    {!! Form::open([
                                    'method' => 'DELETE',
                                    'id' => 'DELETE_FORM_'.$product->id,
                                    'route' => ['marketplaceproducts.destroy', $product->id]
                                    ]) !!}
                                    {!! Form::close() !!}
                                        Delete </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    </div>
                </div>
                
                <ul class="pager">
                    @if($previousPageUrl != '')
                    <li class="previous">
                        <a href="{{$previousPageUrl}}"> ← Prev </a>
                    </li>
                    @endif
                    @if($nextPageUrl != '')
                    <li class="next">
                        <a href="{{$nextPageUrl}}"> Next → </a>
                    </li>
                    @endif
                </ul>
            </div>
        
        <!-- END EXAMPLE TABLE PORTLET-->
    

<div class="clearfix"></div>

</div>
<div class="clearfix"></div>
<script>
    /* for show menu active */
    $("#marketplace-main-menu").addClass("active");
	$('#marketplace-main-menu' ).click();
	$('#marketplace-menu-arrow').addClass('open');
	$('#marketplace-view-product-menu').addClass('active');
    /* end menu active */
    $(document).on("click", "#deleteButton", function () {
        var id = $(this).data('id');
        jQuery('#deleteConfirmation .modal-body #objectId').val( id );
    });

    jQuery('#deleteConfirmation .modal-footer button').on('click', function (e) {
        var $target = $(e.target); // Clicked button element
        $(this).closest('.modal').on('hidden.bs.modal', function () {
            if($target[0].id == 'confirmDelete'){
                $( "#DELETE_FORM_" + jQuery('#deleteConfirmation .modal-body #objectId').val() ).submit();
            }
        });
    });
</script>
@endsection
