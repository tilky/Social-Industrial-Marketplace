@extends('admin.app')

@section('content')

<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title">Import Companies</h3>
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <i class="fa fa-dashboard"></i><a href="{{URL::to('/')}}">Dashboard</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <a href="javascript:void(0);">Import Companies</a>
                </li>
            </ul>
        </div>
        <div class="row formbtn-panel">
            <!-- BEGIN FORM-->
            {!! Form::open([
            'url'=>'importCompanies',
            'class' => 'form-horizontal',
            'id' => 'fileupload',
            'enctype' => 'multipart/form-data',
            'files' => 'true'
            ]) !!}

            <div class="form-group">

                <div class="col-md-4">
                    <input type="file" name="file" class="filestyle" data-buttonName="btn-warning" required="" data-buttonBefore="true">
                </div>


                <div class="col-md-8">
                    <button type="submit" name="submit" class="btn btn-success">
                        <span class="glyphicon glyphicon-send"></span> Submit
                    </button>
                </div>
            </div>
            {!! Form::close() !!}
        </div>
    </div>
</div>

@endsection
