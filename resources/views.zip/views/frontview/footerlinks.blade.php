<div class="footer">
<div class="container spacingfooter">
<div class="footercol">
<h3 class="wh_hedaer">Buyers</h3>
<ul>
<li><a href="">Get Quotes </a></li>
<li><a href="">MarketPlace</a></li>
<li><a href="">Login to Account</a></li>
<li><a href="">Buyer+ Package</a></li>
<li><a href="">Procurement Tools</a></li>  
</ul> 

</div>


<div class="footercol">
<h3 class="wh_hedaer">Suppliers</h3>
<ul>
<li><a href="">Request Leads</a></li>
<li><a href="">Post for Sale</a></li>
<li><a href="">Login to Account</a></li>                         
<li><a href="">Pricing & Packages</a></li>
<li><a href="">Company Accounts</a></li>
</ul> 
</div>


<div class="footercol">
<h3 class="wh_hedaer">Support Center</h3>
<ul>
<li><a href="">Frequenty Asked Questions </a></li>    
<li><a href="">Quote System </a></li>    
<li><a href="">Marketplace </a></li>    
<li><a href="">Account Support </a></li>    
<li><a href="">Contact Support</a></li>   
</ul>  
</div>


<div class="footercol">
<h3 class="wh_hedaer">About Us</h3>
<ul>  
<li><a href="">Company Information</a></li>                        
<li><a href="">Service Offering </a></li>    
<li><a href="">Our Mission</a></li>   
</ul> 
</div>

<div class="footercol">
<h3 class="wh_hedaer">Contact Us</h3>
<ul> 
<li><a href="">Contact Information</a></li>                        
<li><a href="">Support Team </a></li>    
<li><a href="">Advertiser Info</a></li>    
</ul> 

</div> 

</div> 

<div class="clearfix"></div>




<div class="copyright">     
<div class="nopadding text-center"> 
 <div class="text-center"> 
     <ul class="scocialicon">
         <li> <h4 class="header_18">Stay Connected:</h4>  </li> 
         <li class="hvr-bounce-to-right fb"><a href=""> <i class="fa fa-facebook"></i></a></li>  
         <li class="hvr-bounce-to-right lnk"><a href=""><i class="fa fa-linkedin"></i></a></li> </ul>
   
 </div>
  <hr/>
  
  <p>&copy; 2016 QuoteTek Solutions, Inc. All Rights Reserved. </p>
  <p>QuoteTek.com is A Industrial Marketplace and not an Approved Vendor or Distributor of Manufacturer Products or Services.</p>
 
  <ul class="trm_pp">
      <li><a href="">Terms of Usage</a></li> 
      <li><a href="">Privacy Policy </a></li>
  </ul>
  

</div>
</div>  
</div>
