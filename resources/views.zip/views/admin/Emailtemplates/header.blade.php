<html style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
<head>
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

   
</head>
<body bgcolor="#fbf6f6" style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; -webkit-font-smoothing: antialiased; height: 100%; -webkit-text-size-adjust: none; width: 100% !important; margin: 0; padding: 0;">



<table class="body-wrap" bgcolor="fbf6f6" style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; width: 100%; margin: 0; padding: 20px 20px 0;"><tr style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;">
    <td style="font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; margin: 0; padding: 0;"></td>
    <td class="container" bgcolor="#FFFFFF" style="border-radius: 15px; font-family: 'Open Sans', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; clear: both !important; display: block !important; max-width: 600px !important; Margin: 0 auto; padding: 0 auto 20px; border: 1px solid #000;">
   <br />
<div align="center" padding="25px 10px 10px 10px"><img  padding="25px 10px 10px 10px" src="http://cryptdata.com/qt/public/livesite/images/e-mail/logo.png" width="150px" alt="INDY JOHN" height="40px" style="margin: 0 auto"></div>


   <p style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.6em; font-weight: normal; margin: 0 auto 10px; text-align: center; padding: 0;">
                <b>A Social Marketplace for the Industrial World.</b></p>
				
    <div class="content" style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; display: block; max-width: 600px; margin: 0 auto; padding: 0;">
            <div class="content" style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6em; display: block; max-width: 600px; margin: 0 auto; padding: 0 20px;">
            

				
				
<!--E-mail HEADER ENDS -->				
<!--E-mail BODY Starts -->				
				

          
