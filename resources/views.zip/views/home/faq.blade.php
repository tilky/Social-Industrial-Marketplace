@extends('home.app')
@section('content')
@include('home.header')
<link href="{{URL::asset('public/metronic/assets/pages/css/faq.min.css')}}" rel="stylesheet" type="text/css" />
<div class="faq-page"> 
  <!--======================= layout ========================-->
  
  <div class="small-layout" style="background-image: url('{{URL::asset('public/livesite/images/banners/8.jpg')}}') ;">
    <div class="mask"></div>
    <h1 class="header_middle text-center animated bounceInDown slower go">Frequently Asked Questions</h1>
  </div>
  
  <!--=======================================================--> 
  
  <!--======================= Navbar ========================-->
  <div class="simple-navbar text-center relative">
    <ul class="list-inline">
      <li><a href="{{url('about-us')}}">About Us</a></li>
      <li class="active"><a href="{{url('faq')}}">FAQ</a></li>
      <li><a href="{{url('news')}}">Indy John News</a></li>
      <li><a href="{{url('investor-outreach')}}">Investor Outreach</a></li>
      <li><a href="{{url('contact-us')}}">Contact Us</a></li>
    </ul>
    <div class="vertical_lines"></div>
  </div>
  
  <!--=======================================================--> 
  
  <!--======================= Questions  ========================-->
  
  <section class="container">
    <h3>Frequently Asked Questions </h3>
    <div class="faq-content-container">
    <div class="col-md-12">
    <div class="row">
      <div class="col-md-6">
        <div class="faq-section ">
          <h2 class="faq-title uppercase ">Indy John Basics <small class="expand-all">(expand all)</small></h2>
          <div class="collapse in panel-group accordion faq-content" id="accordion1">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_1"> What Is Indy John?</a> </h4>
              </div>
              <div id="collapse_1" class="panel-collapse collapse">
                <div class="panel-body"><p> Indy John is a social marketplace built for Industrial Buyers and Suppliers. Our platform offers a more efficient way for Industrial people to Buy, Casually Shop and Sell industrial items and services.</p> </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_2"> How does Indy John work? </a></h4>
              </div>
              <div id="collapse_2" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Indy John is easy to use! Whether you’re a Buyer or Supplier, or both, create a free account and choose how you want to start using your account. Once you completed the quick sign up process, all users are given a Buyer dashboard for purchasing and a Supplier CRM for selling. Feel free to use one or both of these features. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_3"> What type of items can Indy John help me Buy or Sell? </a></h4>
              </div>
              <div id="collapse_3" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We can help you Buy or Sell most items containing technical specifications or physical dimensions.  Our list of products, supplies, consumables and services is extensive and searchable throughout our site. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_4"> Why should I sign up with Indy John? </a></h4>
              </div>
              <div id="collapse_4" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We are the only social marketplace focused on the Industrial Buy-Sell experience and we have new marketing technologies designed to benefit our users.  With much more to come. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_5"> How do I start using Indy John? </a></h4>
              </div>
              <div id="collapse_5" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> No workday is the same, so we’ve installed a Quick-Start guide in the dashboard to assist you with work options. Need some more guidance? We have a tutorial in our Dashboard-CRM always ready to help. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_6"> Does Indy John manage payments between Buyers and Suppliers? </a></h4>
              </div>
              <div id="collapse_6" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> At this time, Indy John chooses not to manage payments for transactions. We’re here to make meaningful and productive connections amongst our users.  However, upon completing transactions, we encourage you to evaluate and leave a user review. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_7"> Can I use Indy John solely for networking and connecting purposes? </a></h4>
              </div>
              <div id="collapse_7" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> No problem, we’d hope you make us your source to Buy-Sell Industrial but feel free to grow your network using our service. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_8"> How do I gain trust of other users on Indy John? </a></h4>
              </div>
              <div id="collapse_8" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We encourage all users to establish their account and become a verified user.  This is one way to ensure you’re doing a trustworthy business deal. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_9"> What can Indy John’s Search Discovery help me find? </a></h4>
              </div>
              <div id="collapse_9" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Our Search Discovery can help you in many ways.  We can help you find Products, People, Companies, and Service Providers. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_10"> What do Indy John’s number codes stand for? </a></h4>
              </div>
              <div id="collapse_10" class="panel-collapse collapse">
                <div class="panel-body">
                 
                  
                  <ul>
                    <li>IJB - Indy John Buy-Request </li>
                    <li> IJQ - Indy John Quote</li>
                    <li> IJI - Indy John Item</li>
                    <li> IJU - Indy John User</li>
                    <li> IJJ - Indy John Job</li>
                    <li> IJV - Indy John Invoice</li>
                    <li> IJM - Indy John Market Listing</li>
                    <li> IJC - Indy John Company I.D.</li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_11"> Is there a Mobile Application for Indy John? </a></h4>
              </div>
              <div id="collapse_11" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> No, our mobile application is coming soon.  However, IndyJohn.com is a mobile compatible website. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_12"> Is there a solution for Company Administrators? </a></h4>
              </div>
              <div id="collapse_12" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> At this time, our company solutions are still in development but we offer a free User-Administrator account.  This account is exactly the same as other accounts <b>except they have administrative authority over an Indy John Company Page</b>.  With this account, you can manage your company details, modify showcase photos, and monitor all user interaction. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_13"> What is an Indy John Company Page? </a></h4>
              </div>
              <div id="collapse_13" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> It’s a listing we showcase inside our Industrial marketplace.  Once your company page is created, your listing can be searched and discovered by people looking for your specific company or keywords associated with your Industrial offering. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_14"> How do I start or manage a company page? </a></h4>
              </div>
              <div id="collapse_14" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> You can start or join a company inside your Dashboard-CRM.  Start by searching and claiming existing company pages - If you’re authorized to be an administrator, provide us some brief details about your company and start managing.  For those who are not authorized to be administrator, you can start the company page process but will need to recommend an administrator by providing a name and email. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_15"> Can my company Partner or Advertise with Indy John? </a></h4>
              </div>
              <div id="collapse_15" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Let’s talk, were currently looking for strategic partnerships and limited advertising is now available.  Please visit our Marketing Solutions page for details. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_16"> How do I contact Indy John for user help or to report a problem? </a></h4>
              </div>
              <div id="collapse_16" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Create a support ticket inside your Dashboard-CRM or visit our Contact Us page and message us, we’ll aim to address all issues in a timely manner. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_17"> How do I stop using Indy John? </a></h4>
              </div>
              <div id="collapse_17" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Indy John provides an At-Will service, simply stop using Indy John but we hope you’d reconsider us. </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
        <div class="col-md-6">
        <div class="faq-section ">
          <h2 class="faq-title uppercase ">User Accounts <small class="expand-all">(expand all)</small></h2>
          <div class="collapse in panel-group accordion faq-content" id="accordion2">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse_18"> Does Indy John really offer a free account? </a></h4>
              </div>
              <div id="collapse_18" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Yes, our core marketplace is free to use and most features are included in the free account. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_19"> Which Buy-Sell features are available to me with a free account? </a></h4>
              </div>
              <div id="collapse_19" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> All features are available to use but limited in some capacity.  Compare our Buyer and Supplier user accounts and decide which best fits your needs. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_20"> Why should I verify my account? </a></h4>
              </div>
              <div id="collapse_20" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We encourage all users to establish their account and become a verified user.  This is one way to ensure you’re doing a trustworthy business deal. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_21"> How do I verify my account? </a></h4>
              </div>
              <div id="collapse_21" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Verification is a simple process done by email, phone number, or social media profile. Upon completion, a verified seal will be attached to your account and displayed when you connect with other users.  For free members, we charge a small fee for this verification as it includes a comprehensive background check. For upgraded members, verification fee is waived. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_22"> What is an Indy John User-Administrator account? </a></h4>
              </div>
              <div id="collapse_22" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> This account is treated like any other Indy John account, except this account has company administrator authority.  As an administrator, you’ll be able to manage your company page and monitor all users added and subtracted from your company page. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_23"> How do I know if my account is a User-Administrator account? </a></h4>
              </div>
              <div id="collapse_23" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Upon sign up process, you may claim the administrator role or delegate that role to another associate.  Quick Tip - A Company Administrator menu will be displayed in your Dashboard and CRM. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_24"> Why should I upgrade my Buyer Account to Buyer+? </a></h4>
              </div>
              <div id="collapse_24" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We offer a Buyer+ account for more serious buyers looking to gain faster pricing options and do more with our Indy John Market. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_25"> Should I upgrade my Supplier Account status to Silver or Gold? </a></h4>
              </div>
              <div id="collapse_25" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We recommend Silver and Gold Accounts for users with higher sales and marketing goals.  Users can also increase selling opportunities in our Indy John Market being a valued member, compare valued account to learn more. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_26"> How do I upgrade my user account? </a></h4>
              </div>
              <div id="collapse_26" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Every Buyer Dashboard and Supplier CRM has an UPGRADE icon, simply click and select the account that works best for you.  Provide us billing details and continue using Indy John with additional advantages. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_27"> How does a Valued Account pricing compare to competitors? </a></h4>
              </div>
              <div id="collapse_27" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We don’t have a direct competitor but there are plenty of expensive companies who charge high fees for networking only or cold calling lists.  No company today is doing what Indy John can do for you! </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_28"> Can I use both Buyer Dashboard and Supplier CRM? </a></h4>
              </div>
              <div id="collapse_28" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We understand Suppliers may purchase items and Buyers sometimes sell products, feel free to be a dual-user and toggle back and forth between Buying and Selling features. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_29"> How does Indy John secure its members’ account information? </a></h4>
              </div>
              <div id="collapse_29" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We understand malicious activity is a constant issue. While there is no security measure that is completely impenetrable, Indy John will continue to be proactive in this department and use modern security measures to help protect against malicious actions on your personal information. </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
        </div>
        </div>
        <div class="col-md-12">
    <div class="row">
        <div class="col-md-6">
        <div class="faq-section ">
          <h2 class="faq-title uppercase ">Quote-Lead System <small class="expand-all">(expand all)</small></h2>
          <div class="collapse in panel-group accordion faq-content" id="accordion3">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapse_30"> What is the Quote-Lead System? </a></h4>
              </div>
              <div id="collapse_30" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Our system is a more efficient way for Industrial people to Buy and Sell items and services.  We match and connect Buyers and Suppliers based on product and service keywords, resulting in pricing options for Buyers and increased selling opportunities for Suppliers.  We’ve also thrown in a Buyer Dashboard and Supplier CRM for users, designed to better manage all new Quote-Lead system activity. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_31"> What type of items can Indy John help me Buy or Sell? </a></h4>
              </div>
              <div id="collapse_31" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We can help you Buy or Sell most items containing technical specifications or physical dimensions.  Our list of products, supplies, consumables and services is extensive and searchable throughout our site. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_32"> As a Buyer, how does the Quote-Lead system work? </a></h4>
              </div>
              <div id="collapse_32" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Submit one Buy Request into our system and based on your product or service needs, we’ll match you with a network of Indy John Suppliers. Then sit back and prepare to compare quotes and get the price you want. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_33"> Why should I make Indy-John my place for purchasing Industrial products and services? </a></h4>
              </div>
              <div id="collapse_33" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Indy John is a money-saver! Industrial items and services are specialized desirables with a wide price range, we can help you receive pricing options and we’ll also throw in a dashboard to help you organize all your purchases. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_34"> As a Supplier, how does the Quote-Lead system work? </a></h4>
              </div>
              <div id="collapse_34" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Inside your Indy John CRM, create individual Lead Requests for your product offering and we’ll match you with new incoming Buy Requests. Then simply, respond to your Buy Requests using our built-in quote template. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_35"> Why is this system a better alternative to existing selling methods? </a></h4>
              </div>
              <div id="collapse_35" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Our system is exactly the opposite of Cold Calling prospects and knocking on doors.  Simply create Lead Requests and we’ll bring the Sales Leads to you.  Our system has virtually eliminated the “pursuit” and rewarded you with the “catch”! </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_36"> Is there a solution for Sales Teams and Company Administrators? </a></h4>
              </div>
              <div id="collapse_36" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> At this time, our company solutions are still in development but we offer a free User-Administrator account.  Company Administrator rights are determined upon a normal sign up process. With this account, you can monitor your Indy John company page as well as manage all users added to your company page. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_37"> Can I use both Buyer Dashboard and Supplier CRM features? </a></h4>
              </div>
              <div id="collapse_37" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Yes, we understand most Indy John users will use both Buy-Sell features.  Once you’re signed up, feel free to jump back and forth between Buying and Selling. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_38"> Does Indy John manage payments between Buyers and Suppliers? </a></h4>
              </div>
              <div id="collapse_38" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> At this time, Indy John chooses not to manage payments for transactions. We’re simply here to make meaningful and productive connections amongst our users.  However, upon completing transactions, we encourage you to evaluate and leave a user review. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_39"> How can I maximize Buying and Selling opportunities with the Quote-Lead system? </a></h4>
              </div>
              <div id="collapse_39" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Compare our valued account and decide which one works best for your professional needs.  Check out our FAQ-User Accounts section to learn more. </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
        <div class="col-md-6">
        <div class="faq-section ">
          <h2 class="faq-title uppercase ">Indy John Market <small class="expand-all" >(expand all)</small></h2>
          <div class="collapse in panel-group accordion faq-content" id="accordion4">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion4" href="#collapse_40"> What is the Indy John Market? </a></h4>
              </div>
              <div id="collapse_40" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Indy John Market is a brand new Industrial-Only market.  All users can Purchase, Sell, or casually shop for products and supplies. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_41"> What type of items can I find in the Indy John Market? </a></h4>
              </div>
              <div id="collapse_41" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Give us time to build up supplier inventory, but once it’s at full capacity you’ll be able to find Industrial equipment, instrumentation, tools, supplies, consumables and much more. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_42"> How do I List items in the Indy John Market? </a></h4>
              </div>
              <div id="collapse_42" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Located in the Indy John Dashboard-CRM, all users have an Indy John Market area with a few action tasks available for use. Search and Post items directly from your Dashboard-CRM. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_43"> Can anyone post items on the Indy John Market? </a></h4>
              </div>
              <div id="collapse_43" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Yes! .. Indy John Market is free to use for all users. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_44"> How much does it cost to post items? </a></h4>
              </div>
              <div id="collapse_44" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Casual Buying and Selling can be done with our free account.  Looking to do more? Explore becoming a valued member. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_45"> How many items can I post in Indy John Market? </a></h4>
              </div>
              <div id="collapse_45" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Free account users can post up to 30 items per month.  Do you want to post more than 30 items? Please explore becoming an Indy John valued member. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_46"> When does my market listing expire? </a></h4>
              </div>
              <div id="collapse_46" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Valued member listings will appear in the market until listing is manually removed. For our free users, we have a 30 day listing expiry date. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_47"> Does Indy John manage payments between Buyers and Suppliers? </a></h4>
              </div>
              <div id="collapse_47" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> At this time, Indy John chooses not to manage payments for transactions. We’re simply here to make meaningful and productive connections amongst our users.  However, upon completing transactions, we encourage you to evaluate and leave a user review. </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
        </div>
        </div>
        <div class="col-md-12">
    <div class="row">
        <div class="col-md-6">
        <div class="faq-section ">
          <h2 class="faq-title uppercase ">Indy John Job Board <small class="expand-all">(expand all)</small></h2>
          <div class="collapse in panel-group accordion faq-content" id="accordion5">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion5" href="#collapse_48"> What is the Indy John Job Board? </a></h4>
              </div>
              <div id="collapse_48" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Were focused on building a great industrial marketplace for our users but we also want to add helpful resources for our users. So, were introducing a brand new Job Board focused on Industrial jobs. All users can Explore, Search, and Post Industrial jobs. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_49"> How do I get started using the Job Board? </a></h4>
              </div>
              <div id="collapse_49" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> You’ll find a Job Center menu in each user Dashboard-CRM. Posting and Searching jobs can be initiated from there, also look for our green Indy John tab located throughout our site to begin job actions. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_50"> As a Job Seeker, why should I use Indy John to search jobs? </a></h4>
              </div>
              <div id="collapse_50" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We’re dedicated to Industrial jobs and nothing else!  When our new job board is at full capacity, you’ll be able to Search and quickly Apply for specific positions or skillsets desired by potential employers. Plus, you’ll be able to manage all applying data in your free user dashboard. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_51"> As an Employer, why is Indy John the right place to post my job openings? </a></h4>
              </div>
              <div id="collapse_51" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Our system matches Employers with Applicants based on specific Industrial expertise and skillsets.  You’ll have the ability to recruit and decide between worthy industrial-minded applicants. We’ll also allow you to manage all this new applicant data in our Job Center. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_52"> Why is this Job Board different from other job posting sites? </a></h4>
              </div>
              <div id="collapse_52" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> We’re dedicated to Industrial employment opportunities and we’re a lot cheaper than other professional and technical job sites! Your company job posting would also be available and displayed to a large Industrial audience. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_53"> How much does it cost to use the Job Board? </a></h4>
              </div>
              <div id="collapse_53" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Free to search and apply for jobs.  To post a job - we charge $30.00 for a 30 day listing.                               * Our Valued Accounts include job credits, 1 Credit = 1 Job posting </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_54"> When does my job listing expire? </a></h4>
              </div>
              <div id="collapse_54" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Valued member job credit listings will appear in the market until job posting is manually removed. Free users that posted with job listing fee, those listings will expire after 30 days. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_55"> Where do I manage all job data? </a></h4>
              </div>
              <div id="collapse_55" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> It’s easy, all job details and applicant management can be done in your user dashboard. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_56"> Is there a solution for Company Administrators? </a></h4>
              </div>
              <div id="collapse_56" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> No, all users can post and manage employment opportunities and candidates inside their Dashboard-CRM. </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
        <div class="col-md-6">
        <div class="faq-section ">
          <h2 class="faq-title uppercase ">Social <small class="expand-all">(expand all)</small></h2>
          <div class="collapse in panel-group accordion faq-content" id="accordion6">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion6" href="#collapse_57"> Can I use Indy John solely for networking and connecting purposes? </a></h4>
              </div>
              <div id="collapse_57" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> No problem, we’d hope you make us your source to Buy-Sell Industrial but feel free to grow your network using our service. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_58"> Can I Endorse and Review other Indy John users? </a></h4>
              </div>
              <div id="collapse_58" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Yes, we encourage all users to endorse and review.  This will help us build a better network of valuable users.</p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_59"> Can I screen my reviews before they appear on my profile? </a></h4>
              </div>
              <div id="collapse_59" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Yes, this is done inside your Dashboard-CRM. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_60"> How do I invite friends and associates to Indy John? </a></h4>
              </div>
              <div id="collapse_60" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> An upgrade icon is installed in every Dashboard-CRM, choose what invite method you want to use and begin compiling a list of referring earning opportunities. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_61"> Can I Direct-Message other Indy John users? </a></h4>
              </div>
              <div id="collapse_61" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Yes, all messaging activity is organized inside your Dashboard-CRM. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_62"> How do I sign up for the Referral Program? </a></h4>
              </div>
              <div id="collapse_62" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> It’s easy.  Once you’re signed up with Indy John, we’ll generate you a referral code to pass along or you can simply share your Indy John profile link with friends and associates.  When your referrals decide to become a valued member, you start earning payouts. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_63"> How much can I earn by referring others? </a></h4>
              </div>
              <div id="collapse_63" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> You can earn up to $100 per paid account that you refer. If they sign up, but choose a free account, our system will make a record and your referral bonus will be paid when they become a paying customer. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_64"> How do I manage my referrals and payouts? </a></h4>
              </div>
              <div id="collapse_64" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> This is easily done inside your Dashboard-CRM. Each Dashboard-CRM has a Referral Program menu with details on how to manage your referrals and payouts. </p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_65"> How fast will I receive my referral payouts? </a></h4>
              </div>
              <div id="collapse_65" class="panel-collapse collapse">
                <div class="panel-body">
                  <p> Referral payouts will be made up to 45 days from time your candidate’s first valued account payment.  All payout data will be managed inside your Dashboard-CRM. </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
        </div>
        </div>
      </div>
   
    <!--  <div class="section-content">
        <h3>Frequently Asked Questions  <small >(expand all)</small></h3>
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingOne">
                    <h4 class="panel-title ">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
     <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>What is Indy John ?     </b> </a>
</h4>
                </div>
                <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                    <div class="panel-body">
                        <p>
                           Indy John is the first Industrial marketplace built on a social selling platform, created for the industrial world.  
                        </p>
                    </div>
                </div>
            </div>
			
			
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingTwo">
                    <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="false" aria-controls="collapse1">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>How does Indy John work?     </b>
</a>
</h4>
                </div>
                <div id="collapse1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                    <div class="panel-body">
                        <p>
                           Indy John is easy to use. Whether you're a buyer or supplier, you will be required to create an account and choose how you want to use your account. Once you completed the quick sign up process, you will be given a Buyer dashboard for purchasing and a Supplier CRM for selling. Feel free to use one or both of these features. Please visit our Buyer Features page and Supplier Network page for details.
                        </p>

                    </div>
                </div>
            </div>
		<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading1"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="false" aria-controls="collapse1">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
What Is The Quote-Lead System™?
   </b></a></h4></div><div id="collapse1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading1"><div class="panel-body"><p>
The system is a more efficient way for industrial Buyers and Suppliers to perform their jobs.  We’ll match and connect Buyers and Suppliers based on product and service keywords.  This will result in pricing options for Buyers and increased selling opportunities for Suppliers. We’ve also thrown in a Buyer Dashboard and Supplier CRM for users, designed to better manage all Quote-Lead System™ activity.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading3"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="false" aria-controls="collapse3">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Does Indy John Work?
   </b></a></h4></div><div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3"><div class="panel-body"><p>
Indy John is easy to use. Whether you’re a buyer or supplier, you will be required to create a free account and choose how you want to use your account. Once you completed the quick sign up process, all users are given a Buyer dashboard for purchasing and a Supplier CRM for selling. Feel free to use one or both of these features. Please visit our Buyer Features page and Supplier Network page for details.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading4"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="false" aria-controls="collapse4">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
   Can I Use Both Buyer Dashboard and Supplier CRM features?
   </b></a></h4></div><div id="collapse4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading4"><div class="panel-body"><p>
Yes, we understand most Indy John users will be Dual Feature users.  Once your signed up, please feel free to jump back and forth between Buying and Supplying.
</p></div></div></div>


<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading5"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="false" aria-controls="collapse5">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Is There A Cost For using Indy John?
   </b></a></h4></div><div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading5"><div class="panel-body"><p>
Our core marketplace is free to use and most features are included in the free account. We do offer a Buyer+ account for more serious buyers and valued accounts for suppliers with higher sales and marketing goals. 
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading6"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse6" aria-expanded="false" aria-controls="collapse6">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Do I Upgrade My User Account?
   </b></a></h4></div><div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading6"><div class="panel-body"><p>
Every Buyer Dashboard and Supplier CRM has an UPGRADE icon, it’s an easy process, simply click and select the account that works best for you.  Provide us some billing details and continue using Indy John with additional advantages.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading6"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse6" aria-expanded="false" aria-controls="collapse6">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
What Is The Indy John Market?
   </b></a></h4></div><div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading6"><div class="panel-body"><p>
Indy John Market is a brand new Industrial-Only market.  All users can Purchase, Sell, or casually shop for products and supplies. 
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading8"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse8" aria-expanded="false" aria-controls="collapse8">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Can Anyone Post Products On The Indy John Market?
   </b></a></h4></div><div id="collapse8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading8"><div class="panel-body"><p>
Yes! Indy John Market is free to use for all users, list up to 30 products with a free account. Looking to do more with our market, see our valued accounts for details.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading9"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse9" aria-expanded="false" aria-controls="collapse9">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
What Can Indy John’s Search Help Me Find?
   </b></a></h4></div><div id="collapse9" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading9"><div class="panel-body"><p>
Our Search Discovery can help you in many ways.  We can help you locate Products, People, Companies, and Service Providers.  
</p></div></div></div>


<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading10"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse10" aria-expanded="false" aria-controls="collapse10">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Does Indy John manage payments between Buyers and Suppliers?
   </b></a></h4></div><div id="collapse10" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading10"><div class="panel-body"><p>
At this time, Indy John does not manage payments for transactions. However, upon completing the transaction, we encourage you to evaluate and leave a user review.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading11"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse11" aria-expanded="false" aria-controls="collapse11">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Do I Gain Trust Of Other Users On Indy John?
   </b></a></h4></div><div id="collapse11" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading11"><div class="panel-body"><p>
We do encourage all of our users to establish their account and become verified in order to make full use of our services. This is one way to ensure you’re doing a trustworthy business deal. Verification is done by email, phone number, or social media profile. Upon completion, a verified seal will be attached to your account and displayed when you connect with other users. There is a fee for this verification as it includes a comprehensive background check. Visit Verification tab in your Dashboard to learn more.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading12"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse12" aria-expanded="false" aria-controls="collapse12">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Is There A Mobile Application For Indy John?
   </b></a></h4></div><div id="collapse12" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading12"><div class="panel-body"><p>
No, our mobile application is coming soon.  However, IndyJohn.com is a mobile compatible website. 
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading13"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse13" aria-expanded="false" aria-controls="collapse13">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Do I Sign Up To Start Referring And Earning?
   </b></a></h4></div><div id="collapse13" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading13"><div class="panel-body"><p>
It’s easy.  Once you’re signed up on Indy John, we’ll generate you a referral code or you can simply share your Indy John profile link with friends and associates.  Each Buyer Dashboard and Supplier CRM has a Referral Center with more instruction and details on how to manage your referrals and payouts.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading14"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse14" aria-expanded="false" aria-controls="collapse14">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Much Can I Earn By Referring Others?
   </b></a></h4></div><div id="collapse14" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading14"><div class="panel-body"><p>
You can earn up to $100 per paid account that you refer. If they sign up, but choose a free account, our system will make a record and your referral bonus will be paid when they become a paying customer.
</p></div></div></div>


<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading15"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse15" aria-expanded="false" aria-controls="collapse15">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Is There A Solution For Sales Teams And Company Administrators?
   </b></a></h4></div><div id="collapse15" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading15"><div class="panel-body"><p>
Indy John is easy to use. Whether you're a buyer or supplier, 
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading16"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse16" aria-expanded="false" aria-controls="collapse16">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
   How does Indy John work?
   </b></a></h4></div><div id="collapse16" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading16"><div class="panel-body"><p>
At this time, we offer corporate accounts for companies with 5 or more paid users. We consider these customized accounts and are built to a company’s specific needs, all designed to help you better manage and organize your data.  Please contact us at sales@indyjohn.com to learn more.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading17"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse17" aria-expanded="false" aria-controls="collapse17">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
Can My Company Partner or Advertise With Indy John?
   </b></a></h4></div><div id="collapse17" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading17"><div class="panel-body"><p>
Let’s talk, were currently looking for strategic partnerships and limited advertising is now available.  Please visit our Marketing Solutions page for details.
</p></div></div></div>

<div class="panel panel-default"><div class="panel-heading" role="tab" id="heading18"> <h4 class="panel-title">
<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse18" aria-expanded="false" aria-controls="collapse18">
   <i class="fa fa-minus"></i><i class="fa fa-plus"></i><b>
How Do I Contact Indy John For User Help Or General Questions?
   </b></a></h4></div><div id="collapse18" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading18"><div class="panel-body"><p>
Please visit our Contact Us page and message us, we’ll aim to address all issues in a timely manner. You can also log in and submit a Support ticket from the Main menu.
</p></div></div></div>



			          




        </div>
    </div>--> 
    
  </section>
  
  <!--=======================================================--> 
</div>
<script>
	$(document).on('click', "small.expand-all", function() {
	$(this).addClass('expand-open');
	$(this).removeClass('expand-all');
	$(this).parent().parent().find('.accordion-toggle').removeClass('collapsed');
	$(this).parent().parent().find('.panel-collapse').addClass('in');
	$(this).parent().parent().find('.panel-collapse').css("height", "auto");;
});

	$(document).on('click', "small.expand-open", function() {
	$(this).removeClass('expand-open');
	$(this).addClass('expand-all');
	$(this).parent().parent().find('.accordion-toggle').addClass('collapsed');
	$(this).parent().parent().find('.panel-collapse').removeClass('in');
});

</script>
@include('home.footerlinks')
@endsection 
