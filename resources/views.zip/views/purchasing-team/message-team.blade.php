@extends('buyer.app')

@section('content')
<style>
.media:nth-of-type(odd) {
    background-color: #fbfcfd;
}
</style>
<link href="{{URL::asset('public/metronic/apps/css/inbox.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/select2/css/select2-bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/fancybox/source/jquery.fancybox.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/jquery-file-upload/blueimp-gallery/blueimp-gallery.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/jquery-file-upload/css/jquery.fileupload.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/jquery-file-upload/css/jquery.fileupload-ui.css')}}" rel="stylesheet" type="text/css" />
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="{{url()}}/user-dashboard">Home</a>
            <i class="fa fa-circle"></i>
        </li>
       
        <li>
            <span>Team Message</span>
        </li>
    </ul>
</div>

<div class="col-md-12 main_box">
<div class="row">
<div class="col-md-12 border2x_bottom">
<div class="col-md-9 col-sm-9">
        <div class="row">
<h3 class="page-title uppercase">Team Messaging</h3>
</div>
</div>
<div class="col-md-3 col-sm-3 text-right">
        <div class="row">
          <div class="actions margin-top-10"> <select class="form-control">
              <option value="created_at" selected="selected">Selected Team</option>
              <option value="expiry_date">Team 1 </option>
              <option value="hidden_quotes">Team 2 </option>
            </select> </div>
        </div>
      </div>
</div>

</div>
<div class="row">
    <div class="col-md-12">
         <div class="col-md-12 padding-top paddin-bottom">
            @if($errors->any())
            <div class="alert alert-danger">
                @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
                @endforeach
            </div>
            @endif
            @if (Session::has('message'))
                <div id="" class="custom-alerts alert alert-success fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>{{ Session::get('message') }}</div>
            @endif
            <!-- BEGIN PAGE BASE CONTENT -->
            <div class="inbox">
                <div class="row">
                    
                    <div class="col-md-12">
                        <div class="inbox-body">
                            <div class="inbox-content">
                                
                                <h1>TEAM NAME HERE</h1>
            
                                
                                    <div class="media">
                                        <a class="pull-left" href="#">
                                            <img src="//www.gravatar.com/avatar/{!! md5($message->user->email) !!}?s=64" alt="{!! $message->user->name !!}" class="img-circle">
                                        </a>
                                        <div class="media-body">
                                            <h5 class="media-heading">Sender Name</h5>
                                            <p>Message:</p>
                                            <div class="text-muted"><small>Posted on:</small></div>
                                        </div>
                                    </div>
                               
                                <div class="col-md-12">
                                    <h3>Attachments</h3>
                                  
                                    <p><a href="{{url('')}}/{{$attachment->attachment_path}}" download>Download Attachment {{$index+1}}</a></p>
                                  
                                </div>
                                
                                <div style="clear: both;"></div>              
                                <!-- BEGIN FORM-->
                                
                                <div class="form-body">
                                    <h2>Send a new message</h2>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <!-- Subject Form Input -->
                                            <div class="form-group">
                                                <textarea class="inbox-editor inbox-wysihtml5 form-control" name="message" rows="12"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-actions right">
                                        <a href="{{ URL::to('marketplaceproducts') }}" class="btn btn-circle red bold btn-sm">
                                            Cancel </a>
                                        <button type="submit" class="btn btn-circle yellow-crusta color-black bold">
                                            <i class="fa fa-check"></i>Post Message</button>
                                    </div>
                                
                               
                                <!-- END FORM-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END PAGE BASE CONTENT -->
        </div>   
        
    </div>
</div>
</div>

<script>
    /* for show menu active */
    $("#messenger-main-menu").addClass("active");
	$('#messenger-main-menu' ).click();
    /* end menu active */
    
    $( document ).ready(function() {
        $('#free_shipping_continents').multiSelect();
        $('#product_color').multiSelect();
        $('#product_usage').multiSelect();
        $('.inbox-wysihtml5').wysihtml5({
          toolbar: {
            
          }
        });
    });
</script>
<script src="{{URL::asset('public/metronic/plugins/select2/js/select2.full.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/fancybox/source/jquery.fancybox.pack.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/vendor/jquery.ui.widget.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/vendor/tmpl.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/vendor/load-image.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/vendor/canvas-to-blob.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/blueimp-gallery/jquery.blueimp-gallery.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/jquery.iframe-transport.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/jquery.fileupload.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/jquery.fileupload-process.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/jquery.fileupload-image.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/jquery.fileupload-audio.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/jquery.fileupload-video.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/jquery.fileupload-validate.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('public/metronic/plugins/jquery-file-upload/js/jquery.fileupload-ui.js')}}" type="text/javascript"></script>
@endsection
