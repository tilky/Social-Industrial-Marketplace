@extends('supplier.app')

@section('content')
<link href="{{URL::asset('public/metronic/plugins/bootstrap-daterangepicker/daterangepicker.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')}}" rel="stylesheet" type="text/css" />
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li> <a href="{{url('user-dashboard')}}">Home</a> <i class="fa fa-circle"></i> </li>
        <li> <span>Assigned Lead Requests</span> </li>
    </ul>
</div>
<div class="col-md-12 main_box">
    <div class="row">
        <div class="col-md-12 border2x_bottom">
        <h3 class="page-title uppercase"> <i class="fa fa-group color-black"></i> Assigned Lead Requests </h3>
    </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="col-md-12">
                <div class="portlet-body">
                    @if (Session::has('message'))
                    <div id="" class="custom-alerts alert alert-success fade in">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
                    {{ Session::get('message') }}
                    </div>
                    @endif
                    <div class="col-md-9 paddin-npt">
                        <p class="caption-helper">Assigned Lead Requests:</p>
                    </div>
                    <div class="col-md-12 paddin-npt">
                        <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                            <thead>
                                <tr>
                                    <th>Lead Request Name</th>
                                    <th>Lead Request ID</th>
                                    <th>Created On</th>
                                    <th>Assigned On</th>
                                    <th>Assigned To</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            @foreach($allSupplierLeadRequestArray as $supplierLeadRequest)
                                <tr>
                                    <td>{{ $supplierLeadRequest['leadRequestName'] }}</td>
                                    <td>{{ $supplierLeadRequest['leadRequestId'] }}</td>
                                    <td>{{ $supplierLeadRequest['createdOn'] }}</td>
                                    <td>{{ $supplierLeadRequest['assignedOn'] }}</td>
                                    <td><a class="btn dark btn-red btn-circle btn-sm" href="javascript:;">{{ $supplierLeadRequest['assignedTo'] }}</a></td>
                                    <td>
                                        <div class="btn-group"> <a class="btn btn-circle yellow-crusta" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> Actions <i class="fa fa-angle-down"></i> </a>
                                            <ul class="dropdown-menu pull-right">
                                                <li> <a href="" target="_blank"><i class="fa fa-eye"></i> View Lead Request</a></li>
                                                <li><a href="" onclick=""><i class="fa fa-edit"></i> Reassign</a></li>
                                                <li> <a href="{{url('/message-supplying-team')}}?team_id={{$supplierLeadRequest['teamId']}}" target="_blank"><i class="fa fa-file-text-o"></i> Message Team Members</a> </li>
                                                <li class="divider"> </li>
                                                <li> <a href="" ><i class="fa fa-pencil-remove"></i> Dismiss Assignment</a> </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <ul class="pager">
                        @if($previousPageUrl != '')
                        <li class="previous">
                            <a href="{{$previousPageUrl}}"> <i class="fa fa-long-arrow-left"></i> Prev </a>
                        </li>
                        @endif
                        @if($nextPageUrl != '')
                        <li class="next">
                            <a href="{{$nextPageUrl}}"> Next <i class="fa fa-long-arrow-right"></i> </a>
                        </li>
                        @endif
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 
