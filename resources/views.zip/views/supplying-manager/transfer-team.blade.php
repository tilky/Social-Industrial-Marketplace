@extends('supplier.app')

@section('content')
<style>
.select2-container{display: block!important;}
</style>
<link href="{{URL::asset('public/metronic/plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{URL::asset('public/metronic/plugins/select2/css/select2-bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
<div class="page-bar">
  <ul class="page-breadcrumb">
    <li> <a href="{{url('user-dashboard')}}">Home</a> <i class="fa fa-circle"></i> </li>
    <li> <a href="{{url('referrals')}}">About Supplying Teams</a> <i class="fa fa-circle"></i> </li>
    <li> <span>About Proram</span> </li>
  </ul>
</div>
<div class="col-md-12 main_box">
  <div class="row">
    <div class="col-md-12 border2x_bottom">
      <h3 class="page-title uppercase"> <i class="fa fa-group color-black"></i> Transfer Team</h3>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="portlet-body form"> @if($errors->any())
        <div class="alert alert-danger"> @foreach($errors->all() as $error)
          <p>{{ $error }}</p>
          @endforeach </div>
        @endif
        @if (Session::has('message'))
        <div id="" class="custom-alerts alert alert-success fade in">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
          {{ Session::get('message') }}</div>
        @endif
        <div class="col-md-12">
<h3>Use this page to transfer the team management to another Indy John user account.</h3>
<p>Please note, this step is not reversible, please ensure your details are accurate. </p>


<div class="form-group">
                                    <label class="col-md-12 paddin-npt">Select Your Team:</label>
                                    <div class="col-md-12 paddin-npt">
                                          <input type="number" name="qty_request" class="form-control" value="{{Request::old('qty_request')}}" placeholder="Select Team" />
										<span class="help-block margin-top">Select the team that you want to transfer.</span>
                                    </div>
                                </div>
                                
<div class="form-group">
                                    <label class="col-md-12 paddin-npt">Appoint New Manager:</label>
                                    <div class="col-md-12 paddin-npt">
                                         <input type="number" name="qty_request" class="form-control" value="{{Request::old('qty_request')}}" placeholder="Select User" />
									<span class="help-block margin-top">Search and Select the User.</span>
                                    </div>
                                </div>
                                
        
                                <button type="submit" class="btn btn-circle yellow-crusta"> <i class="fa fa-check"></i> Submit Request</button>                        
                                                             

         
         
         <h3>Team Transfer Status:</h3>
         
         <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
              <thead>
                <tr>
                  <th> Team Name </th>
                  <th> Initiated on</th>
                  <th> Status</th>
                  <th> Actions</th>
                 
                </tr>
              </thead>
              <tbody>
              
              <tr>
              <td>Team 123
 </td>
              <td>12/25/2015</td>
              <td>Pending Authorization from New Manager</td>
 
             
              <td><div class="btn-group"> <a class="btn btn-circle yellow-crusta" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> Actions <i class="fa fa-angle-down"></i> </a>
                    <ul class="dropdown-menu pull-right">
                  <li> <a href="" target="_blank"><i class="fa fa-eye"></i> Resend Transfer Verification E-mail</a></li>
        
                     
                      <li><a href="" onclick=""><i class="fa fa-edit"></i> Cancel Transfer</a></li>
                     
            
                 
                     
                  
                     
                    </ul>
                  </div></td>
              </tr>
                </tbody>
              
            </table>
            
            
         
         
         
           
         </div>
      </div>
    </div>
     <div class="clearfix"></div>
   <p>
  </div>
</div>

<script>
/* for show menu active */
$("#referrals-main-menu").addClass("active");
$('#referrals-main-menu' ).click();
$('#referrals-menu-arrow').addClass('open')
$('#referral-about-program-menu').addClass('active');
/* end menu active */

</script> 
@endsection 
